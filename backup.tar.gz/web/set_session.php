<?php
// 临时测试脚本：创建会话并设置用户信息
session_start();
$_SESSION['user_id'] = 1;
$_SESSION['username'] = '测试用户';
echo json_encode(['ok' => true, 'session_id' => session_id()], JSON_UNESCAPED_UNICODE);
