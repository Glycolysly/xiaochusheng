<?php
session_start();
if (!isset($_SESSION['username'])) { header("Location: index.php"); exit; }

// 自动扫描 music 文件夹里的文件
$music_dir = __DIR__ . '/music/';
$songs = [];
if (is_dir($music_dir)) {
    $files = scandir($music_dir);
    foreach ($files as $f) {
        if ($f !== '.' && $f !== '..') {
            $ext = strtolower(pathinfo($f, PATHINFO_EXTENSION));
            if (in_array($ext, ['mp3', 'flac', 'wav', 'm4a','ogg'])) {
                $songs[] = $f;
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="zh-cn">
<head>
    <meta charset="UTF-8">
    <title>在线音乐厅</title>
    <link rel="icon" type="image/png" href="title.png">
    <style>
        body { margin: 0; background: #121212; color: #fff; font-family: sans-serif; height: 100vh; display: flex; overflow: hidden; }
        
        /* 左侧：播放器核心区 */
        .player-zone { flex: 1; display: flex; flex-direction: column; align-items: center; justify-content: center; padding: 40px; background: linear-gradient(135deg, #1e1e2f 0%, #252540 100%); }
        
        /* 唱片封面动画 */
        .cover-art { 
            width: 300px; height: 300px; border-radius: 50%; 
            background: #333 url('title.png') no-repeat center/cover; /* 默认用你的logo做封面 */
            box-shadow: 0 0 30px rgba(0,0,0,0.5);
            animation: spin 10s linear infinite;
            animation-play-state: paused; /* 默认暂停 */
            border: 5px solid #222;
        }
        @keyframes spin { 100% { transform: rotate(360deg); } }
        
        .song-info { margin-top: 30px; text-align: center; }
        .song-title { font-size: 24px; font-weight: bold; margin-bottom: 10px; }
        .song-desc { color: #aaa; font-size: 14px; max-width: 400px; line-height: 1.5; }

        /* 底部控制条 */
        .controls { width: 100%; max-width: 600px; margin-top: 40px; }
        audio { width: 100%; border-radius: 30px; }

        /* 右侧：侧边栏歌单 */
        .sidebar { width: 300px; background: #0f0f15; border-left: 1px solid #333; display: flex; flex-direction: column; }
        .sidebar-header { padding: 20px; font-size: 18px; font-weight: bold; border-bottom: 1px solid #222; background: #181820; }
        .playlist { flex: 1; overflow-y: auto; padding: 0; margin: 0; list-style: none; }
        .playlist li {
            padding: 15px 20px; cursor: pointer; border-bottom: 1px solid #222; transition: 0.2s;
            display: flex; align-items: center;
        }
        .playlist li:hover { background: #222; }
        .playlist li.active { background: #333; color: #4CAF50; border-left: 3px solid #4CAF50; }
        .icon { margin-right: 10px; font-size: 12px; }

        /* 返回按钮 */
        .back-btn { position: absolute; top: 20px; left: 20px; color: #fff; text-decoration: none; background: rgba(0,0,0,0.5); padding: 8px 15px; border-radius: 20px; }
    </style>
</head>
<body>
    <a href="index.php" class="back-btn">← 返回首页</a>

    <div class="player-zone">
        <div class="cover-art" id="coverArt"></div>
        <div class="song-info">
            <div class="song-title" id="currentTitle">请选择一首歌曲</div>
            <div class="song-desc">
                这里是歌曲描述区域。你可以在这里添加歌词、专辑介绍或者心情记录。<br>
                支持高品质无损音频播放，由 Nginx 加速驱动。
            </div>
        </div>
        <div class="controls">
            <audio id="audioPlayer" controls controlsList="nodownload">
                您的浏览器不支持音频播放。
            </audio>
        </div>
    </div>

    <div class="sidebar">
        <div class="sidebar-header">🎵 播放列表 (<?php echo count($songs); ?>)</div>
        <ul class="playlist" id="playlist">
            <?php foreach ($songs as $index => $song): ?>
                <li onclick="playSong('<?php echo htmlspecialchars($song); ?>', this)">
                    <span class="icon">▶</span>
                    <?php echo htmlspecialchars($song); ?>
                </li>
            <?php endforeach; ?>
            <?php if (empty($songs)) echo "<li style='padding:20px; color:#666;'>暂无音乐，请去上传</li>"; ?>
        </ul>
    </div>

    <script>
        var audio = document.getElementById('audioPlayer');
        var cover = document.getElementById('coverArt');
        var title = document.getElementById('currentTitle');
        var listItems = document.querySelectorAll('.playlist li');

        function playSong(fileName, element) {
            // 1. 设置播放地址 (注意 type=music)
            audio.src = "stream.php?type=music&file=" + encodeURIComponent(fileName);
            
            // 2. 更新界面
            title.innerText = fileName;
            
            // 3. 高亮侧边栏
            listItems.forEach(item => item.classList.remove('active'));
            element.classList.add('active');
            
            // 4. 开始播放
            audio.play();
        }

        // 监听播放状态，控制唱片旋转
        audio.onplay = function() { cover.style.animationPlayState = 'running'; };
        audio.onpause = function() { cover.style.animationPlayState = 'paused'; };
        
        // 自动播放下一首 (可选功能)
        audio.onended = function() {
            var active = document.querySelector('.playlist li.active');
            if (active && active.nextElementSibling) {
                active.nextElementSibling.click();
            }
        };
        
    </script>
    <script>
            document.addEventListener('DOMContentLoaded', function() {
            var video = document.getElementById('audioPlayer');
            var links = document.querySelectorAll('a'); // 找到页面上所有的链接 
            links.forEach(function(link) {
                link.addEventListener('click', function(e) {
                    // 如果链接是 "#" 或者空，不管它
                    if(this.getAttribute('href') === '#' || !this.getAttribute('href')) return;

                    // 🛑 核心操作：在跳转前，物理掐断视频
                    if (video) {
                        video.pause();           // 1. 暂停播放
                        video.removeAttribute('src'); // 2. 移除视频源 (最关键！)
                        video.load();            // 3. 重置播放器，迫使浏览器立刻断开与 stream.php 的连接
                    }
                });
            });
        });
    </script>
</body>
</html>
