<?php
session_start(); // 启动 Session，区分不同用户

// 定义数据文件路径
$dataDir = __DIR__ . '/data';
$userHighscoreFile = $dataDir . '/user_highscore.json';
$leaderboardFile = $dataDir . '/leaderboard.json';

// 初始化：创建数据目录和缺失的 JSON 文件
if (!is_dir($dataDir)) {
    mkdir($dataDir, 0755, true);
}

// 初始化用户历史最高分文件
if (!file_exists($userHighscoreFile)) {
    file_put_contents($userHighscoreFile, json_encode([]));
}

// 初始化排行榜文件
if (!file_exists($leaderboardFile)) {
    file_put_contents($leaderboardFile, json_encode([]));
}

// 封装 JSON 文件读写函数
function readJsonFile($filePath) {
    $content = file_get_contents($filePath);
    return json_decode($content, true) ?: [];
}

function writeJsonFile($filePath, $data) {
    file_put_contents($filePath, json_encode($data, JSON_PRETTY_PRINT));
}

// 获取当前用户标识（基于 Session ID）
$userSessionId = session_id();

// 处理 AJAX 请求（根据 action 区分操作）
$action = $_POST['action'] ?? $_GET['action'] ?? '';
$result = ['status' => 'error', 'message' => '无效操作'];

switch ($action) {
    // 1. 获取用户当前历史最高分
    case 'get_user_highscore':
        $userHighscores = readJsonFile($userHighscoreFile);
        $userHighscore = $userHighscores[$userSessionId] ?? 0;
        $result = [
            'status' => 'success',
            'user_highscore' => $userHighscore
        ];
        break;

    // 2. 提交当前游戏分数（更新历史最高分 + 排行榜）
    case 'submit_score':
        $currentScore = (int)$_POST['current_score'] ?? 0;
        if ($currentScore < 0) {
            $result['message'] = '分数不能为负数';
            break;
        }

        // 更新用户历史最高分
        $userHighscores = readJsonFile($userHighscoreFile);
        $oldHighscore = $userHighscores[$userSessionId] ?? 0;
        if ($currentScore > $oldHighscore) {
            $userHighscores[$userSessionId] = $currentScore;
            writeJsonFile($userHighscoreFile, $userHighscores);
        }

        // 更新排行榜（保留前 10 名，同一用户只保留最高分）
        $leaderboard = readJsonFile($leaderboardFile);
        $userExists = false;
        $updatedLeaderboard = [];

        // 检查用户是否已在排行榜中，更新其最高分
        foreach ($leaderboard as $item) {
            if ($item['session_id'] === $userSessionId) {
                $userExists = true;
                if ($currentScore > $item['score']) {
                    $updatedLeaderboard[] = [
                        'session_id' => $userSessionId,
                        'username' => '玩家' . substr($userSessionId, 0, 6), // 简化用户名
                        'score' => $currentScore,
                        'update_time' => date('Y-m-d H:i:s')
                    ];
                } else {
                    $updatedLeaderboard[] = $item;
                }
            } else {
                $updatedLeaderboard[] = $item;
            }
        }

        // 若用户不在排行榜中，添加新记录
        if (!$userExists) {
            $updatedLeaderboard[] = [
                'session_id' => $userSessionId,
                'username' => '玩家' . substr($userSessionId, 0, 6),
                'score' => $currentScore,
                'update_time' => date('Y-m-d H:i:s')
            ];
        }

        // 按分数降序排序，保留前 10 名
        usort($updatedLeaderboard, function($a, $b) {
            return $b['score'] - $a['score'];
        });
        $finalLeaderboard = array_slice($updatedLeaderboard, 0, 10);
        writeJsonFile($leaderboardFile, $finalLeaderboard);

        $result = [
            'status' => 'success',
            'message' => '分数提交成功',
            'new_highscore' => $currentScore > $oldHighscore ? $currentScore : $oldHighscore
        ];
        break;

    // 3. 获取全局排行榜
    case 'get_leaderboard':
        $leaderboard = readJsonFile($leaderboardFile);
        // 补充排名信息
        $rankedLeaderboard = array_map(function($item, $index) {
            $item['rank'] = $index + 1;
            return $item;
        }, $leaderboard, array_keys($leaderboard));
        $result = [
            'status' => 'success',
            'leaderboard' => $rankedLeaderboard
        ];
        break;

    default:
        $result['message'] = '未知操作类型';
        break;
}

// 返回 JSON 格式响应
header('Content-Type: application/json; charset=utf-8');
echo json_encode($result);
exit;
?>