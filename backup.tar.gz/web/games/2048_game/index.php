<?php
session_start(); // 启动 Session，确保用户标识唯一
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP 2048 游戏（修复版）</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="game-container">
        <div class="game-header">
            <h1 class="game-title">2048</h1>
            <div class="score-panel">
                <div class="score-box">
                    <div class="label">当前分数</div>
                    <div class="value" id="current-score">0</div>
                </div>
                <div class="score-box">
                    <div class="label">历史最高分</div>
                    <div class="value" id="user-highscore">0</div>
                </div>
            </div>
        </div>

        <div class="game-board" id="game-board"></div>

        <div class="game-controls">
            <button class="btn" id="btn-up">↑</button>
            <button class="btn" id="btn-left">←</button>
            <button class="btn" id="btn-down">↓</button>
            <button class="btn" id="btn-right">→</button>
            <button class="btn" id="btn-reset">重置游戏</button>
        </div>
    </div>

    <div class="leaderboard">
        <h2 class="leaderboard-title">全局排行榜（前 10 名）</h2>
        <table class="leaderboard-table">
            <thead>
                <tr>
                    <th>排名</th>
                    <th>玩家</th>
                    <th>分数</th>
                    <th>更新时间</th>
                </tr>
            </thead>
            <tbody id="leaderboard-body">
                <!-- 动态渲染排行榜 -->
            </tbody>
        </table>
    </div>

    <p class="game-tip">提示：使用键盘方向键或页面按钮控制瓦片移动，相同数字瓦片合并为更高数字，达到 2048 即为胜利，无法移动时游戏结束</p>

    <script>
        // 游戏核心变量
        let grid = Array(4).fill().map(() => Array(4).fill(0));
        let currentScore = 0;
        let isGameOver = false;

        // 页面加载完成后初始化
        window.onload = function() {
            initGame();
            loadUserHighscore();
            loadLeaderboard();
            bindEvents();
        };

        // 1. 初始化游戏（生成初始瓦片，重置状态）
        function initGame() {
            grid = Array(4).fill().map(() => Array(4).fill(0));
            currentScore = 0;
            isGameOver = false;
            updateScoreDisplay();
            // 生成两个不重叠的初始瓦片
            generateRandomTile();
            generateRandomTile();
            renderGrid();
        }

        // 2. 生成随机瓦片（2 的概率 90%，4 的概率 10%，确保只在空位置生成）
        function generateRandomTile() {
            const emptyTiles = [];
            for (let i = 0; i < 4; i++) {
                for (let j = 0; j < 4; j++) {
                    if (grid[i][j] === 0) {
                        emptyTiles.push({x: i, y: j});
                    }
                }
            }

            if (emptyTiles.length === 0) return;
            const randomTile = emptyTiles[Math.floor(Math.random() * emptyTiles.length)];
            grid[randomTile.x][randomTile.y] = Math.random() < 0.9 ? 2 : 4;
        }

        // 3. 渲染棋盘到页面（同步网格数据与页面显示）
        function renderGrid() {
            const board = document.getElementById('game-board');
            board.innerHTML = '';

            for (let i = 0; i < 4; i++) {
                for (let j = 0; j < 4; j++) {
                    const tile = document.createElement('div');
                    tile.className = `tile ${grid[i][j] !== 0 ? `tile-${grid[i][j]}` : ''}`;
                    tile.textContent = grid[i][j] !== 0 ? grid[i][j] : '';
                    board.appendChild(tile);
                }
            }
        }

        // 4. 更新分数显示（同步当前分数到页面）
        function updateScoreDisplay() {
            document.getElementById('current-score').textContent = currentScore;
        }

        // 5. 核心修复：左移动逻辑（拆分「压缩」和「合并」步骤，避免索引错乱）
        function moveLeft() {
            // 先备份原网格，用于后续判断是否有变化
            const originalGrid = JSON.parse(JSON.stringify(grid));
            let newGrid = [];

            for (let row of grid) {
                // 步骤1：压缩行（去除空值，把有效数字移到左侧）
                let compressedRow = row.filter(num => num !== 0);
                
                // 步骤2：合并相同数字（修复索引问题，从左到右依次合并）
                for (let i = 0; i < compressedRow.length - 1; i++) {
                    if (compressedRow[i] === compressedRow[i + 1] && compressedRow[i] !== 0) {
                        // 合并数字，累加分数
                        compressedRow[i] *= 2;
                        currentScore += compressedRow[i];
                        // 移除右侧被合并的数字
                        compressedRow.splice(i + 1, 1);
                        // 合并后停留当前索引，防止连续合并（如 [2,2,2] → [4,2] 而非 [8]）
                        i++;
                    }
                }

                // 步骤3：补零填充（恢复为 4 列长度）
                while (compressedRow.length < 4) {
                    compressedRow.push(0);
                }

                newGrid.push(compressedRow);
            }

            // 步骤4：判断网格是否有变化，有变化才更新网格并生成新瓦片
            grid = newGrid;
            if (!isGridEqual(originalGrid, grid)) {
                generateRandomTile();
                renderGrid();
                updateScoreDisplay();
                checkGameOver();
                checkVictory(); // 新增胜利判断（达到 2048）
            }
        }

        // 6. 辅助函数：判断两个网格是否完全一致（用于检测移动是否有效）
        function isGridEqual(grid1, grid2) {
            return JSON.stringify(grid1) === JSON.stringify(grid2);
        }

        // 7. 核心修复：方向转换逻辑（基于左移，通过旋转棋盘实现上下右移动）
        // 旋转棋盘（顺时针 90 度，用于转换上下/右移动为左移动）
        function rotateGridClockwise(g) {
            const newGrid = Array(4).fill().map(() => Array(4).fill(0));
            for (let i = 0; i < 4; i++) {
                for (let j = 0; j < 4; j++) {
                    newGrid[j][3 - i] = g[i][j];
                }
            }
            return newGrid;
        }

        // 旋转棋盘（逆时针 90 度，用于还原棋盘）
        function rotateGridCounterClockwise(g) {
            const newGrid = Array(4).fill().map(() => Array(4).fill(0));
            for (let i = 0; i < 4; i++) {
                for (let j = 0; j < 4; j++) {
                    newGrid[3 - j][i] = g[i][j];
                }
            }
            return newGrid;
        }

        // 右移动（反转每行 → 左移 → 反转还原）
        function moveRight() {
            // 备份原网格
            const originalGrid = JSON.parse(JSON.stringify(grid));
            // 反转每行
            grid = grid.map(row => row.reverse());
            // 左移
            moveLeft();
            // 反转还原
            grid = grid.map(row => row.reverse());
            // 若有变化，重新渲染（修正原左移内的渲染逻辑，避免重复渲染）
            if (!isGridEqual(originalGrid, grid)) {
                renderGrid();
                updateScoreDisplay();
            }
        }

        // 上移动（逆时针旋转 → 左移 → 顺时针旋转还原）
        function moveUp() {
            const originalGrid = JSON.parse(JSON.stringify(grid));
            grid = rotateGridCounterClockwise(grid);
            moveLeft();
            grid = rotateGridClockwise(grid);
            if (!isGridEqual(originalGrid, grid)) {
                renderGrid();
                updateScoreDisplay();
            }
        }

        // 下移动（顺时针旋转 → 左移 → 逆时针旋转还原）
        function moveDown() {
            const originalGrid = JSON.parse(JSON.stringify(grid));
            grid = rotateGridClockwise(grid);
            moveLeft();
            grid = rotateGridCounterClockwise(grid);
            if (!isGridEqual(originalGrid, grid)) {
                renderGrid();
                updateScoreDisplay();
            }
        }

        // 8. 检查游戏胜利（达到 2048）
        function checkVictory() {
            for (let i = 0; i < 4; i++) {
                for (let j = 0; j < 4; j++) {
                    if (grid[i][j] === 2048) {
                        isGameOver = true;
                        alert(`恭喜你！成功合成 2048，最终分数：${currentScore}`);
                        submitScore(currentScore);
                        break;
                    }
                }
                if (isGameOver) break;
            }
        }

        // 9. 检查游戏结束（无空瓦片 + 无相邻可合并数字）
        function checkGameOver() {
            // 检查是否有空瓦片（有空则游戏未结束）
            for (let i = 0; i < 4; i++) {
                for (let j = 0; j < 4; j++) {
                    if (grid[i][j] === 0) return;
                }
            }

            // 检查横向相邻是否有可合并数字
            for (let i = 0; i < 4; i++) {
                for (let j = 0; j < 3; j++) {
                    if (grid[i][j] === grid[i][j + 1]) return;
                }
            }

            // 检查纵向相邻是否有可合并数字
            for (let j = 0; j < 4; j++) {
                for (let i = 0; i < 3; i++) {
                    if (grid[i][j] === grid[i + 1][j]) return;
                }
            }

            // 游戏结束
            isGameOver = true;
            alert(`游戏结束！你的最终分数：${currentScore}\n点击确定重置游戏`);
            submitScore(currentScore);
            initGame();
        }

        // 10. 绑定事件（键盘 + 页面按钮，防止游戏结束后操作）
        function bindEvents() {
            // 键盘方向键控制
            document.addEventListener('keydown', (e) => {
                if (isGameOver) return;
                // 阻止方向键的页面滚动默认行为
                if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.key)) {
                    e.preventDefault();
                }
                switch (e.key) {
                    case 'ArrowUp': moveUp(); break;
                    case 'ArrowDown': moveDown(); break;
                    case 'ArrowLeft': moveLeft(); break;
                    case 'ArrowRight': moveRight(); break;
                }
            });

            // 页面按钮控制
            document.getElementById('btn-up').addEventListener('click', () => !isGameOver && moveUp());
            document.getElementById('btn-left').addEventListener('click', () => !isGameOver && moveLeft());
            document.getElementById('btn-down').addEventListener('click', () => !isGameOver && moveDown());
            document.getElementById('btn-right').addEventListener('click', () => !isGameOver && moveRight());
            document.getElementById('btn-reset').addEventListener('click', () => {
                submitScore(currentScore);
                initGame();
            });
        }

        // 11. 后端数据交互：加载用户历史最高分
        function loadUserHighscore() {
            fetch('game_handler.php?action=get_user_highscore')
                .then(res => res.json())
                .then(data => {
                    if (data.status === 'success') {
                        document.getElementById('user-highscore').textContent = data.user_highscore;
                    }
                })
                .catch(err => console.error('加载历史最高分失败：', err));
        }

        // 12. 后端数据交互：提交当前分数（更新个人最高分和排行榜）
        function submitScore(score) {
            fetch('game_handler.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `action=submit_score&current_score=${score}`
            })
                .then(res => res.json())
                .then(data => {
                    if (data.status === 'success') {
                        document.getElementById('user-highscore').textContent = data.new_highscore;
                        loadLeaderboard(); // 提交分数后刷新排行榜
                    }
                })
                .catch(err => console.error('提交分数失败：', err));
        }

        // 13. 后端数据交互：加载全局排行榜
        function loadLeaderboard() {
            fetch('game_handler.php?action=get_leaderboard')
                .then(res => res.json())
                .then(data => {
                    if (data.status === 'success') {
                        const tbody = document.getElementById('leaderboard-body');
                        tbody.innerHTML = '';

                        data.leaderboard.forEach(item => {
                            const tr = document.createElement('tr');
                            tr.innerHTML = `
                                <td>${item.rank}</td>
                                <td>${item.username}</td>
                                <td>${item.score}</td>
                                <td>${item.update_time}</td>
                            `;
                            tbody.appendChild(tr);
                        });

                        // 若无排行榜数据
                        if (data.leaderboard.length === 0) {
                            const tr = document.createElement('tr');
                            tr.innerHTML = '<td colspan="4">暂无排行榜数据</td>';
                            tbody.appendChild(tr);
                        }
                    }
                })
                .catch(err => console.error('加载排行榜失败：', err));
        }
    </script>
</body>
</html>