<?php
// ==========================================
// 1. PHP 后端 API (玩家 + 房间管理)
// ==========================================
if (isset($_POST['action']) || isset($_GET['action'])) {
    header('Content-Type: application/json');
    header("Cache-Control: no-store, no-cache, must-revalidate");
    
    $p_file = 'players.json';
    $r_file = 'rooms.json';

    if (!file_exists($p_file)) file_put_contents($p_file, json_encode([], JSON_UNESCAPED_UNICODE));
    if (!file_exists($r_file)) file_put_contents($r_file, json_encode([], JSON_UNESCAPED_UNICODE));

    $players = json_decode(file_get_contents($p_file), true) ?? [];
    $rooms   = json_decode(file_get_contents($r_file), true) ?? [];
    $action  = $_REQUEST['action'] ?? '';

    // --- 玩家 API ---
    if ($action === 'get_player') {
        $name = $_REQUEST['name'] ?? '';
        if (!isset($players[$name])) {
            $players[$name] = ['name' => $name, 'beans' => 100000, 'wins' => 0, 'last_sign' => ''];
            file_put_contents($p_file, json_encode($players, JSON_UNESCAPED_UNICODE));
        }
        echo json_encode(['status' => 'success', 'data' => $players[$name]]);
        exit;
    }

    if ($action === 'update_player') {
        $name = $_POST['name'] ?? '';
        $delta = intval($_POST['beans_delta'] ?? 0);
        $signDate = $_POST['sign_date'] ?? null;
        if (isset($players[$name])) {
            $players[$name]['beans'] += $delta;
            if ($signDate) $players[$name]['last_sign'] = $signDate;
            if ($players[$name]['beans'] < 0) $players[$name]['beans'] = 0;
            file_put_contents($p_file, json_encode($players, JSON_UNESCAPED_UNICODE));
            echo json_encode(['status' => 'success', 'data' => $players[$name]]);
        }
        exit;
    }

    // --- 房间 API (核心修改) ---

    // 1. 创建房间
    if ($action === 'create_room') {
        $code = $_POST['room_code'];
        $host = $_POST['host_name'];
        
        $rooms[$code] = [
            'host' => $host, // 记录房主名字
            'players' => [
                ['name' => $host, 'type' => 'human', 'ready' => true]
            ],
            'status' => 'waiting',
            'updated_at' => time()
        ];
        
        // 清理过期房间
        foreach ($rooms as $k => $v) { if (time() - $v['updated_at'] > 3600) unset($rooms[$k]); }
        
        file_put_contents($r_file, json_encode($rooms, JSON_UNESCAPED_UNICODE));
        echo json_encode(['status' => 'success']);
        exit;
    }

    // 2. 轮询/加入房间
    if ($action === 'poll_room') {
        $code = $_POST['room_code'];
        $me   = $_POST['my_name'] ?? '';

        // 如果房间不存在（被销毁了）
        if (!isset($rooms[$code])) {
            echo json_encode(['status' => 'dissolved', 'msg' => '房间已解散']);
            exit;
        }

        // 自动加入逻辑
        $inRoom = false;
        foreach($rooms[$code]['players'] as $p) {
            if ($p['name'] === $me) $inRoom = true;
        }
        
        // 如果不在房间且没满，且不是刷新请求，加入
        if (!$inRoom && $me !== '' && count($rooms[$code]['players']) < 3) {
            $rooms[$code]['players'][] = ['name' => $me, 'type' => 'human', 'ready' => true];
            $rooms[$code]['updated_at'] = time();
            file_put_contents($r_file, json_encode($rooms, JSON_UNESCAPED_UNICODE));
        }

        echo json_encode(['status' => 'success', 'data' => $rooms[$code]]);
        exit;
    }

    // 3. 添加 AI
    if ($action === 'add_ai') {
        $code = $_POST['room_code'];
        if (isset($rooms[$code]) && count($rooms[$code]['players']) < 3) {
            $rooms[$code]['players'][] = ['name' => 'AI机器人', 'type' => 'ai', 'ready' => true];
            file_put_contents($r_file, json_encode($rooms, JSON_UNESCAPED_UNICODE));
            echo json_encode(['status' => 'success']);
        }
        exit;
    }

    // 4. 离开/销毁房间 (🌟 新增)
    if ($action === 'leave_room') {
        $code = $_POST['room_code'];
        $name = $_POST['my_name'];

        if (isset($rooms[$code])) {
            // 如果是房主离开 -> 销毁房间
            if ($rooms[$code]['host'] === $name) {
                unset($rooms[$code]);
            } else {
                // 如果是普通玩家 -> 移除自己
                $newPlayers = [];
                foreach ($rooms[$code]['players'] as $p) {
                    if ($p['name'] !== $name) $newPlayers[] = $p;
                }
                $rooms[$code]['players'] = $newPlayers;
            }
            file_put_contents($r_file, json_encode($rooms, JSON_UNESCAPED_UNICODE));
        }
        echo json_encode(['status' => 'success']);
        exit;
    }

    exit;
}

include $_SERVER['DOCUMENT_ROOT'] . '/check.php'; 
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>斗地主 (联机大厅版)</title>
    <link rel="icon" type="image/png" href="/title.png">
    <style>
        /* === 样式表 === */
        body { margin: 0; background: #2c3e50; font-family: 'Segoe UI', sans-serif; height: 100vh; overflow: hidden; display: flex; user-select: none; }
        .sidebar { width: 200px; background: #fff; padding: 20px; display: flex; flex-direction: column; gap: 10px; border-right: 1px solid #ccc; z-index: 50; }
        .sidebar-item { padding: 12px; color: #333; text-decoration: none; border-radius: 6px; display: block; }
        .sidebar-item:hover, .sidebar-item.active { background: #e6f7ff; color: #1890ff; font-weight: bold; }
        .user-info-box { margin-top: auto; padding: 15px; background: #f8f9fa; border-radius: 8px; font-size: 13px; color: #555; }
        .bean-count { color: #f1c40f; font-weight: bold; font-size: 18px; display: block; margin: 5px 0; }

        .stage { flex: 1; position: relative; overflow: hidden; background: linear-gradient(135deg, #1e3c72, #2a5298); }
        .scene { display: none; width: 100%; height: 100%; position: relative; }
        .scene.active { display: block; }

        /* 菜单/大厅 */
        .center-box { position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); text-align: center; color: white; width: 420px; }
        .glass-panel { background: rgba(255,255,255,0.1); backdrop-filter: blur(10px); padding: 40px; border-radius: 20px; box-shadow: 0 10px 30px rgba(0,0,0,0.3); }
        .big-btn { width: 100%; padding: 15px; font-size: 16px; border-radius: 50px; border: none; cursor: pointer; background: #f1c40f; color: #333; font-weight: bold; margin-bottom: 10px; transition:0.1s; }
        .big-btn:hover { transform: scale(1.05); }
        .big-btn:disabled { background: #95a5a6; cursor: not-allowed; transform: none; }
        .input-code { width: 100%; padding: 12px; border-radius: 50px; border: 2px solid rgba(255,255,255,0.3); background: rgba(0,0,0,0.3); color: white; text-align: center; font-size: 18px; margin-bottom: 10px; outline: none; }

        /* 房主标签样式 */
        .host-badge { background: #e67e22; color: white; padding: 2px 6px; border-radius: 4px; font-size: 12px; margin-left: 8px; font-weight: bold; }
        .player-slot { padding: 10px; border-bottom: 1px solid rgba(255,255,255,0.1); display: flex; align-items: center; gap: 10px; text-align: left; }
        .slot-avatar { width: 35px; height: 35px; background: #ddd; border-radius: 50%; }

        /* 游戏内元素 */
        .base-card-area { position: absolute; top: 10px; left: 50%; transform: translateX(-50%); display: flex; gap: 10px; z-index: 200; background: rgba(0,0,0,0.5); padding: 10px 20px; border-radius: 0 0 15px 15px; }
        .multiplier-float { position: absolute; top: 20px; right: 20px; color: rgba(255,255,255,0.8); font-size: 14px; text-align: right; z-index: 5; pointer-events: none; }
        
        .player-seat { position: absolute; text-align: center; color: white; width: 120px; z-index: 20; }
        .seat-top { top: 100px; left: 10%; }
        .seat-right { top: 100px; right: 10%; }
        .avatar { width: 60px; height: 60px; border-radius: 50%; border: 3px solid white; background: #ccc; margin: 0 auto; background-size: cover; position: relative; }
        .landlord-icon { position: absolute; bottom: -5px; right: -5px; width: 24px; height: 24px; background: #f1c40f; border-radius: 50%; border: 2px solid white; font-size: 14px; line-height: 22px; color: #d35400; font-weight: bold; display: none; z-index: 25; }
        .identity-tag { position: absolute; top: -5px; right: -10px; background: #f1c40f; color: #d35400; font-size: 10px; padding: 2px 6px; border-radius: 8px; border: 2px solid white; font-weight: bold; z-index: 30; white-space: nowrap; display: none; }
        .bean-tag { font-size: 12px; background: rgba(0,0,0,0.5); padding: 2px 8px; border-radius: 10px; margin-top: 5px; display: inline-block; color: #f1c40f; }
        .bubble { background: rgba(255,255,255,0.9); color: #333; padding: 5px 10px; border-radius: 10px; margin-top: 5px; min-height: 20px; font-size: 12px; display: inline-block; white-space: nowrap; font-weight: bold; }

        .played-area { position: absolute; height: 100px; display: flex; align-items: center; pointer-events: none; z-index: 15; }
        .played-top { top: 130px; left: 18%; } 
        .played-right { top: 130px; right: 18%; flex-direction: row-reverse; } 
        .played-me { bottom: 260px; left: 50%; transform: translateX(-50%); } 

        .my-area { position: absolute; bottom: 20px; left: 0; right: 0; height: 180px; display: flex; justify-content: center; pointer-events: none; z-index: 100; }
        .hand-wrapper { position: relative; width: 800px; height: 100%; pointer-events: auto; }

        .card { width: 105px; height: 150px; background: white; border-radius: 8px; box-shadow: -2px 2px 6px rgba(0,0,0,0.4); position: absolute; bottom: 0; display: flex; flex-direction: column; padding: 5px; box-sizing: border-box; cursor: pointer; transition: transform 0.2s, bottom 0.2s; font-family: Arial; font-weight: bold; font-size: 24px; }
        .card.small { width: 60px; height: 85px; font-size: 16px; padding: 2px; position: relative; bottom: auto; margin: 0; cursor: default; }
        .card.played { width: 80px; height: 115px; font-size: 18px; position: relative; margin-left: -50px; box-shadow: 0 2px 5px rgba(0,0,0,0.2); bottom: auto; cursor: default; }
        .card.played:first-child { margin-left: 0; }
        .card.back { background: #34495e; background-image: repeating-linear-gradient(45deg, rgba(255,255,255,0.1) 0, rgba(255,255,255,0.1) 10px, transparent 10px, transparent 20px); color: transparent; border: 2px solid white; display: block; }
        .card.red { color: #e74c3c; } .card.black { color: #2c3e50; }
        .card.selected { bottom: 20px !important; border: 2px solid #3498db; }
        .card:hover { bottom: 10px; z-index: 999; }
        .card.small:hover, .card.played:hover { bottom: auto; transform: none; }

        .btn-group { position: absolute; bottom: 240px; left: 50%; transform: translateX(-50%); display: flex; gap: 20px; z-index: 10000; background: rgba(0,0,0,0.3); padding: 10px 20px; border-radius: 40px; }
        .g-btn { border: none; padding: 10px 35px; border-radius: 30px; font-size: 16px; font-weight: bold; cursor: pointer; box-shadow: 0 4px 10px rgba(0,0,0,0.3); transition: 0.1s; }
        .g-btn:active { transform: scale(0.95); }
        .btn-play { background: #3498db; color: white; }
        .btn-pass { background: #95a5a6; color: white; }
        .btn-rob { background: #e67e22; color: white; }
    </style>
</head>
<body>

<div class="sidebar">
    <a href="/games.php" class="sidebar-item">🏠 回到大厅</a>
    <div class="sidebar-item active">🃏 斗地主</div>
    <div class="user-info-box">
        <div>当前玩家: <?php echo $_SESSION['username']; ?></div>
        <span class="bean-count" id="sidebar-beans">加载中...</span>
        <button id="btn-sign" style="width:100%; margin-top:10px; cursor:pointer;" onclick="Player.signIn()">📅 每日签到</button>
    </div>
</div>

<div class="stage">
    <div id="scene-menu" class="scene active">
        <div class="center-box glass-panel">
            <h1 style="font-size: 50px; margin: 0 0 30px 0;">🃏 欢乐斗地主</h1>
            <button class="big-btn" onclick="Lobby.create()">👑 创建房间</button>
            <div style="height: 1px; background: rgba(255,255,255,0.2); margin: 20px 0;"></div>
            <input type="text" id="join-input" class="input-code" placeholder="输入6位房间号" maxlength="6">
            <button class="big-btn" style="background:transparent; border:2px solid white; color:white;" onclick="Lobby.join()">🚀 加入房间</button>
        </div>
    </div>

    <div id="scene-lobby" class="scene">
        <div class="center-box glass-panel">
            <h3>房间号: <span id="room-code">------</span></h3>
            <div class="player-list" id="lobby-list" style="margin: 20px 0; text-align: left;"></div>
            <div style="text-align:left; margin-bottom:20px;">
                <label style="color:#ccc;">底注设置:</label>
                <input type="number" id="input-base-score" value="200" min="100" step="100" style="width:80px; padding:5px; border-radius:5px; border:none;">
            </div>
            <div style="display:flex; gap:10px; flex-wrap:wrap;">
                <button class="big-btn" id="btn-add-ai" style="background:#95a5a6; font-size:14px; flex:1;" onclick="Lobby.addAI()">+ AI</button>
                <button class="big-btn" id="btn-start-game" style="flex:2;" disabled onclick="Lobby.start()">开始游戏</button>
                <button class="big-btn" style="background:transparent; border:2px solid #e74c3c; color:#e74c3c; width:100%; margin-top:5px;" onclick="Lobby.leave()">❌ 退出房间</button>
            </div>
        </div>
    </div>

    <div id="scene-game" class="scene">
        <div class="base-card-area" id="base-cards-container"></div>

        <div style="position: absolute; top: 10px; right: 20px; color: rgba(255,255,255,0.8); text-align: right; z-index: 5;">
            <div>底注: <span id="game-base">200</span></div>
            <div>倍率: <span id="game-mul" style="font-size:24px; color:#f1c40f; font-weight:bold;">x1</span></div>
        </div>

        <div id="played-ai1" class="played-area played-top"></div>
        <div id="played-ai2" class="played-area played-right"></div>
        <div id="played-me" class="played-area played-me"></div>

        <div class="player-seat seat-top">
            <div class="avatar" style="background-image: url('https://api.dicebear.com/7.x/avataaars/svg?seed=Robot1');">
                <div class="identity-tag" id="identity-ai1">农民</div>
                <div class="landlord-icon" id="icon-ai1">地主</div>
            </div>
            <div class="bean-tag">💰 1000</div>
            <div class="bubble" id="msg-ai1">...</div>
            <div style="font-size:12px; margin-top:5px; background:rgba(0,0,0,0.5); padding:2px 5px; border-radius:10px;">剩 <span id="count-ai1">17</span> 张</div>
        </div>

        <div class="player-seat seat-right">
            <div class="avatar" style="background-image: url('https://api.dicebear.com/7.x/avataaars/svg?seed=Robot2');">
                <div class="identity-tag" id="identity-ai2">农民</div>
                <div class="landlord-icon" id="icon-ai2">地</div>
            </div>
            <div class="bean-tag">💰 1000</div>
            <div class="bubble" id="msg-ai2">...</div>
            <div style="font-size:12px; margin-top:5px; background:rgba(0,0,0,0.5); padding:2px 5px; border-radius:10px;">剩 <span id="count-ai2">17</span> 张</div>
        </div>
        
        <div style="position: absolute; bottom: 200px; left: 20px; color: white; z-index: 50;">
            <div class="avatar" style="width:50px;height:50px;background-image: url('https://api.dicebear.com/7.x/avataaars/svg?seed=Me');display:inline-block;vertical-align:middle;">
                <div class="identity-tag" id="identity-me">农民</div>
                <div class="landlord-icon" id="icon-me" style="display:none; right:-5px; bottom:-5px;">地</div>
            </div>
            <div style="display:inline-block; vertical-align:middle; margin-left:10px;">
                <div style="font-weight:bold;">我自己</div>
                <div class="bean-tag" id="bean-me">💰 ...</div>
                <div style="font-size:12px; margin-top:5px;">剩 <span id="count-me">17</span> 张</div>
            </div>
        </div>

        <div class="btn-group" id="controls-bid" style="display:none;">
            <button class="g-btn btn-pass" onclick="Game.bid(0)">不抢</button>
            <button class="g-btn btn-rob" onclick="Game.bid(1)">抢地主 (x2)</button>
        </div>

        <div class="btn-group" id="controls-play" style="display:none;">
            <button class="g-btn btn-pass" onclick="Game.pass()">不出</button>
            <button class="g-btn btn-play" onclick="Game.play()">出牌</button>
        </div>

        <div class="my-area">
            <div class="hand-wrapper" id="my-hand"></div>
        </div>
    </div>
</div>

<script>
// === 0. 玩家数据 ===
const Player = {
    username: "<?php echo $_SESSION['username']; ?>",
    beans: 0,
    
    init: async function() {
        try {
            const fd = new FormData(); fd.append('action', 'get_player'); fd.append('name', this.username);
            const res = await fetch('?', { method: 'POST', body: fd });
            const json = await res.json();
            if(json.status === 'success') {
                this.beans = parseInt(json.data.beans);
                this.updateUI();
                const today = new Date().toISOString().split('T')[0];
                const btn = document.getElementById('btn-sign');
                if(json.data.last_sign === today) { btn.disabled = true; btn.innerText = "已签到"; }
            }
        } catch(e) { console.error(e); }
    },
    updateBeans: async function(delta) {
        this.beans += delta; this.updateUI();
        const fd = new FormData(); fd.append('action', 'update_player'); fd.append('name', this.username); fd.append('beans_delta', delta);
        await fetch('?', { method: 'POST', body: fd });
    },
    signIn: async function() {
        const today = new Date().toISOString().split('T')[0];
        const fd = new FormData(); fd.append('action', 'update_player'); fd.append('name', this.username); fd.append('beans_delta', 10000); fd.append('sign_date', today);
        const res = await fetch('?', { method: 'POST', body: fd });
        const json = await res.json();
        if(json.status === 'success') {
            this.beans = json.data.beans; this.updateUI(); alert("签到成功！+10000 豆");
            document.getElementById('btn-sign').disabled = true; document.getElementById('btn-sign').innerText = "已签到";
        }
    },
    updateUI: function() {
        const text = "💰 " + this.beans.toLocaleString();
        document.getElementById('sidebar-beans').innerText = text;
        document.getElementById('bean-me').innerText = text;
    }
};
Player.init();

// === 1. 规则引擎 ===
const RuleEngine = {
    getVal: function(c) {
        if(!c) return 0;
        if(c.rank==='Small')return 16; if(c.rank==='Big')return 17;
        const m={'3':3,'4':4,'5':5,'6':6,'7':7,'8':8,'9':9,'10':10,'J':11,'Q':12,'K':13,'A':14,'2':15};
        return m[c.rank] || 0;
    },
    analyze: function(cards) {
        if (!cards || !cards.length) return { t: 'invalid', v: 0 };
        const vals = cards.map(c => this.getVal(c)).sort((a, b) => a - b);
        const len = vals.length;
        const counts = {}; vals.forEach(v => counts[v] = (counts[v] || 0) + 1);
        const keys = Object.keys(counts).map(Number).sort((a,b)=>a-b);
        const maxCount = Math.max(...Object.values(counts));

        if (len === 2 && vals[0] === 16 && vals[1] === 17) return { t: 'rocket', v: 999 };
        if (len === 4 && maxCount === 4) return { t: 'bomb', v: keys.find(k => counts[k]===4) }; 
        if (len === 1) return { t: 'single', v: vals[0] };
        if (len === 2 && maxCount === 2) return { t: 'pair', v: vals[0] };
        if (len === 3 && maxCount === 3) return { t: 'triple', v: vals[0] };
        if (len === 4 && maxCount === 3) return { t: '3+1', v: Number(keys.find(k => counts[k]===3)) };
        if (len === 5 && maxCount === 3 && keys.length === 2) return { t: '3+2', v: Number(keys.find(k => counts[k]===3)) };
        if (len >= 5 && maxCount === 1 && vals[len-1] < 15) {
            let isStraight = true; for(let i=0; i<len-1; i++) if(vals[i+1] !== vals[i]+1) isStraight = false;
            if(isStraight) return { t: 'straight', v: vals[0] };
        }
        return { t: 'invalid', v: 0 };
    },
    canBeat: function(curr, last) {
        if (!last || !last.length) { return this.analyze(curr).t !== 'invalid'; }
        const c = this.analyze(curr), l = this.analyze(last);
        if (c.t === 'invalid') return false;
        if (c.t === 'rocket') return true;
        if (l.t === 'rocket') return false;
        if (c.t === 'bomb') { if (l.t !== 'bomb') return true; return c.v > l.v; }
        if (c.t === l.t && curr.length === last.length) return c.v > l.v;
        return false;
    }
};

// === 2. 房间逻辑 (修复版) ===
const Lobby = {
    roomCode: null,
    timer: null,
    myRole: 'guest',

    create: async function() {
        const code = Math.floor(100000 + Math.random() * 900000);
        const myName = "<?php echo $_SESSION['username']; ?>";
        const fd = new FormData(); fd.append('action', 'create_room'); fd.append('room_code', code); fd.append('host_name', myName);
        await fetch('?', { method: 'POST', body: fd });
        this.enterLobby(code, 'host');
    },
    join: function() {
        const code = document.getElementById('join-input').value;
        if (code.length !== 6) return alert("请输入 6 位房间号");
        this.enterLobby(code, 'guest');
    },
    enterLobby: function(code, role) {
        this.roomCode = code; this.myRole = role;
        this.switch('lobby');
        document.getElementById('room-code').innerText = code;
        document.getElementById('btn-add-ai').style.display = (role === 'host' ? 'inline-block' : 'none');
        
        this.poll();
        if (this.timer) clearInterval(this.timer);
        this.timer = setInterval(() => this.poll(), 1500);
    },
    poll: async function() {
        if (!this.roomCode) return;
        const myName = "<?php echo $_SESSION['username']; ?>";
        try {
            const fd = new FormData(); fd.append('action', 'poll_room'); fd.append('room_code', this.roomCode); fd.append('my_name', myName);
            const res = await fetch('?', { method: 'POST', body: fd });
            const json = await res.json();
            if (json.status === 'success') {
                this.render(json.data.players, json.data.host);
            } else {
                alert(json.msg || "房间已解散"); this.leave(false);
            }
        } catch (e) {}
    },
    addAI: async function() {
        const fd = new FormData(); fd.append('action', 'add_ai'); fd.append('room_code', this.roomCode);
        await fetch('?', { method: 'POST', body: fd });
        this.poll();
        document.getElementById('input-base-score').value = 200;
        document.getElementById('input-base-score').disabled = true;
    },
    // 🌟 离开房间
    leave: async function(notifyServer = true) {
        clearInterval(this.timer);
        if(notifyServer && this.roomCode) {
            const fd = new FormData();
            fd.append('action', 'leave_room');
            fd.append('room_code', this.roomCode);
            fd.append('my_name', "<?php echo $_SESSION['username']; ?>");
            await fetch('?', { method: 'POST', body: fd });
        }
        this.roomCode = null;
        this.switch('menu');
    },
    render: function(players, hostName) {
        const list = document.getElementById('lobby-list'); list.innerHTML = '';
        players.forEach(p => {
            const color = p.type === 'ai' ? '#95a5a6' : '#f1c40f';
            const roleTag = (p.name === hostName) ? '<span class="host-badge">房主</span>' : '';
            list.innerHTML += `<div class="player-slot"><div class="slot-avatar" style="background:${color}"></div><div style="flex:1">${p.name} ${roleTag}</div><span style="color:#2ecc71">已准备</span></div>`;
        });
        for (let i = players.length; i < 3; i++) {
            list.innerHTML += `<div class="player-slot" style="opacity:0.5; border:1px dashed #ccc;"><div class="slot-avatar" style="background:#eee"></div><div style="flex:1">等待加入...</div></div>`;
        }
        const btn = document.getElementById('btn-start-game');
        if (players.length === 3) {
            if (this.myRole === 'host') {
                btn.disabled = false; btn.innerText = "开始游戏"; btn.style.background = "#3498db";
            } else {
                btn.disabled = true; btn.innerText = "等待房主开始...";
            }
        } else {
            btn.disabled = true; btn.innerText = `等待加入 (${players.length}/3)`;
        }
    },
    start: function() {
        clearInterval(this.timer);
        const score = parseInt(document.getElementById('input-base-score').value) || 200;
        if (Player.beans < score) return alert("豆子不足 " + score + "，无法开局！");
        this.switch('game');
        
        // 最后一次获取玩家列表
        const fd = new FormData(); fd.append('action', 'poll_room'); fd.append('room_code', this.roomCode);
        fetch('?', { method: 'POST', body: fd }).then(r=>r.json()).then(d => Game.init(score, d.data.players));
    },
    switch: function(name) {
        document.querySelectorAll('.scene').forEach(el => el.classList.remove('active'));
        document.getElementById('scene-' + name).classList.add('active');
    }
};

// === 3. 游戏核心逻辑 ===
const Game = {
    hands: { me: [], ai1: [], ai2: [] },
    bottomCards: [],
    turn: 'me', landlord: null, multiplier: 1, baseScore: 200,
    lastPlay: null, passCount: 0, timer: null,

    init: function(score, players) {
        if(this.timer) clearTimeout(this.timer);
        this.baseScore = score;
        document.getElementById('btn-sign').style.display = 'none';
        this.multiplier = 1; this.updateMultiplierUI();
        this.clearAllPlayedCards(); this.hideIcons();

        this.dealCards();
        this.renderHand();
        this.renderBottomCards(false);

        const humanCount = players.filter(p => p.type === 'human').length;
        if (humanCount === 1) {
            this.landlord = 'me'; this.multiplier = 2; this.updateMultiplierUI();
            setTimeout(() => { alert("单人模式：你是地主，倍率 x2"); this.startPlayingPhase(); }, 500);
        } else {
            this.status = 'bidding'; this.turn = 'me'; this.checkTurn();
        }
    },
    dealCards: function() {
        const suits = ['♠','♥','♣','♦'];
        const ranks = ['3','4','5','6','7','8','9','10','J','Q','K','A','2'];
        let deck = [];
        ranks.forEach(r => suits.forEach(s => deck.push({rank:r, suit:s, color:(s==='♥'||s==='♦')?'red':'black', selected:false})));
        deck.push({rank:'Small', suit:'', color:'black', display:'小王', selected:false});
        deck.push({rank:'Big', suit:'', color:'red', display:'大王', selected:false});
        deck.sort(() => Math.random() - 0.5);
        this.hands.me = deck.slice(0, 17);
        this.hands.ai1 = deck.slice(17, 34);
        this.hands.ai2 = deck.slice(34, 51);
        this.bottomCards = deck.slice(51, 54);
        this.sortAll();
    },
    sortAll: function() { ['me', 'ai1', 'ai2'].forEach(p => this.hands[p].sort((a,b) => RuleEngine.getVal(b) - RuleEngine.getVal(a))); },
    startPlayingPhase: function() {
        this.status = 'playing'; this.turn = this.landlord;
        this.renderBottomCards(true);
        this.hands[this.landlord].push(...this.bottomCards);
        this.sortAll();
        if(this.landlord === 'me') this.renderHand();
        ['me', 'ai1', 'ai2'].forEach(p => {
            document.getElementById(`count-${p}`).innerText = this.hands[p].length;
            const tag = document.getElementById(`identity-${p}`);
            tag.style.display = 'block';
            tag.innerText = (p === this.landlord) ? '地主' : '农民';
            tag.style.background = (p === this.landlord) ? '#e74c3c' : '#f1c40f';
        });
        document.getElementById(`icon-${this.landlord}`).style.display = 'block';
        this.lastPlay = null; this.passCount = 0;
        this.checkTurn();
    },
    checkTurn: function() {
        if (this.status === 'bidding') {
            document.getElementById('controls-bid').style.display = 'flex';
        } else {
            if (this.passCount >= 2) {
                this.clearAllPlayedCards(); this.lastPlay = null; this.passCount = 0;
            }
            if (this.turn === 'me') {
                document.getElementById('controls-play').style.display = 'flex';
                const btnPass = document.querySelector('#controls-play .btn-pass');
                btnPass.disabled = (this.lastPlay === null);
                btnPass.style.opacity = btnPass.disabled ? 0.5 : 1;
            } else {
                document.getElementById('controls-play').style.display = 'none';
                this.timer = setTimeout(() => this.aiMove(), 1500);
            }
        }
    },
    bid: function(val) {
        document.getElementById('controls-bid').style.display = 'none';
        if(val) { this.landlord = 'me'; this.multiplier *= 2; }
        else { alert("你放弃了，AI接管地主"); this.landlord = 'ai1'; }
        this.updateMultiplierUI(); this.startPlayingPhase();
    },
    play: function() {
        const selected = this.hands.me.filter(c => c.selected);
        if (!selected.length) return alert("请选牌");
        let lastCards = (this.lastPlay && this.passCount < 2) ? this.lastPlay.cards : null;
        if (!RuleEngine.canBeat(selected, lastCards)) return alert("牌序错误 (管不上)");
        this.hands.me = this.hands.me.filter(c => !c.selected);
        this.renderHand(); this.finishTurn('me', selected);
    },
    pass: function() { this.finishTurn('me', null); },
    finishTurn: function(p, cards) {
        const bubble = document.getElementById(`msg-${p}`);
        if(cards) {
            this.passCount = 0; this.lastPlay = { player: p, cards: cards };
            this.renderPlayedCards(p, cards);
            if(bubble) bubble.innerText = "";
            const t = RuleEngine.analyze(cards).t;
            if(t === 'bomb') this.multiplier *= 4; if(t === 'rocket') this.multiplier *= 8;
            this.updateMultiplierUI();
            if (this.hands[p].length === 0) return this.gameOver(p);
        } else {
            this.passCount++; document.getElementById(`played-${p}`).innerHTML = '';
            if(bubble) bubble.innerText = "不出";
        }
        if(p !== 'me') document.getElementById(`count-${p}`).innerText = this.hands[p].length;
        const next = {'me':'ai1', 'ai1':'ai2', 'ai2':'me'};
        this.turn = next[p]; this.checkTurn();
    },
    aiMove: function() {
        const p = this.turn; const hand = this.hands[p];
        const lastCards = (this.lastPlay && this.passCount < 2) ? this.lastPlay.cards : null;
        let toPlay = null;
        if (!lastCards) { toPlay = [hand[hand.length-1]]; }
        else {
            const t = RuleEngine.analyze(lastCards).t;
            const v = RuleEngine.getVal(lastCards[0]);
            if (t === 'single') { const c = hand.find(card => RuleEngine.getVal(card) > v); if(c) toPlay = [c]; }
            else if (t === 'pair') {
                for(let i=0; i<hand.length-1; i++) {
                    if (hand[i].rank === hand[i+1].rank && RuleEngine.getVal(hand[i]) > v) { toPlay = [hand[i], hand[i+1]]; break; }
                }
            }
        }
        if (toPlay) { this.hands[p] = hand.filter(h => !toPlay.includes(h)); this.finishTurn(p, toPlay); }
        else { this.finishTurn(p, null); }
    },
    gameOver: function(winner) {
        const win = (winner === this.landlord); const amILandlord = (this.landlord === 'me');
        const score = this.baseScore * this.multiplier;
        let delta = 0;
        if (win) {
            delta = amILandlord ? score * 2 : -score;
            alert(amILandlord ? `地主胜利！+${delta}豆` : `地主胜利！-${Math.abs(delta)}豆`);
        } else {
            delta = amILandlord ? -score * 2 : score;
            alert(amILandlord ? `农民胜利！-${Math.abs(delta)}豆` : `农民胜利！+${delta}豆`);
        }
        Player.updateBeans(delta);
        document.getElementById('btn-sign').style.display = 'block';
        location.reload();
    },
    renderHand: function() {
        const div = document.getElementById('my-hand'); div.innerHTML = '';
        const step = this.hands.me.length > 15 ? 35 : 45;
        const startX = 400 - (this.hands.me.length * step) / 2;
        this.hands.me.forEach((c, i) => {
            let el = document.createElement('div');
            el.className = `card ${c.color} ${c.selected?'selected':''}`;
            el.innerHTML = `<div>${c.rank==='Small'?'小王':(c.rank==='Big'?'大王':c.rank)}</div><div style="font-size:30px;margin-top:10px">${c.suit}</div>`;
            el.style.left = (startX + i * step) + 'px'; el.style.zIndex = i;
            el.onclick = () => { c.selected = !c.selected; this.renderHand(); };
            div.appendChild(el);
        });
    },
    renderBottomCards: function(reveal) {
        const div = document.getElementById('base-cards-container'); div.innerHTML = '';
        this.bottomCards.forEach(c => {
            let el = document.createElement('div');
            if(reveal) {
                el.className = `card small ${c.color}`;
                el.innerHTML = `<div>${c.rank==='Small'?'小王':(c.rank==='Big'?'大王':c.rank)}</div><div>${c.suit}</div>`; el.style.background = 'white';
            } else { el.className = 'card small back'; }
            div.appendChild(el);
        });
    },
    renderPlayedCards: function(p, cards) {
        const div = document.getElementById(`played-${p}`); div.innerHTML = ''; if(!cards) return;
        cards.forEach((c, i) => {
            let el = document.createElement('div'); el.className = `card played ${c.color}`;
            el.innerHTML = `<div>${c.rank==='Small'?'小王':(c.rank==='Big'?'大王':c.rank)}</div><div>${c.suit}</div>`; el.style.zIndex = i;
            div.appendChild(el);
        });
    },
    clearAllPlayedCards: function() {
        ['me', 'ai1', 'ai2'].forEach(p => {
            document.getElementById(`played-${p}`).innerHTML = '';
            const msg = document.getElementById(`msg-${p}`); if(msg) msg.innerText = '';
        });
    },
    hideIcons: function() { ['me', 'ai1', 'ai2'].forEach(p => document.getElementById(`identity-${p}`).style.display = 'none'); },
    updateMultiplierUI: function() { document.getElementById('game-mul').innerText = "x" + this.multiplier; }
};
</script>
</body>
</html>