<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$identity_html = '0';

if (!isset($_SESSION['user_id'])) {

} else {
    $role = isset($_SESSION['role']) ? $_SESSION['role'] : 'user';
    $username = isset($_SESSION['username'])? $_SESSION['username'] : '未知用户';

    if ($role === 'admin') {
        $identity_html = '<span style="color: black;">当前身份:<span style="color: red;">管理员</span>';
    } else {
        $identity_html = '<span style="color: black;">用户:<span style="color: green;">'.$username.'</span>';
    }
}
?>