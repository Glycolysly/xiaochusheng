<?php
// reader.php - 电子书阅读器页面

session_start();
// 1. 安全检查
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}
// 释放 Session 锁，避免卡顿
session_write_close();

// 2. 获取书籍参数
$book_file = isset($_GET['book']) ? $_GET['book'] : '';
if (empty($book_file)) {
    header("Location: book.php");
    exit;
}

// 3. 验证书籍文件
$book_dir = 'books/';
$book_path = $book_dir . $book_file;
if (!file_exists($book_path)) {
    echo "<script>alert('书籍文件不存在！');window.location.href='book.php';</script>";
    exit;
}

$book_name = pathinfo($book_file, PATHINFO_FILENAME);
$book_type = strtolower(pathinfo($book_file, PATHINFO_EXTENSION));

// 4. 扫描所有书籍（用于导航）
$files = glob($book_dir . '*.{pdf,epub,txt}', GLOB_BRACE);
$book_list = [];
$current_index = -1;

if ($files) {
    foreach ($files as $index => $file) {
        $filename = basename($file);
        $name_without_ext = pathinfo($file, PATHINFO_FILENAME);

        $book_list[] = [
            'file' => $filename,
            'name' => $name_without_ext,
            'type' => strtolower(pathinfo($file, PATHINFO_EXTENSION))
        ];

        if ($filename === $book_file) {
            $current_index = $index;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="zh-cn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($book_name); ?> - 阅读器</title>
    <link rel="icon" type="image/png" href="title.png">
    <style>
        /* 全局样式 */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Arial, sans-serif;
            background: #f5f5f5;
            color: #333;
            overflow: hidden;
        }

        /* 顶部导航栏 */
        .top-nav {
            position: fixed;
            top: 0; left: 0;
            width: 100%;
            height: 50px;
            background: #fff;
            border-bottom: 1px solid #e0e0e0;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 20px;
            z-index: 1000;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        .nav-left {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .nav-btn {
            background: none;
            border: none;
            font-size: 18px;
            cursor: pointer;
            padding: 8px;
            border-radius: 4px;
            transition: background 0.2s;
        }

        .nav-btn:hover {
            background: #f0f0f0;
        }

        .book-title {
            font-size: 16px;
            font-weight: 600;
            color: #333;
            max-width: 300px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }

        .nav-right {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        /* 主内容区域 */
        .main-content {
            margin-top: 50px;
            height: calc(100vh - 50px);
            display: flex;
        }

        /* 侧边栏 */
        .sidebar {
            width: 300px;
            background: #fff;
            border-right: 1px solid #e0e0e0;
            display: flex;
            flex-direction: column;
            transition: width 0.3s ease;
        }

        .sidebar.collapsed {
            width: 50px;
        }

        /* 侧边栏头部 */
        .sidebar-header {
            padding: 20px;
            border-bottom: 1px solid #e0e0e0;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .sidebar.collapsed .sidebar-header {
            padding: 20px 15px;
            justify-content: center;
        }

        .sidebar-title {
            font-size: 16px;
            font-weight: 600;
            color: #333;
        }

        .sidebar.collapsed .sidebar-title {
            display: none;
        }

        /* 工具面板 */
        .tools-panel {
            flex: 1;
            padding: 20px;
            overflow-y: auto;
        }

        .sidebar.collapsed .tools-panel {
            padding: 10px;
        }

        .tool-section {
            margin-bottom: 25px;
        }

        .tool-title {
            font-size: 14px;
            font-weight: 600;
            color: #666;
            margin-bottom: 15px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .sidebar.collapsed .tool-title {
            display: none;
        }

        .tool-group {
            display: flex;
            flex-direction: column;
            gap: 10px;
        }

        .tool-btn {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 12px;
            background: #f8f9fa;
            border: 1px solid #e0e0e0;
            border-radius: 6px;
            cursor: pointer;
            transition: all 0.2s;
            font-size: 14px;
            color: #333;
        }

        .tool-btn:hover {
            background: #e9ecef;
            border-color: #007bff;
        }

        .tool-btn.active {
            background: #007bff;
            color: white;
            border-color: #007bff;
        }

        .sidebar.collapsed .tool-btn {
            justify-content: center;
            padding: 12px;
        }

        .sidebar.collapsed .tool-btn span:not(.icon) {
            display: none;
        }

        .icon {
            font-size: 16px;
            width: 20px;
            text-align: center;
        }

        /* 滑块控件 */
        .slider-control {
            display: flex;
            flex-direction: column;
            gap: 10px;
        }

        .slider-group {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .slider-label {
            font-size: 14px;
            color: #666;
            min-width: 60px;
        }

        .sidebar.collapsed .slider-label {
            display: none;
        }

        .slider {
            flex: 1;
            -webkit-appearance: none;
            height: 6px;
            border-radius: 3px;
            background: #e0e0e0;
            outline: none;
        }

        .slider::-webkit-slider-thumb {
            -webkit-appearance: none;
            width: 16px;
            height: 16px;
            border-radius: 50%;
            background: #007bff;
            cursor: pointer;
        }

        .slider-value {
            font-size: 12px;
            color: #666;
            min-width: 30px;
            text-align: right;
        }

        .sidebar.collapsed .slider-value {
            display: none;
        }

        /* 阅读区域 */
        .reader-area {
            flex: 1;
            background: #fff;
            display: flex;
            flex-direction: row;
            position: relative;
        }

        .reader-content {
            flex: 1;
            padding: 40px;
            overflow: auto;
            line-height: 1.8;
            font-size: 16px;
            color: #333;
            transition: all 0.3s ease;
        }

        /* 进度条 */
        .progress-bar {
            width: 12px;
            background: #f0f0f0;
            border-left: 1px solid #e0e0e0;
            position: relative;
            display: flex;
            align-items: flex-start;
        }

        .progress-indicator {
            width: 100%;
            background: #007bff;
            height: 0%;
            transition: height 0.3s ease;
            border-radius: 0 0 6px 6px;
        }

        .reader-content.night-mode {
            background: #1a1a1a;
            color: #e0e0e0;
        }

        .reader-content.pdf-container {
            padding: 0;
        }

        .reader-content.pdf-container iframe {
            width: 100%;
            height: 100%;
            border: none;
        }

        .reader-content.txt-content {
            max-width: 800px;
            margin: 0 auto;
            font-family: 'Georgia', serif;
        }

        .reader-content.txt-content pre {
            white-space: pre-wrap;
            word-wrap: break-word;
            overflow-wrap: break-word;
            font-family: inherit;
            margin: 0;
        }

        /* 响应式 */
        @media (max-width: 768px) {
            .sidebar {
                position: absolute;
                left: -300px;
                top: 0;
                height: 100%;
                z-index: 1001;
                box-shadow: 2px 0 10px rgba(0,0,0,0.1);
                transition: left 0.3s ease;
            }

            .sidebar.open {
                left: 0;
            }

            .reader-area {
                width: 100%;
            }

            .reader-content {
                padding: 20px;
            }

            .progress-bar {
                display: none;
            }
        }

        /* 加载动画 */
        .loading {
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100%;
            font-size: 18px;
            color: #666;
        }

        /* 隐藏类 */
        .hidden {
            display: none !important;
        }
    </style>
</head>
<body>
    <!-- 顶部导航栏 -->
    <div class="top-nav">
        <div class="nav-left">
            <button class="nav-btn" id="sidebar-toggle" title="切换侧边栏">☰</button>
            <button class="nav-btn" onclick="window.location.href='book.php'" title="返回书架">📚</button>
            <div class="book-title"><?php echo htmlspecialchars($book_name); ?></div>
        </div>
        <div class="nav-right">
            <button class="nav-btn" id="fullscreen-btn" title="全屏">⛶</button>
        </div>
    </div>

    <!-- 主内容区域 -->
    <div class="main-content">
        <!-- 侧边栏 -->
        <div class="sidebar" id="sidebar">
            <div class="sidebar-header">
                <span class="sidebar-title">阅读工具</span>
            </div>

            <div class="tools-panel">
                <!-- 导航工具 -->
                <div class="tool-section">
                    <div class="tool-title">导航</div>
                    <div class="tool-group">
                        <button class="tool-btn" onclick="window.location.href='index.php'">
                            <span class="icon">🏠</span>
                            <span>网站首页</span>
                        </button>
                        <button class="tool-btn" id="back-to-shelf">
                            <span class="icon">📚</span>
                            <span>返回书架</span>
                        </button>
                        <button class="tool-btn" id="sidebar-toggle-btn">
                            <span class="icon" id="sidebar-icon">◀</span>
                            <span id="sidebar-text">收起侧边栏</span>
                        </button>
                    </div>
                </div>

                <!-- 显示工具 -->
                <div class="tool-section">
                    <div class="tool-title">显示</div>
                    <div class="tool-group">
                        <button class="tool-btn" id="night-mode">
                            <span class="icon">🌙</span>
                            <span>夜间模式</span>
                        </button>
                        <button class="tool-btn" id="fullscreen-mode">
                            <span class="icon">⛶</span>
                            <span>全屏阅读</span>
                        </button>
                    </div>
                </div>

                <!-- 字体工具 -->
                <div class="tool-section">
                    <div class="tool-title">字体</div>
                    <div class="slider-control">
                        <div class="slider-group">
                            <span class="slider-label">大小</span>
                            <input type="range" class="slider" id="font-size" min="12" max="24" value="16">
                            <span class="slider-value" id="font-size-value">16px</span>
                        </div>
                        <div class="slider-group">
                            <span class="slider-label">行高</span>
                            <input type="range" class="slider" id="line-height" min="1.2" max="2.0" step="0.1" value="1.8">
                            <span class="slider-value" id="line-height-value">1.8</span>
                        </div>
                    </div>
                </div>

                <!-- 选择工具 -->
                <div class="tool-section">
                    <div class="tool-title">选择</div>
                    <div class="tool-group">
                        <button class="tool-btn" id="select-all">
                            <span class="icon">📝</span>
                            <span>全选</span>
                        </button>
                        <button class="tool-btn" id="copy-text">
                            <span class="icon">📋</span>
                            <span>复制</span>
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <!-- 阅读区域 -->
        <div class="reader-area">
            <div class="reader-content" id="reader-content">
                <?php if ($book_type === 'pdf'): ?>
                    <div class="pdf-container">
                        <iframe src="<?php echo htmlspecialchars($book_path); ?>" title="PDF 阅读器"></iframe>
                    </div>
                <?php elseif ($book_type === 'txt'): ?>
                    <div class="txt-content">
                        <pre><?php echo htmlspecialchars(file_get_contents($book_path)); ?></pre>
                    </div>
                <?php elseif ($book_type === 'epub'): ?>
                    <div class="loading">
                        <div>EPUB 文件暂不支持在线阅读，请下载后使用专用阅读器</div>
                        <br>
                        <a href="<?php echo htmlspecialchars($book_path); ?>" download class="tool-btn">
                            <span class="icon">⬇</span>
                            <span>下载 EPUB</span>
                        </a>
                    </div>
                <?php else: ?>
                    <div class="loading">不支持的文件格式</div>
                <?php endif; ?>
            </div>
            <!-- 进度条 -->
            <div class="progress-bar" id="progress-bar">
                <div class="progress-indicator" id="progress-indicator"></div>
            </div>
        </div>
    </div>

    <script>
        // 全局变量
        let isNightMode = false;
        let isFullscreen = false;
        let sidebarCollapsed = false; // 默认展开
        const bookList = <?php echo json_encode($book_list); ?>;
        const currentIndex = <?php echo $current_index; ?>;

        // DOM 元素
        const sidebar = document.getElementById('sidebar');
        const readerContent = document.getElementById('reader-content');
        const sidebarToggle = document.getElementById('sidebar-toggle');
        const fullscreenBtn = document.getElementById('fullscreen-btn');

        // 初始化
        document.addEventListener('DOMContentLoaded', function() {
            setupEventListeners();
            loadUserPreferences();
            updateProgress(); // 初始化进度条
        });

        // 设置事件监听器
        function setupEventListeners() {
            // 侧边栏切换
            sidebarToggle.addEventListener('click', toggleSidebar);

            // 全屏按钮
            fullscreenBtn.addEventListener('click', toggleFullscreen);

            // 夜间模式
            document.getElementById('night-mode').addEventListener('click', toggleNightMode);

            // 全屏阅读
            document.getElementById('fullscreen-mode').addEventListener('click', toggleFullscreen);

            // 字体大小
            document.getElementById('font-size').addEventListener('input', updateFontSize);

            // 行高
            document.getElementById('line-height').addEventListener('input', updateLineHeight);

            // 书籍导航
            document.getElementById('back-to-shelf').addEventListener('click', goToShelf);
            document.getElementById('sidebar-toggle-btn').addEventListener('click', toggleSidebar);

            // 选择工具
            document.getElementById('select-all').addEventListener('click', selectAllText);
            document.getElementById('copy-text').addEventListener('click', copySelectedText);

            // 滚动进度
            readerContent.addEventListener('scroll', updateProgress);

            // ESC 键关闭全屏
            document.addEventListener('keydown', function(e) {
                if (e.key === 'Escape' && isFullscreen) {
                    exitFullscreen();
                }
            });
        }

        // 切换侧边栏
        function toggleSidebar() {
            sidebarCollapsed = !sidebarCollapsed;
            sidebar.classList.toggle('collapsed', sidebarCollapsed);

            // 更新按钮图标和文字
            const icon = document.getElementById('sidebar-icon');
            const text = document.getElementById('sidebar-text');

            if (sidebarCollapsed) {
                icon.textContent = '▶';
                text.textContent = '展开侧边栏';
            } else {
                icon.textContent = '◀';
                text.textContent = '收起侧边栏';
            }

            saveUserPreferences();
        }

        // 切换夜间模式
        function toggleNightMode() {
            isNightMode = !isNightMode;
            readerContent.classList.toggle('night-mode', isNightMode);
            document.getElementById('night-mode').classList.toggle('active', isNightMode);
            saveUserPreferences();
        }

        // 切换全屏
        function toggleFullscreen() {
            if (!isFullscreen) {
                enterFullscreen();
            } else {
                exitFullscreen();
            }
        }

        // 进入全屏
        function enterFullscreen() {
            isFullscreen = true;
            document.documentElement.requestFullscreen().catch(console.log);
            document.getElementById('fullscreen-mode').classList.add('active');
            document.getElementById('fullscreen-btn').textContent = '⛶';
        }

        // 退出全屏
        function exitFullscreen() {
            isFullscreen = false;
            if (document.fullscreenElement) {
                document.exitFullscreen();
            }
            document.getElementById('fullscreen-mode').classList.remove('active');
            document.getElementById('fullscreen-btn').textContent = '⛶';
        }

        // 更新字体大小
        function updateFontSize(e) {
            const size = e.target.value;
            readerContent.style.fontSize = size + 'px';
            document.getElementById('font-size-value').textContent = size + 'px';
            saveUserPreferences();
        }

        // 更新进度条
        function updateProgress() {
            const scrollTop = readerContent.scrollTop;
            const scrollHeight = readerContent.scrollHeight;
            const clientHeight = readerContent.clientHeight;
            const progress = (scrollTop / (scrollHeight - clientHeight)) * 100;
            document.getElementById('progress-indicator').style.height = Math.min(progress, 100) + '%';
        }

        // 书籍导航
        function goToShelf() {
            window.location.href = 'book.php';
        }

        // 选择工具
        function selectAllText() {
            const selection = window.getSelection();
            const range = document.createRange();
            range.selectNodeContents(readerContent);
            selection.removeAllRanges();
            selection.addRange(range);
        }

        function copySelectedText() {
            const selectedText = window.getSelection().toString();
            if (selectedText) {
                navigator.clipboard.writeText(selectedText).then(() => {
                    showToast('文本已复制到剪贴板');
                });
            }
        }

        // 显示提示消息
        function showToast(message) {
            // 创建提示元素
            const toast = document.createElement('div');
            toast.textContent = message;
            toast.style.cssText = `
                position: fixed;
                top: 70px;
                right: 20px;
                background: #007bff;
                color: white;
                padding: 10px 20px;
                border-radius: 4px;
                z-index: 10000;
                font-size: 14px;
                box-shadow: 0 2px 10px rgba(0,0,0,0.2);
                animation: fadeIn 0.3s ease;
            `;

            document.body.appendChild(toast);

            setTimeout(() => {
                toast.style.animation = 'fadeOut 0.3s ease';
                setTimeout(() => toast.remove(), 300);
            }, 2000);
        }

        // 加载用户偏好设置
        function loadUserPreferences() {
            const prefs = localStorage.getItem('reader_prefs');
            if (prefs) {
                const settings = JSON.parse(prefs);

                // 应用设置
                if (settings.nightMode) {
                    toggleNightMode();
                }
                if (settings.sidebarCollapsed) {
                    toggleSidebar();
                }
                if (settings.fontSize) {
                    document.getElementById('font-size').value = settings.fontSize;
                    updateFontSize({target: {value: settings.fontSize}});
                }
                if (settings.lineHeight) {
                    document.getElementById('line-height').value = settings.lineHeight;
                    updateLineHeight({target: {value: settings.lineHeight}});
                }
            }
        }

        // 保存用户偏好设置
        function saveUserPreferences() {
            const prefs = {
                nightMode: isNightMode,
                sidebarCollapsed: sidebarCollapsed,
                fontSize: document.getElementById('font-size').value,
                lineHeight: document.getElementById('line-height').value
            };
            localStorage.setItem('reader_prefs', JSON.stringify(prefs));
        }

        // 添加CSS动画
        const style = document.createElement('style');
        style.textContent = `
            @keyframes fadeIn {
                from { opacity: 0; transform: translateY(-10px); }
                to { opacity: 1; transform: translateY(0); }
            }
            @keyframes fadeOut {
                from { opacity: 1; transform: translateY(0); }
                to { opacity: 0; transform: translateY(10px); }
            }
        `;
        document.head.appendChild(style);
    </script>
</body>
</html>