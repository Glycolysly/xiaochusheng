<?php
// router.php - 极简纯净版 (专治转圈圈)

// 1. 解析请求路径
$uri = urldecode(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH));
$file = __DIR__ . $uri;

// 2. 静态资源直接放行
// 如果文件存在，且不是 PHP 脚本，直接返回 false 交给服务器处理
// 这样图片、视频、CSS 就不会经过任何 PHP 逻辑，速度最快
if (file_exists($file) && !is_dir($file)) {
    // 兼容性写法：使用 substr 代替 str_ends_with，防止 Linux PHP 版本过低报错
    if (substr($file, -4) !== '.php') {
        return false; 
    }
}

// 3. PHP 脚本路由
if ($uri === '/' || $uri === '/index.php') {
    require 'index.php';
} 
elseif (file_exists($file) && substr($file, -4) === '.php') {
    // 这是一个 PHP 文件 (比如 stream.php, upload.php)，直接运行它
    require $file;
} 
else {
    // 404 处理
    http_response_code(404);
    echo "404 Not Found";
}
?>
