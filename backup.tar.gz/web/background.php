<canvas id="background-canvas"></canvas>

<style>
    #background-canvas {
        position: fixed;       /* 关键1：固定定位，不随页面滚动 */
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        z-index: -9999;        /* 关键2：负数层级，强制沉到最底 */
        pointer-events: none;  /* 关键3：鼠标穿透，不挡住页面操作 */
        
        /* 为了防止 JS 加载慢导致白屏，先给个深色底 */
        background: linear-gradient(to right, #d7c2c2ff, #7895eaff, #3026edff);
    }
</style>
<script>

        (function() {
            const canvas = document.getElementById('background-canvas');
            const ctx = canvas.getContext('2d');
            

            function resizeCanvas() {
                canvas.width = window.innerWidth;
                canvas.height = window.innerHeight;
            }

            resizeCanvas();
            window.addEventListener('resize', resizeCanvas);
            

           class Particle {
               constructor() {
                   this.x = Math.random() * canvas.width;
                   this.y = Math.random() * canvas.height;
                   this.size = Math.random() * 3 + 2; 
                   this.speedX = Math.random() * 0.3 - 0.15; 
                   this.speedY = Math.random() * 0.3 - 0.15;
                   
   
                   const colors = [
                       {r: 255, g: 105, b: 180}, 
                       {r: 135, g: 206, b: 235},
                       {r: 144, g: 238, b: 144}, 
                       {r: 255, g: 215, b: 0},  
                       {r: 128, g: 0, b: 128},  
                       {r: 255, g: 165, b: 0},  
                       {r: 0, g: 191, b: 255},   
                       {r: 255, g: 255, b: 255}  
                   ];
                   

                   const colorChoice = colors[Math.floor(Math.random() * colors.length)];
                   this.color = `rgba(${colorChoice.r}, ${colorChoice.g}, ${colorChoice.b}, 0.6)`;
                   this.lineColor = `rgba(${colorChoice.r}, ${colorChoice.g}, ${colorChoice.b}, 0.6)`;

                   this.r = colorChoice.r;
                   this.g = colorChoice.g;
                   this.b = colorChoice.b;
               }
                
                update() {

                    this.x += this.speedX;
                    this.y += this.speedY;
                    

                    if (mouse.x !== null && mouse.y !== null) {
                        const dx = mouse.x - this.x;
                        const dy = mouse.y - this.y;
                        const distance = Math.sqrt(dx * dx + dy * dy);
                        

                        if (distance < 150) {

                            const force = 0.01;
                            this.speedX += (dx * force) / distance;
                            this.speedY += (dy * force) / distance;
                        }
                    }
                    

                    const maxSpeed = 2;
                    if (Math.abs(this.speedX) > maxSpeed) {
                        this.speedX = this.speedX > 0 ? maxSpeed : -maxSpeed;
                    }
                    if (Math.abs(this.speedY) > maxSpeed) {
                        this.speedY = this.speedY > 0 ? maxSpeed : -maxSpeed;
                    }
                    
                    if (this.x < 0) this.x = canvas.width;
                    if (this.x > canvas.width) this.x = 0;
                    if (this.y < 0) this.y = canvas.height;
                    if (this.y > canvas.height) this.y = 0;
                }
                
                draw() {
                    ctx.fillStyle = this.color;
                    ctx.beginPath();
                    ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
                    ctx.fill();
                }
            }
            

            let particles = [];
            const particleCount = 100;
            
            function init() {
                particles = [];
                for (let i = 0; i < particleCount; i++) {
                    particles.push(new Particle());
                }
            }

            function connectParticles() {
                for (let a = 0; a < particles.length; a++) {
                    for (let b_idx = a + 1; b_idx < particles.length; b_idx++) {
                        const dx = particles[a].x - particles[b_idx].x;
                        const dy = particles[a].y - particles[b_idx].y;
                        const distance = Math.sqrt(dx * dx + dy * dy);

                        if (distance < 200) {

                            const opacity = 0.8 - (distance / 200) * 0.5;
                            
  
                            const r = Math.floor((particles[a].r + particles[b_idx].r) / 2);
                            const g = Math.floor((particles[a].g + particles[b_idx].g) / 2);
                            const blue = Math.floor((particles[a].b + particles[b_idx].b) / 2);
                            
                            ctx.strokeStyle = `rgba(${r}, ${g}, ${blue}, ${opacity})`;
                            ctx.lineWidth = 1.2;
                            ctx.beginPath();
                            ctx.moveTo(particles[a].x, particles[a].y);
                            ctx.lineTo(particles[b_idx].x, particles[b_idx].y);
                            ctx.stroke();
                        }
                    }
                }
            }

            const mouse = { x: null, y: null };
            

            window.addEventListener('mousemove', function(event) {
                const rect = canvas.getBoundingClientRect();
                mouse.x = event.clientX - rect.left;
                mouse.y = event.clientY - rect.top;
            });
            

            window.addEventListener('mouseout', function() {
                mouse.x = null;
                mouse.y = null;
            });
            

            function animate() {
                ctx.clearRect(0, 0, canvas.width, canvas.height);
                

                connectParticles();
                

                for (let i = 0; i < particles.length; i++) {
                    particles[i].update();
                    particles[i].draw();
                }
                
                requestAnimationFrame(animate);
            }
            init();
            animate();
        })();
    </script>
