<?php
session_start();

// 如果用户已经登录，没必要注册，直接踢回首页
if (isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}

$error_msg = '';
$success_msg = '';

// 处理注册表单提交
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    $username = trim($_POST['username']);
    $email_address = trim($_POST['email']);
    $password = trim($_POST['password']);
    $confirm_password = trim($_POST['confirm_password']);
    $check_password = trim($_POST['check_password']);
    
    // 1. 基础验证：检查密码是否一致
    if ($password !== $confirm_password) {
        $error_msg = "两次输入的密码不一致！";
    } 
    elseif (strlen($password) < 6) { // 可选：简单的密码长度验证
        $error_msg = "密码长度至少需要6位！";
    }
    elseif (!filter_var($email_address, FILTER_VALIDATE_EMAIL)) {
        $error_msg = "邮箱格式不正确！";
    }
    else if($check_password !== ($_SESSION['email_verify_code'] ?? '')) {
        if($email_address !== ($_SESSION['email_verify_addr'] ?? '')) {
            $error_msg = "验证码与邮箱地址不匹配！";
        }
        else if(time() - ($_SESSION['email_verify_time'] ?? 0) > 10 * 60) { // 10分钟过期
            $error_msg = "验证码已过期，请重新获取！";
        }
        else
        $error_msg = "验证码错误！";
    }
    else {
        $json_file = '732946d0544620d92e4d7c4b1490b143.json';
        
        // 读取现有用户数据
        $users = [];
        if (file_exists($json_file)) {
            $json_string = file_get_contents($json_file);
            $users = json_decode($json_string, true);
            if (!$users) $users = []; // 如果文件为空或格式错误，初始化为空数组
        }

        // 2. 验证用户名是否已存在
        $user_exists = false;
        foreach ($users as $user) {
            if ($user['username'] === $username) {
                $user_exists = true;
                break;
            }
        }

        if ($user_exists) {
            $error_msg = "该用户名已被注册，请更换一个！";
        } else {
            // 3. 生成新用户数据
            // 自动计算下一个 ID (取当前最大的 ID + 1)
            $new_id = 1;
            if (!empty($users)) {
                // 提取所有用户的 ID，找到最大值
                $ids = array_column($users, 'id');
                $new_id = max($ids) + 1;
            }

            $new_user = [
                "id" => $new_id,
                "username" => $username,
                "password" => password_hash($password, PASSWORD_DEFAULT),
                "email_address" => $email_address,
                "role" => "user"         // 默认为普通用户
            ];

            // 4. 追加并写入文件
            $users[] = $new_user;
            
            // JSON_PRETTY_PRINT 让文件格式整齐，JSON_UNESCAPED_UNICODE 防止中文乱码
            if (file_put_contents($json_file, json_encode($users, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE))) {
                // 注册成功，跳转到登录页
                // 这里用 JS 跳转并提示，体验更好
                echo "<script>alert('注册成功！请登录。'); window.location.href='login.php';</script>";
                exit;
            } else {
                $error_msg = "系统错误：无法写入数据，请检查文件权限。";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="zh-cn">
<head>
    <meta charset="UTF-8">
    <title>用户注册</title>
    <link rel="icon" type="image/png" href="title.png">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        /* 复用 login.php 的样式 */
        body {
            font-family: Arial, sans-serif;
            background-color: #fdfdfdff;
            margin: 0;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            overflow: hidden;
            position: relative;
        }

       
        .login-card {
            position: relative;
            z-index: 10;
            background: rgba(255, 255, 255, 0.9);
            padding: 40px;
            width: 320px;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.3);
            text-align: center;
        }

        .login-card h2 {
            margin-top: 0;
            color: #333;
            margin-bottom: 20px;
        }

        .form-group {
            margin-bottom: 15px;
            text-align: left;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 5px;
            color: #666;
            font-size: 14px;
        }

        .form-control {
            width: 100%;
            padding: 10px;
            box-sizing: border-box; 
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
        }

        .btn-submit {
            width: 100%;
            padding: 12px;
            background-color: #007BFF; /* 注册按钮改为蓝色，以示区别 */
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            margin-top: 10px;
            transition: background 0.3s;
        }

        .btn-submit:hover {
            background-color: #0056b3;
        }

        .error-message {
            color: #ff0000;
            background-color: #ffe6e6;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 15px;
            font-size: 14px;
            display: <?php echo empty($error_msg) ? 'none' : 'block'; ?>;
        }
        
        .back-link {
            display: block;
            margin-top: 15px;
            font-size: 14px;
            color: #0b0b0bff;
            text-decoration: none;
        }
        
        .back-link:hover {
            text-decoration: underline;
        }
        .input-group {
            display: flex;
            gap: 10px; /* 输入框和按钮之间的间距 */
        }
        
        /* 让输入框占据剩余空间 */
        .input-group .form-control {
            flex: 1;
            width: auto; /* 覆盖原来的 width: 100% */
        }

        /* 发送验证码按钮样式 */
        .btn-send-code {
            padding: 0 15px;
            background-color: #e2f5b6ff; /* 橙色，与注册按钮区分 */
            color: black;
            border: none;
            border-radius: 5px;
            font-size: 14px;
            cursor: pointer;
            white-space: nowrap; /* 防止文字换行 */
            transition: background 0.3s;
        }

        .btn-send-code:hover {
            background-color: #e2d4beff;
        }

        .btn-send-code:disabled {
            background-color: #ccc; /* 禁用变成灰色 */
            cursor: not-allowed;
        }
    </style>
</head>
<body>

    <?php include("back.php"); ?>

    <div class="login-card">
        <h2>新用户注册</h2>

        <div class="error-message">
            <?php echo $error_msg; ?>
        </div>

        <form method="post" action="register.php">
            <div class="form-group">
                <label>用户名</label>
                <input type="text" name="username" class="form-control" placeholder="请输入用户名" required>
            </div>
            <div class="form-group">
                <label>邮箱地址</label>
                <div class="input-group">
                    <input type="email" id="email" name="email" class="form-control" placeholder="请输入邮箱地址" required>
                    <button type="button" id="sendCodeBtn" class="btn-send-code">发送验证码</button>
                </div>
            </div>

            <div class="form-group">
                <label>密码</label>
                <input type="password" name="password" class="form-control" placeholder="设置您的密码" required>
            </div>
            
            <div class="form-group">
                <label>确认密码</label>
                <input type="password" name="confirm_password" class="form-control" placeholder="请再次输入密码" required>
            </div>
            <div class="form-group">
                <label>验证码</label>
                <input type="text" name="check_password" class="form-control" placeholder="请输入验证码" required>
            </div>

            <button type="submit" class="btn-submit">立即注册</button>
        </form>

        <a href="login.php" class="back-link">已有账号？去登录 →</a>
    </div>

<script>
    const sendBtn = document.getElementById('sendCodeBtn');
    const emailInput = document.getElementById('email');

    sendBtn.addEventListener('click', function() {
        const email = emailInput.value.trim();
        if (!email || !email.includes('@')) {
            alert('请先填写正确的邮箱地址！');
            return;
        }

        // 禁用按钮，防止重复点击
        sendBtn.disabled = true;
        sendBtn.style.backgroundColor = '#ccc';
        sendBtn.textContent = '发送中...';

        fetch('send.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ email: email })
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                alert('验证码已发送，请查收邮件！');

                let countdown = 60;
                sendBtn.style.backgroundColor = '#ccc';
                sendBtn.textContent = countdown + '秒后重发';

                const timer = setInterval(() => {
                    countdown--;
                    sendBtn.textContent = countdown + '秒后重发';
                    if (countdown <= 0) {
                        clearInterval(timer);
                        sendBtn.disabled = false;
                        sendBtn.style.backgroundColor = '#e2f5b6ff';
                        sendBtn.textContent = '发送验证码';
                    }
                }, 1000);
            } else {
                alert('发送失败：' + data.message);
                sendBtn.disabled = false;
                sendBtn.style.backgroundColor = '#e2f5b6ff';
                sendBtn.textContent = '发送验证码';
            }
        })
        .catch(err => {
            alert('请求失败，请检查网络或服务端：' + err);
            sendBtn.disabled = false;
            sendBtn.style.backgroundColor = '#e2f5b6ff';
            sendBtn.textContent = '发送验证码';
        });
    });
</script>
</body>
</html>