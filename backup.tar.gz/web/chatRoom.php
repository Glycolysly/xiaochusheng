<?php
// ChatRoom.php - 聊天室页面

session_start();
// 1. 安全检查
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}
// 释放 Session 锁，避免卡顿
session_write_close();

// 消息由异步接口处理（chat_post.php / chat_fetch.php）

// 3. 加载消息
$chat_file = 'chat.json';
$chat_data = file_exists($chat_file) ? json_decode(file_get_contents($chat_file), true) : ['messages' => []];
$messages = isset($chat_data['messages']) ? $chat_data['messages'] : [];
// 加载用户头像映射，便于服务端渲染备用
$user_file = '732946d0544620d92e4d7c4b1490b143.json';
$avatar_map = [];
if (file_exists($user_file)) {
    $users = json_decode(file_get_contents($user_file), true);
    if (is_array($users)) {
        foreach ($users as $uname => $ud) {
            if (isset($ud['avatar']) && !empty($ud['avatar'])) $avatar_map[$uname] = $ud['avatar'];
        }
    }
}
?>
<!DOCTYPE html>
<html lang="zh-cn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>聊天室</title>
    <link rel="icon" type="image/png" href="title.png">
    <style>
        /* 全局样式 */
        body {
            font-family: 'Segoe UI', Arial, sans-serif;
            margin: 0;
            padding: 0;
            background: linear-gradient(to right, #d7c2c2, #7895ea, #1185f3ff);
            color: #333;
            overflow: hidden;
        }

        /* 导航栏 */
        nav {
            position: fixed;
            top: 0; left: 0;
            width: 100%;
            height: 70px;
            background-color: rgba(255, 255, 255, 0.7);
            backdrop-filter: blur(10px);
            border-bottom: 1px solid rgba(0, 0, 0, 0.05);
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 40px;
            box-sizing: border-box;
            z-index: 100;
        }

        .nav-logo { font-size: 20px; font-weight: bold; color: #333; }
        .nav-links { display: flex; align-items: center; }
        .nav-links a { color: #555; margin-left: 20px; font-size: 15px; font-weight: 500; }
        .nav-links a:hover { color: #000; }

        /* 主内容 */
        .main-content {
            margin-top: 70px;
            height: calc(100vh - 70px);
            display: flex;
            flex-direction: column;
        }

        /* 聊天区域 */
        .chat-container {
            flex: 1;
            display: flex;
            flex-direction: column;
            background: rgba(255, 255, 255, 0.9);
            margin: 20px;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }

        .chat-messages {
            flex: 1;
            overflow-y: auto;
            padding: 20px;
            background: rgba(255, 255, 255, 0.8);
        }

        .message {
            margin-bottom: 15px;
            padding: 10px;
            background: rgba(255, 255, 255, 0.6);
            border-radius: 8px;
            border-left: 4px solid #667eea;
        }

        .message .user {
            font-weight: bold;
            color: #667eea;
            margin-bottom: 5px;
        }

        .message .time {
            font-size: 12px;
            color: rgba(0,0,0,0.5);
            margin-bottom: 5px;
        }

        .message .text {
            line-height: 1.4;
        }

        /* 发送区域 */
        .chat-input {
            padding: 20px;
            background: rgba(255, 255, 255, 0.9);
            border-top: 1px solid rgba(0, 0, 0, 0.1);
        }

        .chat-form {
            display: flex;
            gap: 10px;
        }

        .chat-form input[type="text"] {
            flex: 1;
            padding: 10px;
            border: 1px solid rgba(0, 0, 0, 0.2);
            border-radius: 5px;
            font-size: 14px;
        }

        .chat-form button {
            padding: 10px 20px;
            background: #667eea;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
            transition: background 0.3s;
        }

        .chat-form button:hover {
            background: #5a67d8;
        }

        /* 美化滚动条 */
        .chat-messages::-webkit-scrollbar {
            width: 6px;
        }

        .chat-messages::-webkit-scrollbar-thumb {
            background: rgba(0, 0, 0, 0.2);
            border-radius: 3px;
        }

        .chat-messages::-webkit-scrollbar-track {
            background: rgba(0, 0, 0, 0.05);
        }

        /* 响应式 */
        @media (max-width: 768px) {
            .chat-container {
                margin: 10px;
            }
            .chat-form {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>
    <nav>
        <div class="nav-logo">💬 聊天室</div>
        <div class="nav-links">
            <a href="index.php">首页</a>
            <a href="logout.php">注销</a>
        </div>
    </nav>

    <div class="main-content">
        <div class="chat-container">
            <div class="chat-messages" id="messages">
                <?php if (empty($messages)): ?>
                    <p style="text-align: center; color: #999; margin-top: 50px;">暂无消息，开始聊天吧！</p>
                <?php else: ?>
                    <?php foreach ($messages as $msg): ?>
                        <div class="message">
                            <div class="user"><?php echo htmlspecialchars($msg['user']); ?></div>
                            <div class="time"><?php echo $msg['time']; ?></div>
                            <div class="text"><?php echo $msg['message']; ?></div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
            <div class="chat-input">
                <form id="chatForm" class="chat-form" onsubmit="return false;">
                    <input id="messageInput" type="text" name="message" placeholder="输入消息..." required maxlength="500">
                    <button id="sendBtn" type="button">发送</button>
                </form>
            </div>
        </div>
    </div>

    <script>
        const messagesDiv = document.getElementById('messages');
        const form = document.getElementById('chatForm');
        const input = document.getElementById('messageInput');
        const sendBtn = document.getElementById('sendBtn');

        function renderMessages(data) {
            messagesDiv.innerHTML = '';
            if (!data || !Array.isArray(data.messages) || data.messages.length === 0) {
                messagesDiv.innerHTML = '<p style="text-align: center; color: #999; margin-top: 50px;">暂无消息，开始聊天吧！</p>';
                return;
            }
            data.messages.forEach(msg => {
                const div = document.createElement('div');
                div.className = 'message';
                div.innerHTML = '<div class="user">' + escapeHtml(msg.user) + '</div>' +
                                '<div class="time">' + (msg.time || '') + '</div>' +
                                '<div class="text">' + (msg.message || '') + '</div>';
                messagesDiv.appendChild(div);
            });
            messagesDiv.scrollTop = messagesDiv.scrollHeight;
        }

        function escapeHtml(str) {
            if (!str) return '';
            return String(str).replace(/[&<>"']/g, function (s) {
                return ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":"&#39;"})[s];
            });
        }

        async function fetchMessages() {
            try {
                const res = await fetch('chat_fetch.php', {cache: 'no-store'});
                if (res.status === 401) {
                    // 未登录，跳转登录
                    window.location.href = 'login.php';
                    return;
                }
                const data = await res.json();
                renderMessages(data);
            } catch (e) {
                console.error('fetchMessages error', e);
            }
        }

        async function sendMessage() {
            const text = input.value.trim();
            if (!text) return;
            sendBtn.disabled = true;
            try {
                const res = await fetch('chat_post.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ message: text })
                });
                if (res.status === 401) {
                    window.location.href = 'login.php';
                    return;
                }
                const j = await res.json();
                if (j.ok) {
                    input.value = '';
                    await fetchMessages();
                } else {
                    console.error('send error', j);
                    alert('发送失败');
                }
            } catch (e) {
                console.error('sendMessage error', e);
                alert('发送失败');
            } finally {
                sendBtn.disabled = false;
            }
        }

        // 交互绑定
        sendBtn.addEventListener('click', sendMessage);
        input.addEventListener('keydown', function(e) { if (e.key === 'Enter') sendMessage(); });

        // 首次加载并开始轮询
        fetchMessages();
        setInterval(fetchMessages, 3000);
    </script>
</body>
</html>
