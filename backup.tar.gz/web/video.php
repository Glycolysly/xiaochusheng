<?php
// video.php - 终极版 (JS无刷新切换 + 智能播放)

session_start();
// 1. 安全检查
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}
// 释放 Session 锁，避免卡顿
session_write_close();

// 2. 扫描视频
$video_dir = 'videos/';
$files = glob($video_dir . '*.{mp4,webm,ogg}', GLOB_BRACE);

$video_list = [];
if ($files) {
    foreach ($files as $file) {
        $filename = basename($file);
        $name_without_ext = pathinfo($file, PATHINFO_FILENAME);
        
        // 找封面
        $poster = 'default_poster.png';
        if (file_exists($video_dir . $name_without_ext . '.jpg')) {
            $poster = $video_dir . $name_without_ext . '.jpg';
        } elseif (file_exists($video_dir . $name_without_ext . '.png')) {
            $poster = $video_dir . $name_without_ext . '.png';
        }

        // 构建数据
        $video_list[] = [
            'file' => $filename, // 用于 URL
            'name' => $name_without_ext, // 用于显示
            // 预先生成好 stream.php 的播放地址
            'stream_url' => 'stream.php?file=' . urlencode($filename),
            'poster' => $poster
        ];
    }
}

if (empty($video_list)) {
    echo "<script>alert('未找到视频文件！');window.location.href='index.php';</script>";
    exit;
}

// 3. 确定默认视频 (仅用于首屏显示)
$current_index = 0;
if (isset($_GET['v'])) {
    foreach ($video_list as $index => $item) {
        if ($item['file'] === $_GET['v']) {
            $current_index = $index;
            break;
        }
    }
}
$current_video = $video_list[$current_index];
?>

<!DOCTYPE html>
<html lang="zh-cn">
<head>
    <meta charset="UTF-8">
    <title>❤️👙视频影院👙❤️</title>
    <link rel="icon" type="image/png" href="title.png">
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            color: #fff;
            margin: 0;
            overflow-x: hidden;
        }
        
        /* 导航栏 */
        .nav-bar {
            position: relative;
            z-index: 20;
            padding: 15px 40px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: rgba(255, 255, 255, 0.9);
            backdrop-filter: blur(5px);
            border-bottom: 1px solid rgba(0,0,0,0.1);
        }
        .btn-back {
            color: #333;
            text-decoration: none;
            font-weight: bold;
            font-size: 16px;
        }
        .user-info { color: #333; font-weight: 500; }

        /* 主布局 */
        .container {
            display: flex;
            max-width: 1400px;
            margin: 30px auto;
            gap: 20px;
            padding: 0 20px;
            position: relative;
            z-index: 10;
        }

        /* 左侧：播放器 */
        .player-section {
            flex: 3;
            background: rgba(0, 0, 0, 0.5);
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.5);
            display: flex;
            flex-direction: column;
        }

        video {
            width: 100%;
            border-radius: 8px;
            background: #000;
            box-shadow: 0 4px 10px rgba(0,0,0,0.3);
            aspect-ratio: 16 / 9;
        }

        .video-title {
            margin-top: 20px;
            font-size: 24px;
            font-weight: bold;
            color: #fff;
        }

        /* 右侧：播放列表栏 */
        .playlist-column {
            flex: 1;
            background: rgba(80, 75, 75, 0.35);
            backdrop-filter: blur(10px);
            border-radius: 12px;
            border: 3px solid rgba(0, 0, 0, 0.2);
            display: flex;
            flex-direction: column;
            overflow: hidden;
            height: 600px;
        }

        .playlist-title-bar {
            background: rgba(0, 0, 0, 0.3);
            padding: 15px 20px;
            font-size: 18px;
            font-weight: bold;
            color: #fff; /* 修正为白色，深色背景更清晰 */
            border-bottom: 1px solid rgba(255,255,255,0.1);
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        .playlist-count {
            font-size: 12px;
            background: #2196F3;
            padding: 2px 8px;
            border-radius: 10px;
            color: white;
        }

        .playlist-scroll-area {
            flex: 1;
            overflow-y: auto;
            padding: 10px;
        }

        /* 列表项 */
        .video-item {
            display: flex;
            align-items: center;
            padding: 10px;
            margin-bottom: 8px;
            background: rgba(255, 255, 255, 0.6);
            color: #111;
            text-decoration: none; /* 去掉下划线 */
            border-radius: 6px;
            transition: all 0.2s;
            cursor: pointer; /* 鼠标变小手 */
        }

        .video-item:hover {
            background: rgba(255, 255, 255, 0.9);
            transform: translateX(5px);
        }

        .video-item.active {
            background: rgba(33, 150, 243, 0.9); /* 激活高亮 */
            border-left: 4px solid #0d47a1;
            color: #fff;
        }
        
        /* 激活状态下的文字颜色修正 */
        .video-item.active .no-thumb { color: #eee; }

        .thumb-box {
            width: 80px;
            height: 45px;
            background: #000;
            border-radius: 4px;
            overflow: hidden;
            margin-right: 10px;
            flex-shrink: 0;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .thumb-box img { width: 100%; height: 100%; object-fit: cover; }
        .no-thumb { color: #555; font-size: 12px; }

        .video-info { flex: 1; overflow: hidden; }
        .video-name { font-size: 14px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
        
        ::-webkit-scrollbar { width: 6px; }
        ::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.3); border-radius: 3px; }
    </style>
</head>
<body>

    <?php include("background.php"); ?>

    <div class="nav-bar">
        <a href="index.php" class="btn-back">← 返回首页</a>
        <span class="user-info">当前用户: <?php echo htmlspecialchars($_SESSION['username']); ?></span>
    </div>

    <div class="container">
        
        <div class="player-section">
            <video id="main-video" controls poster="<?php echo htmlspecialchars($current_video['poster']); ?>">
                <source src="<?php echo $current_video['stream_url']; ?>" type="video/mp4">
                您的浏览器不支持 HTML5 视频播放。
            </video>
            
            <div class="video-title" id="video-title-text">
                <?php echo htmlspecialchars($current_video['name']); ?>
            </div>
        </div>

        <div class="playlist-column">
            <div class="playlist-title-bar">
                <span>📂 播放列表</span>
                <span class="playlist-count"><?php echo count($video_list); ?></span>
            </div>

            <div class="playlist-scroll-area">
                <?php foreach ($video_list as $item): ?>
                    <div class="video-item <?php echo ($item['file'] === $current_video['file']) ? 'active' : ''; ?>"
                         onclick="playVideo(this)"
                         data-file="<?php echo htmlspecialchars($item['file']); ?>"
                         data-stream="<?php echo $item['stream_url']; ?>"
                         data-poster="<?php echo htmlspecialchars($item['poster']); ?>"
                         data-name="<?php echo htmlspecialchars($item['name']); ?>">
                        
                        <div class="thumb-box">
                            <?php if ($item['poster'] && $item['poster'] !== 'default_poster.png'): ?>
                                <img src="<?php echo htmlspecialchars($item['poster']); ?>">
                            <?php else: ?>
                                <div class="no-thumb">▶</div>
                            <?php endif; ?>
                        </div>
                        
                        <div class="video-info">
                            <div class="video-name"><?php echo htmlspecialchars($item['name']); ?></div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>

    </div>

    <script>
        function playVideo(element) {
            // 1. 获取点击视频的数据
            var streamUrl = element.getAttribute('data-stream');
            var posterUrl = element.getAttribute('data-poster');
            var videoName = element.getAttribute('data-name');
            var fileName  = element.getAttribute('data-file');

            // 2. 获取播放器和标题元素
            var video = document.getElementById('main-video');
            var title = document.getElementById('video-title-text');

            // 3. 切换 UI 激活状态
            // 移除其他项的 active 类
            var items = document.querySelectorAll('.video-item');
            items.forEach(function(item) {
                item.classList.remove('active');
            });
            // 给当前点击的项加上 active
            element.classList.add('active');

            // 4. 切换视频源 (最关键的一步)
            video.pause();
            video.src = streamUrl; // 直接切换流地址
            video.poster = posterUrl;
            title.innerText = videoName;

            // 5. 开始播放
            video.load(); // 重新加载
            var playPromise = video.play();

            // 处理浏览器可能会阻止自动播放的情况
            if (playPromise !== undefined) {
                playPromise.then(_ => {
                    // 播放成功
                }).catch(error => {
                    console.log("浏览器阻止了自动播放，需要用户交互");
                });
            }

            // 6. 更新浏览器地址栏 URL (这样刷新页面后还在当前视频)
            // 使用 pushState 不会触发页面刷新
            var newUrl = window.location.protocol + "//" + window.location.host + window.location.pathname + '?v=' + encodeURIComponent(fileName);
            window.history.pushState({path: newUrl}, '', newUrl);
        }
    </script>
    </div> <script>
        document.addEventListener('DOMContentLoaded', function() {
            var video = document.getElementById('main-video');
            var links = document.querySelectorAll('a'); // 找到页面上所有的链接

            // 1. 监听所有链接点击事件 (包括切换视频、返回首页)
            links.forEach(function(link) {
                link.addEventListener('click', function(e) {
                    // 如果链接是 "#" 或者空，不管它
                    if(this.getAttribute('href') === '#' || !this.getAttribute('href')) return;

                    // 🛑 核心操作：在跳转前，物理掐断视频
                    if (video) {
                        video.pause();           // 1. 暂停播放
                        video.removeAttribute('src'); // 2. 移除视频源 (最关键！)
                        video.load();            // 3. 重置播放器，迫使浏览器立刻断开与 stream.php 的连接
                    }
                });
            });
        });
    </script>
</body>
</html>
</body>
</html>


