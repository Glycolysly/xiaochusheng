<?php
// profile.php
include 'check.php'; // 确保用户已登录

// 定义统一的存储文件
$user_file = '732946d0544620d92e4d7c4b1490b143.json';
$username = $_SESSION['username'];

// 1. 安全读取并解析 JSON
if (file_exists($user_file)) {
    $json_content = file_get_contents($user_file);
    $users = json_decode($json_content, true);
} else {
    $users = []; // 文件不存在则初始化为空数组
}

// 2. 核心：检查 $users 是否为数组，且当前用户是否存在
if (is_array($users) && isset($users[$username])) {
    $user_data = $users[$username];
} else {
    // 如果用户数据不存在，初始化一个默认数组，防止后面报错
    $user_data = [
        'email_address' => '',
        'avatar' => 'default_avatar.png'
    ];
}

// 3. 处理头像上传
if (isset($_FILES['avatar']) && $_FILES['avatar']['error'] == 0) {
    $upload_dir = 'uploads/avatars/';
    if (!is_dir($upload_dir)) mkdir($upload_dir, 0777, true);
    
    $ext = pathinfo($_FILES['avatar']['name'], PATHINFO_EXTENSION);
    $new_name = $username . '_' . time() . '.' . $ext;
    $target = $upload_dir . $new_name;

    if (move_uploaded_file($_FILES['avatar']['tmp_name'], $target)) {
        // 更新数组中的头像路径
        $users[$username]['avatar'] = $target;
        
        // 【关键】将更新后的完整信息保存回 732946d0544620d92e4d7c4b1490b143.json
        file_put_contents($user_file, json_encode($users, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
        
        $user_data['avatar'] = $target;
        echo "<script>alert('头像更新成功！');</script>";
    }
}

$display_avatar = !empty($user_data['avatar']) ? $user_data['avatar'] : 'default_avatar.png';
?>
<!DOCTYPE html>
<html lang="zh-cn">
<head>
    <meta charset="UTF-8">
    <title>个人中心 - ✨ 我的站点</title>
    <link rel="icon" type="image/png" href="title.png">
    <style>
        /* 继承首页的全局样式 */
        body {
            font-family: 'Segoe UI', Arial, sans-serif;
            margin: 0; padding: 0; overflow: hidden;
            background: transparent !important;
        }
        .hover-jump {
            display: inline-block;
            transition: transform 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        }
        .hover-jump:hover {
            transform: translateY(-5px);
        }
        /* 导航栏头像样式优化 */
         nav {
            position: fixed;
            top: 0; left: 0;
            width: 100%;
            height: 70px;
            background-color: rgba(255, 255, 255, 0.7);
            backdrop-filter: blur(10px);
            border-bottom: 1px solid rgba(0, 0, 0, 0.05);
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 40px;
            box-sizing: border-box;
            z-index: 100;
        }

        .nav-logo { font-size: 20px; font-weight: bold; color: #333; }
        .nav-links { display: flex; align-items: center; }
        .nav-links a { color: #555; margin-left: 20px; font-size: 15px; font-weight: 500; }
        .nav-links a:hover { color: #070707ff; }
        .nav-logo a,
        .nav-logo a:hover,
        .nav-logo a:visited,
        .nav-logo a:focus {
            text-decoration: none;
            color: inherit;
        }

        /* === 新增：顶栏滚动公告样式 === */
        /* === 顶栏滚动公告样式 === */
        .nav-center {
            flex: 1;
            margin: 0 40px;
            height: 34px;
            display: flex;
            align-items: center;
            overflow: hidden;
            position: relative;
            background: rgba(0,0,0,0.03);
            border-radius: 20px;
            max-width: 500px;
        }
        .notice-wrapper {
            white-space: nowrap;
            position: absolute;
            animation: scroll-left 15s linear infinite;
        }
        @keyframes scroll-left {
            0%   { transform: translateX(500px); }
            100% { transform: translateX(-100%); }
        }
        .nav-center:hover .notice-wrapper { animation-play-state: paused; }
        .notice-tag {
            padding: 2px 8px;
            border-radius: 4px;
            color: white;
            font-size: 11px;
            margin-right: 8px;
        }
        .nav-avatar {
                    width: 32px; height: 32px;
                    border-radius: 50%;
                    object-fit: cover;
                    vertical-align: middle;
                    margin-right: 8px;
                    border: 2px solid #4CAF50;
                }

        /* 磨砂玻璃板块 */
        .profile-container {
            margin-top: 100px;
            display: flex; justify-content: center;
            height: calc(100vh - 100px);
            overflow-y: auto;
        }

        .profile-card {
            width: 100%; max-width: 600px;
            background: rgba(255, 255, 255, 0.45) !important;
            backdrop-filter: blur(15px);
            border-radius: 20px;
            padding: 40px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.1);
            border: 1px solid rgba(255,255,255,0.3);
            height: fit-content;
        }

        /* 头像上传区域 */
        .avatar-section {
            text-align: center; margin-bottom: 30px;
        }
        .big-avatar {
            width: 120px; height: 120px;
            border-radius: 50%; object-fit: cover;
            border: 4px solid white;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            margin-bottom: 15px;
        }

        /* 表单样式 */
        .form-group { margin-bottom: 20px; }
        label { display: block; margin-bottom: 8px; color: #444; font-weight: bold; }
        input[type="text"], input[type="email"], input[type="password"] {
            width: 100%; padding: 12px;
            border-radius: 10px; border: 1px solid rgba(0,0,0,0.1);
            background: rgba(255,255,255,0.6);
            box-sizing: border-box;
        }

        .btn-save {
            background: #2196F3; color: white;
            border: none; padding: 12px 25px;
            border-radius: 10px; cursor: pointer;
            width: 100%; font-size: 16px; font-weight: bold;
            transition: 0.3s;
        }
        .btn-save:hover { background: #1976D2; transform: translateY(-2px); }

        .back-home {
            display: inline-block; margin-bottom: 20px;
            color: #2196F3; text-decoration: none; font-weight: bold;
        }
    </style>
</head>
<body>

    <?php include 'background.php'; ?>

    <nav>
    <div class="nav-logo hover-jump">
        <a href="index.php">✨ 我的站点</a>
    </div>
    
    <div class="nav-center">
        <?php if ($top_notice): ?>
            <div class="notice-wrapper">
                <span class="notice-tag" style="background:<?php echo ($top_notice['type']=='danger'?'#f44336':($top_notice['type']=='warning'?'#ff9800':'#2196F3')); ?>;">
                    <?php echo $top_notice['type']=='danger'?'紧急':($top_notice['type']=='warning'?'提醒':'公告'); ?>
                </span>
                <span style="font-size:14px; color:#444;">
                    <strong><?php echo htmlspecialchars($top_notice['title']); ?>：</strong>
                    <?php echo htmlspecialchars($top_notice['content']); ?>
                </span>
            </div>
        <?php endif; ?>
    </div>

    <div class="nav-links">
    <?php if (!isset($_SESSION['username'])): ?>
        <a href="login.php" class="hover-jump">登录</a>
        <a href="register.php" class="hover-jump">注册</a>
    <?php else: ?>
        <?php
        // 读取用户头像
        $user_file = '732946d0544620d92e4d7c4b1490b143.json';
        $username = $_SESSION['username'];
        $display_avatar = 'default_avatar.png'; // 默认头像
        
        if (file_exists($user_file)) {
            $users = json_decode(file_get_contents($user_file), true);
            if (is_array($users) && isset($users[$username]['avatar'])) {
                $display_avatar = $users[$username]['avatar'];
            }
        }
        ?>
        
        <!-- 可点击的头像 -->
        <a href="profile.php" class="hover-jump" style="display: inline-block;">
            <img src="<?php echo $display_avatar; ?>" 
                 alt="头像" 
                 style="width: 32px; height: 32px; border-radius: 50%; object-fit: cover; vertical-align: middle; border: 2px solid #4CAF50;">
        </a>
        
        <span style="font-size:14px; margin-left: 8px;">用户:<span style="color:green; font-weight:bold;"><?php echo $_SESSION['username']; ?></span></span>
        <a href="logout.php" class="hover-jump" style="margin-left:10px;">注销</a>
    <?php endif; ?>
</div>
</nav>

    <div class="profile-container">
        <div class="profile-card">
            <a href="index.php" class="back-home">← 返回首页</a>
            
            <div class="avatar-section">
                <img src="<?php echo $display_avatar; ?>" class="big-avatar" id="preview">
                <form action="" method="post" enctype="multipart/form-data">
                    <input type="file" name="avatar" id="fileInput" style="display:none;" onchange="this.form.submit()">
                    <button type="button" onclick="document.getElementById('fileInput').click()" style="background:rgba(0,0,0,0.05); border:none; padding:8px 15px; border-radius:20px; cursor:pointer;">更换头像</button>
                </form>
            </div>

            <form action="update_profile.php" method="post">
                <div class="form-group">
                    <label>用户昵称</label>
                    <input type="text" name="nickname" value="<?php echo htmlspecialchars($username); ?>" readonly style="background:rgba(0,0,0,0.05);">
                </div>

                <div class="form-group">
                    <label>邮件地址</label>
                    <input type="email" name="email" value="<?php echo htmlspecialchars($user_data['email_address']?? '未设置'); ?>" placeholder="yourname@example.com">
                </div>

                <hr style="border:none; border-top:1px solid rgba(0,0,0,0.05); margin:30px 0;">

                <div class="form-group">
                    <label>新密码 (留空表示不修改)</label>
                    <input type="password" name="new_password" placeholder="请输入新密码">
                </div>

                <div class="form-group">
                    <label>确认新密码</label>
                    <input type="password" name="confirm_password" placeholder="请再次输入新密码">
                </div>

                <button type="submit" class="btn-save">保存更改</button>
            </form>
        </div>
    </div>

</body>
</html>