<?php
session_start();
header('Content-Type: application/json; charset=utf-8');
// 验证登录
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['error' => 'unauthorized']);
    exit;
}

// 读取消息并补齐头像信息
$chat_file = 'chat.json';
$chat_data = file_exists($chat_file) ? json_decode(file_get_contents($chat_file), true) : ['messages' => []];

// 尝试加载用户数据以获取头像映射
$user_file = '732946d0544620d92e4d7c4b1490b143.json';
$avatar_map = [];
if (file_exists($user_file)) {
    $users = json_decode(file_get_contents($user_file), true);
    if (is_array($users)) {
        foreach ($users as $uname => $ud) {
            if (isset($ud['avatar']) && !empty($ud['avatar'])) $avatar_map[$uname] = $ud['avatar'];
        }
    }
}

// 为每条消息补齐 avatar 字段
if (isset($chat_data['messages']) && is_array($chat_data['messages'])) {
    foreach ($chat_data['messages'] as &$m) {
        if (!isset($m['avatar']) || empty($m['avatar'])) {
            $m['avatar'] = isset($avatar_map[$m['user']]) ? $avatar_map[$m['user']] : 'default_avatar.png';
        }
    }
    unset($m);
}

// 禁止缓存
header('Cache-Control: no-cache, no-store, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');

echo json_encode($chat_data, JSON_UNESCAPED_UNICODE);
exit;
