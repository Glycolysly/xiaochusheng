<?php
// crawler.php - 每日热点爬虫 (B站官方API修复版)
// 作用：抓取 Bilibili 官方全站排行榜
date_default_timezone_set('PRC'); // 设置为中华人民共和国时区
// 或者使用
date_default_timezone_set('Asia/Shanghai'); // 设置为上海时区
// 设置头部，防止乱码（虽然主要是在后台运行）
header('Content-Type: application/json; charset=utf-8');
date_default_timezone_set('Asia/Shanghai');

// ==========================================
// 1. 配置区域
// ==========================================
// B站官方全站排行榜 API
$bilibili_api = 'https://api.bilibili.com/x/web-interface/popular';

// ==========================================
// 2. 核心函数：封装 cURL 请求 (伪装成浏览器)
// ==========================================
function curl_get($url) {
    $ch = curl_init();
    
    // 设置 URL
    curl_setopt($ch, CURLOPT_URL, $url);
    // 返回结果而不是直接输出
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    // 【关键】伪装成 Chrome 浏览器，否则 B 站会报 403 错误
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36');
    // 设置超时时间 (秒)
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    // 忽略 SSL 证书检查 (防止服务器证书报错)
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    
    $result = curl_exec($ch);
    
    if (curl_errno($ch)) {
        // 如果出错，返回空
        curl_close($ch);
        return null;
    }
    
    curl_close($ch);
    return $result;
}

// ==========================================
// 3. 开始抓取 B 站数据
// ==========================================

$json_raw = curl_get($bilibili_api);
$data = json_decode($json_raw, true);

$output = [];

// 检查官方 API 是否返回了正确的数据结构
if ($data && isset($data['data']) && isset($data['data']['list']) && is_array($data['data']['list'])) {
    $list = $data['data']['list'];
    $count = 0;
    
    foreach ($list as $item) {
        if ($count >= 12) break; // 只取前 12 条
        
        if (!is_array($item) || !isset($item['title']) || !isset($item['bvid'])) {
            continue; // 跳过无效项
        }
        
        // 格式化播放量 (例如 123456 -> 12.3万)
        $view_count = $item['stat']['view'] ?? 0;
        if ($view_count > 10000) {
            $hot_text = round($view_count / 10000, 1) . '万播放';
        } else {
            $hot_text = $view_count . '播放';
        }

        $output[] = [
            'title' => $item['title'],         // 视频标题
            'url'   => $item['short_link_v2'] ?? "https://www.bilibili.com/video/" . $item['bvid'], // 视频链接
            'hot'   => $hot_text               // 热度（播放量）
        ];
        
        $count++;
    }
} else {
    // 备用方案：如果官方接口挂了或者服务器网络不通
    $output[] = [
        'title' => '获取 B 站热榜失败 (网络或接口异常)',
        'url'   => 'https://www.bilibili.com/v/popular/all',
        'hot'   => '0'
    ];
}

// ==========================================
// 4. 保存结果
// ==========================================

$final_data = [
    'updated_at' => time(),
    'source'     => 'bilibili', // 标记源为 B 站
    'list'       => $output
];

// 写入 hot.json
if (file_put_contents(__DIR__ . '/hot.json', json_encode($final_data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT))) {
    echo "✅ B站热榜更新成功！时间: " . date('Y-m-d H:i:s');
} else {
    echo "❌ 写入文件失败，请检查权限。";
}
?>
