<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

session_start();

// 设置返回 JSON 格式（尽量在可能的输出前设置）
header('Content-Type: application/json');

// 正确引入 PHPMailer 源文件（库位于 PHPMailer/src 下）
require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

// 只接收 POST 请求
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['status' => 'error', 'message' => '无效的请求']);
    exit;
}

// 获取前端传来的邮箱
$data = json_decode(file_get_contents('php://input'), true);
$email = isset($data['email']) ? trim($data['email']) : '';

// 简单的邮箱格式检查
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode(['status' => 'error', 'message' => '邮箱格式不正确']);
    exit;
}

// 生成 6 位随机验证码
$code = rand(100000, 999999);

// 【关键】把验证码存入 Session，用于后续注册时比对
$_SESSION['email_verify_code'] = (string)$code;
$_SESSION['email_verify_addr'] = $email;      // 绑定邮箱，防止用户发给A邮箱却用B邮箱注册
$_SESSION['email_verify_time'] = time();      // 记录时间用于判断过期



// --- 配置邮件发送 ---
$mail = new PHPMailer(true);
$mail->SMTPOptions = array(
    'ssl' => array(
        'verify_peer'       => false,
        'verify_peer_name'  => false,
        'allow_self_signed' => true
    )
);
try {
    // 1. 服务器配置 (这里以 QQ 邮箱为例)
    $mail->isSMTP();                                            
    $mail->Host       = 'smtp.qq.com';                     // SMTP 服务器地址 (QQ: smtp.qq.com, 163: smtp.163.com)
    $mail->SMTPAuth   = true;                                   
    $mail->Username   = '1590047811@qq.com';                 // 【修改这里】你的发件邮箱账号
    $mail->Password   = 'yfuqktdnfipigica';                  // 【修改这里】SMTP 授权码 (不是你的QQ登录密码！)
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;       // 启用 SSL 加密
    $mail->Port       = 465;                               // SMTP 端口 (QQ和163通常是 465)

    // 2. 发件人设置
    $mail->setFrom('1590047811@qq.com', '网站管理员');        // 【修改这里】发件人 (必须和上面 Username 一致)
    $mail->addAddress($email);                             // 收件人 (前端传来的)

    // 3. 内容设置
    $mail->isHTML(true);                                  
    $mail->Subject = '您的注册验证码';
    $mail->Body    = "<div style='background:#f2f2f2; padding:20px;'>
                        <div style='background:#fff; padding:20px; border-radius:5px;'>
                            <h2>欢迎注册</h2>
                            <p>您的验证码是：<b style='color:blue; font-size:24px;'>{$code}</b></p>
                            <p>验证码在 10 分钟内有效，请勿泄露给他人。</p>
                        </div>
                      </div>";
    $mail->AltBody = "您的验证码是：{$code}"; // 纯文本内容，防备不支持HTML的客户端

    $mail->send();
    echo json_encode(['status' => 'success', 'message' => '验证码已发送']);

} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'message' => "邮件发送失败: {$mail->ErrorInfo}"]);
}
?>