<?php
date_default_timezone_set('PRC'); // 设置为中华人民共和国时区
// 或者使用
date_default_timezone_set('Asia/Shanghai'); // 设置为上海时区
session_start();
header('Content-Type: application/json; charset=utf-8');
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['error' => 'unauthorized']);
    exit;
}

$raw = file_get_contents('php://input');
$data = json_decode($raw, true);
$message = isset($data['message']) ? trim($data['message']) : '';

if ($message === '') {
    http_response_code(400);
    echo json_encode(['error' => 'empty_message']);
    exit;
}

// 限制长度
if (mb_strlen($message) > 500) {
    http_response_code(400);
    echo json_encode(['error' => 'message_too_long']);
    exit;
}

$chat_file = 'chat.json';
// 读写锁保证并发安全
$max_retries = 5;
for ($i = 0; $i < $max_retries; $i++) {
    $fp = fopen($chat_file, 'c+');
    if (!$fp) {
        usleep(50000);
        continue;
    }
    if (flock($fp, LOCK_EX)) {
        $contents = stream_get_contents($fp);
        $chat_data = $contents ? json_decode($contents, true) : ['messages' => []];

        $username = isset($_SESSION['username']) ? $_SESSION['username'] : '匿名';

        // 获取用户头像（如果有）
        $user_file = '732946d0544620d92e4d7c4b1490b143.json';
        $avatar = 'default_avatar.png';
        if (file_exists($user_file)) {
            $users = json_decode(file_get_contents($user_file), true);
            if (is_array($users) && isset($users[$username]['avatar']) && !empty($users[$username]['avatar'])) {
                $avatar = $users[$username]['avatar'];
            }
        }

        $new_message = [
            'user' => $username,
            'avatar' => $avatar,
            'message' => htmlspecialchars($message),
            'time' => date('Y-m-d H:i:s')
        ];

        $chat_data['messages'][] = $new_message;
        if (count($chat_data['messages']) > 100) {
            $chat_data['messages'] = array_slice($chat_data['messages'], -100);
        }

        // 写回文件
        ftruncate($fp, 0);
        rewind($fp);
        fwrite($fp, json_encode($chat_data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        fflush($fp);
        flock($fp, LOCK_UN);
        fclose($fp);

        echo json_encode(['ok' => true, 'message' => $new_message], JSON_UNESCAPED_UNICODE);
        exit;
    }
    fclose($fp);
    usleep(50000);
}

http_response_code(500);
echo json_encode(['error' => 'could_not_write']);
exit;
