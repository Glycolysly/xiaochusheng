<?php
session_start();

// 1. 👮 只有管理员能进 (严防死守)
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    die("<h1>403 Forbidden</h1><p>Access Denied.</p>");
}

// 2. 初始化目录记忆
// 如果 session 里没有记录目录，就用当前文件所在目录
if (!isset($_SESSION['cwd'])) {
    $_SESSION['cwd'] = getcwd();
}

$current_dir = $_SESSION['cwd'];
$output = '';

// 3. 处理命令
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $cmd = trim($_POST['cmd']);

    if (!empty($cmd)) {
        // --- 特殊处理 cd 命令 ---
        if (strpos($cmd, 'cd ') === 0) {
            // 截取 cd 后面的路径
            $new_path = trim(substr($cmd, 3));
            
            // 切换工作环境去测试路径是否存在
            chdir($current_dir); 
            
            // 尝试切换
            if (@chdir($new_path)) {
                // 如果切换成功，更新 Session 里的目录
                $_SESSION['cwd'] = getcwd();
                $current_dir = $_SESSION['cwd'];
            } else {
                $output = "❌ Directory not found: $new_path";
            }
        } 
        // --- 处理盘符切换 (针对 Windows) ---
        elseif (preg_match('/^[a-zA-Z]:$/', $cmd)) {
            // 比如输入 "c:"
             if (@chdir($cmd)) {
                $_SESSION['cwd'] = getcwd();
                $current_dir = $_SESSION['cwd'];
            } else {
                $output = "❌ Could not change drive to $cmd";
            }
        }
        // --- 普通命令 (ls, ipconfig, dir, whoami...) ---
        else {
            // 1. 先切换到上次记住的目录
            chdir($current_dir);
            
            // 2. 执行命令 (2>&1 把错误输出也抓回来)
            // Windows 下有些命令可能需要加 cmd /c 前缀，这里直接跑
            $output = shell_exec($cmd . " 2>&1");
            
            // 3. 如果输出为空，提示一下
            if (empty($output)) {
                $output = "[Command executed successfully, no output]";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Super Terminal</title>
    <link rel="icon" type="image/png" href="title.png">
    <style>
        /* 黑客风格配色 */
        body { 
            background-color: #0c0c0c; 
            color: #00ff00; 
            font-family: 'Consolas', 'Courier New', monospace; 
            padding: 20px; 
            margin: 0; 
            font-size: 14px;
        }
        .container { max-width: 1000px; margin: 0 auto; }
        
        /* 顶部栏 */
        .header {
            border-bottom: 1px solid #333;
            padding-bottom: 10px;
            margin-bottom: 20px;
            display: flex;
            justify-content: space-between;
        }
        a { color: #fff; text-decoration: none; background: #333; padding: 5px 10px; border-radius: 3px; }
        
        /* 输出区域 */
        .output-box { 
            background: #111; 
            padding: 15px; 
            border: 1px solid #333; 
            border-radius: 5px;
            min-height: 300px;
            max-height: 60vh;
            overflow-y: auto;
            white-space: pre-wrap; /* 保留换行格式 */
            word-wrap: break-word; 
            margin-bottom: 20px; 
            color: #ccc;
            box-shadow: inset 0 0 10px #000;
        }

        /* 输入区域 */
        .input-group { display: flex; align-items: center; background: #222; padding: 10px; border-radius: 5px; }
        .prompt { color: #00ff00; font-weight: bold; margin-right: 10px; white-space: nowrap; }
        input[type="text"] { 
            flex: 1; 
            background: transparent; 
            border: none; 
            color: #fff; 
            font-family: inherit; 
            font-size: 16px; 
            outline: none; 
        }
        button { 
            background: #008000; 
            color: white; 
            border: none; 
            cursor: pointer; 
            padding: 8px 20px; 
            font-weight: bold;
            margin-left: 10px;
        }
        button:hover { background: #00a000; }
        
        /* 滚动条 */
        ::-webkit-scrollbar { width: 8px; }
        ::-webkit-scrollbar-thumb { background: #333; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <span>💻 SYSTEM ROOT SHELL</span>
            <a href="index.php">❌ Exit</a>
        </div>
        
        <div class="output-box" id="consoleOutput">
            <div style="color: #444; margin-bottom: 10px;">
                Microsoft Windows [Version 10.0.xxx] <br>
                PHP User: <?php echo get_current_user(); ?> <br>
                Current Path: <?php echo $current_dir; ?>
                <hr style="border-color:#333">
            </div>
            <?php 
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                echo "<div style='color:#555'>$ " . htmlspecialchars($_POST['cmd']) . "</div>";
                echo htmlspecialchars($output); 
            }
            ?>
        </div>

        <form method="post">
            <div class="input-group">
                <span class="prompt"><?php echo $current_dir; ?> ></span>
                <input type="text" name="cmd" autofocus autocomplete="off" placeholder="ipconfig / dir / cd ..">
                <button type="submit">EXEC</button>
            </div>
        </form>
    </div>
    
    <script>
        // 自动滚动到底部
        var box = document.getElementById('consoleOutput');
        box.scrollTop = box.scrollHeight;
        // 保持聚焦
        document.querySelector('input').focus();
    </script>
</body>
</html>
