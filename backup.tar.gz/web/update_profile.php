<?php
// update_profile.php
include 'check.php';

// 统一指向您的加密文件名
$user_file = '732946d0544620d92e4d7c4b1490b143.json';
$username = $_SESSION['username'];

if (!file_exists($user_file)) {
    die("错误：用户数据库不存在。");
}

$users = json_decode(file_get_contents($user_file), true);

if (!isset($users[$username])) {
    die("错误：当前用户信息不存在。");
}

// 获取表单提交的邮件地址
$new_email = isset($_POST['email']) ? trim($_POST['email']) : '';
$new_pass  = isset($_POST['new_password']) ? $_POST['new_password'] : '';
$conf_pass = isset($_POST['confirm_password']) ? $_POST['confirm_password'] : '';

// 密码修改逻辑
if (!empty($new_pass)) {
    if ($new_pass !== $conf_pass) {
        echo "<script>alert('两次输入的密码不一致！'); history.back();</script>";
        exit;
    }
    $users[$username]['password'] = $new_pass; 
}

// 更新邮件地址（确保键名与 profile.php 读取的一致）
if (!empty($new_email)) {
    $users[$username]['email_address'] = $new_email;
}

// 保存回 732946d0544620d92e4d7c4b1490b143.json
if (file_put_contents($user_file, json_encode($users, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT))) {
    echo "<script>alert('资料更新成功！'); window.location.href='profile.php';</script>";
} else {
    echo "<script>alert('保存失败，请检查权限！'); history.back();</script>";
}
