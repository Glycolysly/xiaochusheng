<?php
// ai_handler.php
// 这是一个通用的 AI 接口，只负责转发请求和流式输出
include 'check.php'; // 权限校验

header('Content-Type: text/event-stream');
header('Cache-Control: no-cache');
header('Connection: keep-alive');
header('X-Accel-Buffering: no'); // 关键：禁用 Nginx 缓存

// 1. 获取 API Key
$api_key = $_SERVER['OPENAI_API_KEY'] ?? getenv('OPENAI_API_KEY');
if (empty($api_key)) {
    // 这里的 Key 仅作备用
    $api_key = "sk-你的API_KEY"; 
}

$api_url = "https://api.deepseek.com/chat/completions";
// 默认模型，也可以由前端传过来
$default_model = "deepseek-chat"; 

// 2. 获取前端传来的所有参数
$input_raw = file_get_contents('php://input');
$input_data = json_decode($input_raw, true);

// === 核心改造：参数动态化 ===
$user_prompt = $input_data['prompt'] ?? '';
$system_prompt = $input_data['system'] ?? '你是一个有用的助手。'; // 默认人设
$history_msgs = $input_data['messages'] ?? null; // 允许前端直接传完整的对话历史
$temperature = $input_data['temperature'] ?? 1.0; // 默认创造力
$model = $input_data['model'] ?? $default_model;

if (empty($user_prompt) && empty($history_msgs)) {
    echo "data: [ERROR] 没有输入内容\n\n";
    flush();
    exit;
}

// 3. 构建消息体
// 如果前端传了完整的 messages 数组（比如带上下文的游戏），直接用
if (!empty($history_msgs) && is_array($history_msgs)) {
    $messages = $history_msgs;
    // 如果只有 history 没有把当前 prompt 放进去，手动追加（看前端逻辑，这里做个兼容）
    if (!empty($user_prompt)) {
        $messages[] = ['role' => 'user', 'content' => $user_prompt];
    }
} else {
    // 简单模式：只有提示词和人设
    $messages = [
        ["role" => "system", "content" => $system_prompt],
        ["role" => "user", "content" => $user_prompt]
    ];
}

// 4. 发送给 DeepSeek
$post_data = [
    "model" => $model,
    "messages" => $messages,
    "temperature" => (float)$temperature, // 确保是浮点数
    "stream" => true
];

$ch = curl_init($api_url);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    "Content-Type: application/json",
    "Authorization: Bearer " . $api_key
]);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_TIMEOUT, 120); // 游戏可能需要更长思考时间

// 回调函数保持不变
curl_setopt($ch, CURLOPT_WRITEFUNCTION, function($ch, $data) {
    echo $data;
    if (ob_get_level() > 0) ob_flush();
    flush();
    return strlen($data);
});

curl_exec($ch);
curl_close($ch);
?>