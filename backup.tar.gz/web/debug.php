<?php
// debug.php - 服务器自我诊断脚本
header("Content-Type: text/plain; charset=utf-8");
echo "当前session id:".$_SESSION['user_id'];
echo "=== 1. Session 路径检查 ===\n";
$savePath = session_save_path();
if (empty($savePath)) {
    // 如果为空，默认通常是 /tmp
    $savePath = "/tmp";
}
echo "PHP 配置的 Session 存储路径: " . $savePath . "\n";

echo "\n=== 2. 权限检查 ===\n";
if (is_writable($savePath)) {
    echo "状态: ✅ 正常 (PHP 可以写入此目录)\n";
} else {
    echo "状态: ❌ 失败 (PHP 无法写入!)\n";
    echo "提示: 请执行 sudo chown -R nginx:nginx " . $savePath . "\n";
}

echo "\n=== 3. 登录状态模拟 ===\n";
session_start();
$_SESSION['test_key'] = '能存进去吗?';
echo "当前 Session ID: ".$_SESSION['user_id']. "\n";

if (isset($_SESSION['username'])) {
    echo "当前登录用户: " . $_SESSION['username'] . " (✅ 已登录)\n";
} else {
	echo "当前登录用户: [空] (❌ 未登录)\n".$_SESSION['role'];
	echo"debug!!!";
}

echo "\n=== 4. 尝试写入测试数据 ===\n";
session_write_close();
session_start();
if (isset($_SESSION['test_key']) && $_SESSION['test_key'] === '能存进去吗?') {
    echo "写入测试: ✅ 成功\n";
} else {
    echo "写入测试: ❌ 失败 (Session 无法保存)\n";
}
?>
