<?php
include 'check.php';

// 设置北京时间
date_default_timezone_set('Asia/Shanghai');

// === 👮 权限定义 ===
$is_admin = (isset($_SESSION['username']) && $_SESSION['role'] === 'admin');
?>
<!DOCTYPE html>
<html lang="zh-cn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>首页</title>
    <link rel="icon" type="image/png" href="title.png">
    <style>
        /* === 全局样式重置 === */
        body {
            font-family: 'Segoe UI', Arial, sans-serif;
            margin: 0;
            padding: 0;
            overflow: hidden; /* 隐藏body滚动条 */
            color: #333;
            /* 关键：让body透明，显示底层背景 */
            background-color: transparent !important;
        }

        a { text-decoration: none; }

        /* 特效：悬停跳动 */
        .hover-jump {
            display: inline-block;
            transition: transform 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        }
        .hover-jump:hover {
            transform: translateY(-5px);
        }

        /* 导航栏 */
        nav {
            position: fixed;
            top: 0; left: 0;
            width: 100%;
            height: 70px;
            background-color: rgba(255, 255, 255, 0.7);
            backdrop-filter: blur(10px);
            border-bottom: 1px solid rgba(0, 0, 0, 0.05);
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 40px;
            box-sizing: border-box;
            z-index: 100;
        }

        .nav-logo { font-size: 20px; font-weight: bold; color: #333; }
        .nav-links { display: flex; align-items: center; }
        .nav-links a { color: #555; margin-left: 20px; font-size: 15px; font-weight: 500; }
        .nav-links a:hover { color: #000; }
        /* === 新增：顶栏滚动公告样式 === */
        /* === 顶栏滚动公告样式 === */
.nav-center {
    flex: 1;
    margin: 0 40px;
    height: 34px;
    display: flex;
    align-items: center;
    overflow: hidden;
    position: relative;
    background: rgba(0,0,0,0.03);
    border-radius: 20px;
    max-width: 500px;
}
.notice-wrapper {
    white-space: nowrap;
    position: absolute;
    animation: scroll-left 15s linear infinite;
}
@keyframes scroll-left {
    0%   { transform: translateX(500px); }
    100% { transform: translateX(-100%); }
}
.nav-center:hover .notice-wrapper { animation-play-state: paused; }
.notice-tag {
    padding: 2px 8px;
    border-radius: 4px;
    color: white;
    font-size: 11px;
    margin-right: 8px;
}

/* === 侧边栏收缩功能样式 === */
x {
    transition: transform 0.4s cubic-bezier(0.4, 0, 0.2, 1);
    z-index: 110; /* 高于导航栏 */
}
/* 收缩状态：向右平移并留出一小部分作为开关 */
x.collapsed {
    transform: translateX(140px); 
}
.toggle-btn {
    position: absolute;
    left: -25px;
    top: 50%;
    transform: translateY(-50%);
    width: 25px;
    height: 50px;
    background: rgba(255, 255, 255, 0.8);
    backdrop-filter: blur(5px);
    border: 1px solid rgba(0,0,0,0.05);
    border-right: none;
    border-radius: 10px 0 0 10px;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 12px;
}
/* 当侧边栏收缩时，主内容区自动变宽 */
.main-content {
    transition: margin-right 0.4s;
}
.main-content.full-width {
    margin-right: 20px;
}

        /* 侧边栏 */
        x {
            position: fixed;
            top: 70px; right: 0;
            width: 160px;
            height: calc(100% - 70px);
            background-color: rgba(255, 255, 255, 0.5);
            backdrop-filter: blur(5px);
            border-left: 1px solid rgba(0, 0, 0, 0.05);
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 20px;
            box-sizing: border-box;
            z-index: 90;
        }

        x a.btn-sidebar {
            display: block; width: 100%; padding: 12px 0; margin-bottom: 15px;
            text-align: center; background-color: #2196F3; color: white;
            border-radius: 8px; box-shadow: 0 4px 6px rgba(33, 150, 243, 0.2);
        }

        /* 主内容 */
        .main-content {
            margin-top: 70px; margin-right: 160px;
            height: calc(100vh - 70px);
            overflow-y: auto;
            padding: 30px;
            box-sizing: border-box;
            scrollbar-width: thin;
        }
        .main-content::-webkit-scrollbar { width: 8px; }
        .main-content::-webkit-scrollbar-thumb { background: rgba(0,0,0,0.1); border-radius: 4px; }

        /* 板块样式 */
        /* --- 优化板块透明度与交互 --- */
.section-block {
    background: rgba(255, 255, 255, 0.45) !important; /* 增强透明度 */
    backdrop-filter: blur(12px); /* 磨砂玻璃效果 */
    border: 1px solid rgba(255, 255, 255, 0.3);
    border-radius: 15px; 
    padding: 35px; 
    margin-bottom: 30px;
    box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
    transition: all 0.3s ease;
}
.section-title {
    font-size: 20px;
    font-weight: bold;
    margin-bottom: 20px; /* 增加底部间距 */
    color: #333;
}

/* 欢迎板块专用：高度对齐与点击手势 */
/* 优化欢迎和热搜容器 */
/* === 欢迎和热搜容器 === */
.welcome-container {
    display: flex;
    align-items: stretch; /* 关键：让子元素高度对齐 */
    gap: 20px;
    margin-bottom: 30px;
    width: 100%;
    box-sizing: border-box;
}

/* 欢迎板块：固定宽度 */
.welcome-block {
    flex: 0 0 180px; /* 不伸缩，固定180px */
    background: linear-gradient(135deg, rgba(102, 126, 234, 0.8) 0%, rgba(48, 172, 249, 0.61) 100%) !important;
    color: black;
    cursor: pointer;
    max-height: 205px;
    margin-bottom: 0 !important;
    display: flex;
    flex-direction: column;
    justify-content: center;
    min-width: 0;
}

/* 热点板块：占满剩余空间 */
.hot-section-adapt {
    flex: 1; /* 关键：占满剩余空间 */
    display: flex;
    flex-direction: column;
    min-width: 0;
    max-height: 220px; /* 限制最大高度，与欢迎板块接近 */
    overflow: hidden; /* 隐藏超出部分 */
}

/* 热点网格：改为按行排列 */
.hot-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr); /* 每行3个 */
    gap: 10px 14px;
    align-items: start; /* 关键：顶部对齐 */
    overflow-y: auto; /* 允许垂直滚动 */
    padding-right: 5px; /* 为滚动条留空间 */
}

/* 美化滚动条 */
.hot-grid::-webkit-scrollbar {
    width: 6px;
}

.hot-grid::-webkit-scrollbar-thumb {
    background: rgba(0, 0, 0, 0.2);
    border-radius: 3px;
}

.hot-grid::-webkit-scrollbar-track {
    background: rgba(0, 0, 0, 0.05);
    border-radius: 3px;
}

/* 热点链接容器 */
.hot-grid a {
    display: flex;
    align-items: center;
    min-width: 0;
    padding: 6px 8px;
    overflow: hidden;
    background: rgba(255, 255, 255, 0.4);
    border-radius: 6px;
    text-decoration: none;
    transition: all 0.2s;
}

.hot-grid a:hover {
    background: rgba(255, 255, 255, 0.6);
    transform: translateX(3px);
}

/* 序号样式 */
.hot-rank {
    color: #ff4757;
    font-weight: bold;
    margin-right: 10px;
    flex-shrink: 0;
    font-style: italic;
    min-width: 20px; /* 确保序号位置固定 */
}

/* 标题样式：限制宽度并显示省略号 */
.hot-title {
    flex: 1;
    display: inline-block;
    max-width: 100%; /* 自适应容器宽度 */
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    font-size: 14px;
    vertical-align: middle;
    color: #333;
}

/* 火焰图标 */
.hot-grid a span:last-child {
    flex-shrink: 0;
    font-size: 12px;
    margin-left: 5px;
}

/* 响应式：窗口较小时改为2列 */
@media (max-width: 1200px) {
    .hot-grid {
        grid-template-columns: repeat(2, 1fr);
    }
}

/* 响应式：窗口很小时改为1列 */
@media (max-width: 768px) {
    .welcome-container {
        flex-direction: column;
    }
    
    .welcome-block {
        flex: 0 0 auto;
    }
    
    .hot-grid {
        grid-template-columns: 1fr;
    }
}

/* 小红书热搜模块样式 */
.xiaohongshu-section-adapt {
    flex: 1;
    display: flex;
    flex-direction: column;
    min-width: 0;
    max-height: 220px;
    overflow: hidden;
}

.xiaohongshu-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 10px 14px;
    align-items: start;
    overflow-y: auto;
    padding-right: 5px;
}

.xiaohongshu-grid::-webkit-scrollbar {
    width: 6px;
}

.xiaohongshu-grid::-webkit-scrollbar-thumb {
    background: rgba(0, 0, 0, 0.2);
    border-radius: 3px;
}

.xiaohongshu-grid::-webkit-scrollbar-track {
    background: rgba(0, 0, 0, 0.05);
    border-radius: 3px;
}

.xiaohongshu-grid a {
    display: flex;
    align-items: center;
    min-width: 0;
    padding: 6px 8px;
    overflow: hidden;
    background: rgba(255, 255, 255, 0.4);
    border-radius: 6px;
    text-decoration: none;
    transition: all 0.2s;
}

.xiaohongshu-grid a:hover {
    background: rgba(255, 255, 255, 0.6);
    transform: translateX(3px);
}

.xiaohongshu-rank {
    color: #ff1744;
    font-weight: bold;
    margin-right: 10px;
    flex-shrink: 0;
    font-style: italic;
    min-width: 20px;
}

.xiaohongshu-title {
    flex: 1;
    display: inline-block;
    max-width: 100%;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    font-size: 14px;
    vertical-align: middle;
    color: #333;
}

.xiaohongshu-grid a span:last-child {
    flex-shrink: 0;
    font-size: 12px;
    margin-left: 5px;
}

@media (max-width: 1200px) {
    .xiaohongshu-grid {
        grid-template-columns: repeat(2, 1fr);
    }
}

@media (max-width: 768px) {
    .xiaohongshu-grid {
        grid-template-columns: 1fr;
    }
}

/* 热搜栏目样式 */
.hot-trends-container {
    margin-bottom: 30px;
}

.trends-grid {
    display: flex;
    gap: 20px;
    align-items: stretch;
}

.trend-section {
    flex: 1;
    display: flex;
    flex-direction: column;
    min-width: 0;
}

@media (max-width: 768px) {
    .trends-grid {
        flex-direction: column;
    }
}
        /* 网格 */
        .card-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 20px;
        }

        /* 卡片 */
        .info-card {
            background: rgba(255, 255, 255, 0.7);
            border: 1px solid rgba(255,255,255,0.9);
            border-radius: 10px; padding: 20px;
            cursor: pointer; transition: all 0.3s;
            display: block; /* 修复链接卡片显示问题 */
            text-decoration: none;
        }
        .info-card h3 { margin: 0 0 10px 0; color: #333; font-size: 18px; }
        .info-card p { margin: 0; color: #080808ff; font-size: 13px; line-height: 1.5; }

        /* 只有管理员可见的样式（红色强调） */
        .admin-card h3 { color: #d9534f; }
        .admin-block { border-left-color: #d9534f; }

        /* 粒子背景样式 */
        #background-canvas {
            position: fixed;
            top: 0; left: 0;
            width: 100%; height: 100%;
            z-index: -1; /* 沉底 */
            pointer-events: none; /* 穿透 */
            background: linear-gradient(to right, #d7c2c2, #7895ea, #1185f3ff);
        }
    </style>
</head>
<body>

    <canvas id="background-canvas"></canvas>
    <script>

        (function() {
            const canvas = document.getElementById('background-canvas');
            const ctx = canvas.getContext('2d');


            function resizeCanvas() {
                canvas.width = window.innerWidth;
                canvas.height = window.innerHeight;
            }

            resizeCanvas();
            window.addEventListener('resize', resizeCanvas);


           class Particle {
               constructor() {
                   this.x = Math.random() * canvas.width;
                   this.y = Math.random() * canvas.height;
                   this.size = Math.random() * 3 + 2;
                   this.speedX = Math.random() * 0.3 - 0.15;
                   this.speedY = Math.random() * 0.3 - 0.15;


                   const colors = [
                       {r: 255, g: 105, b: 180},
                       {r: 135, g: 206, b: 235},
                       {r: 144, g: 238, b: 144},
                       {r: 255, g: 215, b: 0},
                       {r: 128, g: 0, b: 128},
                       {r: 255, g: 165, b: 0},
                       {r: 0, g: 191, b: 255},
                       {r: 255, g: 255, b: 255}
                   ];


                   const colorChoice = colors[Math.floor(Math.random() * colors.length)];
                   this.color = `rgba(${colorChoice.r}, ${colorChoice.g}, ${colorChoice.b}, 0.6)`;
                   this.lineColor = `rgba(${colorChoice.r}, ${colorChoice.g}, ${colorChoice.b}, 0.6)`;

                   this.r = colorChoice.r;
                   this.g = colorChoice.g;
                   this.b = colorChoice.b;
               }

                update() {

                    this.x += this.speedX;
                    this.y += this.speedY;


                    if (mouse.x !== null && mouse.y !== null) {
                        const dx = mouse.x - this.x;
                        const dy = mouse.y - this.y;
                        const distance = Math.sqrt(dx * dx + dy * dy);


                        if (distance < 150) {

                            const force = 0.01;
                            this.speedX += (dx * force) / distance;
                            this.speedY += (dy * force) / distance;
                        }
                    }


                    const maxSpeed = 2;
                    if (Math.abs(this.speedX) > maxSpeed) {
                        this.speedX = this.speedX > 0 ? maxSpeed : -maxSpeed;
                    }
                    if (Math.abs(this.speedY) > maxSpeed) {
                        this.speedY = this.speedY > 0 ? maxSpeed : -maxSpeed;
                    }

                    if (this.x < 0) this.x = canvas.width;
                    if (this.x > canvas.width) this.x = 0;
                    if (this.y < 0) this.y = canvas.height;
                    if (this.y > canvas.height) this.y = 0;
                }

                draw() {
                    ctx.fillStyle = this.color;
                    ctx.beginPath();
                    ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
                    ctx.fill();
                }
            }


            let particles = [];
            const particleCount = 100;

            function init() {
                particles = [];
                for (let i = 0; i < particleCount; i++) {
                    particles.push(new Particle());
                }
            }

            function connectParticles() {
                for (let a = 0; a < particles.length; a++) {
                    for (let b_idx = a + 1; b_idx < particles.length; b_idx++) {
                        const dx = particles[a].x - particles[b_idx].x;
                        const dy = particles[a].y - particles[b_idx].y;
                        const distance = Math.sqrt(dx * dx + dy * dy);

                        if (distance < 200) {

                            const opacity = 0.8 - (distance / 200) * 0.5;


                            const r = Math.floor((particles[a].r + particles[b_idx].r) / 2);
                            const g = Math.floor((particles[a].g + particles[b_idx].g) / 2);
                            const blue = Math.floor((particles[a].b + particles[b_idx].b) / 2);

                            ctx.strokeStyle = `rgba(${r}, ${g}, ${blue}, ${opacity})`;
                            ctx.lineWidth = 1.2;
                            ctx.beginPath();
                            ctx.moveTo(particles[a].x, particles[a].y);
                            ctx.lineTo(particles[b_idx].x, particles[b_idx].y);
                            ctx.stroke();
                        }
                    }
                }
            }

            const mouse = { x: null, y: null };


            window.addEventListener('mousemove', function(event) {
                const rect = canvas.getBoundingClientRect();
                mouse.x = event.clientX - rect.left;
                mouse.y = event.clientY - rect.top;
            });


            window.addEventListener('mouseout', function() {
                mouse.x = null;
                mouse.y = null;
            });


            function animate() {
                ctx.clearRect(0, 0, canvas.width, canvas.height);


                connectParticles();


                for (let i = 0; i < particles.length; i++) {
                    particles[i].update();
                    particles[i].draw();
                }

                requestAnimationFrame(animate);
            }
            init();
            animate();
        })();
    </script>
    <?php
    $news_file = 'news.json';
    $notices = file_exists($news_file) ? json_decode(file_get_contents($news_file), true) : [];
    $top_notice = !empty($notices) ? $notices[0] : null;
?>
<nav>
    <div class="nav-logo hover-jump">
        <a href="index.php">✨ 我的站点</a>
    </div>
    
    <div class="nav-center">
        <?php if ($top_notice): ?>
            <div class="notice-wrapper">
                <span class="notice-tag" style="background:<?php echo ($top_notice['type']=='danger'?'#f44336':($top_notice['type']=='warning'?'#ff9800':'#2196F3')); ?>;">
                    <?php echo $top_notice['type']=='danger'?'紧急':($top_notice['type']=='warning'?'提醒':'公告'); ?>
                </span>
                <span style="font-size:14px; color:#444;">
                    <strong><?php echo htmlspecialchars($top_notice['title']); ?>：</strong>
                    <?php echo htmlspecialchars($top_notice['content']); ?>
                </span>
            </div>
        <?php endif; ?>
    </div>

    <div class="nav-links">
    <?php if (!isset($_SESSION['username'])): ?>
        <a href="login.php" class="hover-jump">登录</a>
        <a href="register.php" class="hover-jump">注册</a>
    <?php else: ?>
        <?php
        // 读取用户头像
        $user_file = '732946d0544620d92e4d7c4b1490b143.json';
        $username = $_SESSION['username'];
        $display_avatar = 'default_avatar.png'; // 默认头像
        
        if (file_exists($user_file)) {
            $users = json_decode(file_get_contents($user_file), true);
            if (is_array($users) && isset($users[$username]['avatar'])) {
                $display_avatar = $users[$username]['avatar'];
            }
        }
        ?>
        
        <!-- 可点击的头像 -->
        <a href="profile.php" class="hover-jump" style="display: inline-block;">
            <img src="<?php echo $display_avatar; ?>" 
                 alt="头像" 
                 style="width: 32px; height: 32px; border-radius: 50%; object-fit: cover; vertical-align: middle; border: 2px solid #4CAF50;">
        </a>
        
        <span style="font-size:14px; margin-left: 8px;">用户:<span style="color:green; font-weight:bold;"><?php echo $_SESSION['username']; ?></span></span>
        <a href="logout.php" class="hover-jump" style="margin-left:10px;">注销</a>
    <?php endif; ?>
</div>
</nav>

    <div class="main-content">
    
    <div class="welcome-container">
        
        <div class="section-block welcome-block hover-jump" onclick="location.href='profile.php';">
            <h1 style="margin:0; font-size: 28px;">欢迎回来!</h1>
            <p style="opacity: 0.9; margin-top:12px; font-size: 15px;">
                享受你的个人空间。<br>
                <span style="font-size: 12px; border-bottom: 1px solid rgba(4, 4, 4, 0.5);">点击进入个人中心 →</span>
            </p>
        </div>
    </div>

    <!-- 热搜栏目 -->
    <div class="section-block hot-trends-container">
        <div class="section-title" style="margin-bottom: 20px;">🔥 热门趋势</div>
        <div class="trends-grid">
            <?php
            $hot_file = 'hot.json';
            $hot_data = file_exists($hot_file) ? json_decode(file_get_contents($hot_file), true) : ['list' => []];
            $hot_list = isset($hot_data['list']) ? $hot_data['list'] : [];
            ?>
            <div class="trend-section hot-section-adapt" style="border-left: 5px solid #ff4757;">
                <div class="section-title" style="border:none; padding:0; margin-bottom:15px; display:flex; justify-content:space-between; align-items:center;">
                    <span>🔥 噼里啪啦今日热点</span>
                    <span style="font-size:12px; color:rgba(0,0,0,0.4); font-weight:normal;">更新: <?php echo isset($hot_data['updated_at']) ? date('Y-m-d H:i:s', $hot_data['updated_at']) : '未知'; ?></span>
                </div>
                
                <div class="hot-grid">
            <?php if (!empty($hot_list)): ?>
                <?php foreach (array_slice($hot_list, 0, 12) as $index => $hot): ?>
                    <a href="<?php echo $hot['url']; ?>" target="_blank" title="<?php echo htmlspecialchars($hot['title']); ?>" class="hover-jump">
                        <span class="hot-rank"><?php echo $index + 1; ?></span>
                        
                        <span class="hot-title">
                            <?php echo htmlspecialchars($hot['title']); ?>
                        </span>
                        
                        <span style="flex-shrink:0; font-size:12px; margin-left:5px;">🔥</span>
                    </a>
                <?php endforeach; ?>
            <?php endif; ?>
                </div>
            </div>

            <?php
            $xiaohongshu_file = 'xiaohongshu.json';
            $xiaohongshu_data = file_exists($xiaohongshu_file) ? json_decode(file_get_contents($xiaohongshu_file), true) : ['list' => []];
            $xiaohongshu_list = isset($xiaohongshu_data['list']) ? $xiaohongshu_data['list'] : [];
            ?>
            <div class="trend-section xiaohongshu-section-adapt" style="border-left: 5px solid #ff1744;">
                <div class="section-title" style="border:none; padding:0; margin-bottom:15px; display:flex; justify-content:space-between; align-items:center;">
                    <span>📕 小红书热搜</span>
                    <span style="font-size:12px; color:rgba(0,0,0,0.4); font-weight:normal;">更新: <?php echo isset($xiaohongshu_data['updated_at']) ? date('Y-m-d H:i:s', $xiaohongshu_data['updated_at']) : '未知'; ?></span>
                </div>
                
                <div class="xiaohongshu-grid">
            <?php if (!empty($xiaohongshu_list)): ?>
                <?php foreach (array_slice($xiaohongshu_list, 0, 12) as $index => $xiaohongshu): ?>
                    <a href="<?php echo $xiaohongshu['url']; ?>" target="_blank" title="<?php echo htmlspecialchars($xiaohongshu['title']); ?>" class="hover-jump">
                        <span class="xiaohongshu-rank"><?php echo $index + 1; ?></span>
                        
                        <span class="xiaohongshu-title">
                            <?php echo htmlspecialchars($xiaohongshu['title']); ?>
                        </span>
                        
                        <span style="flex-shrink:0; font-size:12px; margin-left:5px;">📕</span>
                    </a>
                <?php endforeach; ?>
            <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

        <div class="section-block">
            <div class="section-title" style="margin-bottom: 20px;">娱乐与媒体</div>
            <div class="card-grid">
                <a href="video.php" class="info-card hover-jump">
                    <h3>📺 视频影院</h3>
                    <p>浏览并播放服务器上的高清视频资源。</p>
                </a>
                <a href="music.php" class="info-card hover-jump">
                    <h3>🎵 在线音乐</h3>
                    <p>聆听精选歌单。</p>
                </a>
                <a href="book.php" class="info-card hover-jump">
                    <h3>📚 电子书阅读</h3>
                    <p>图一下虚。</p>
                </a>
                <a href="chatRoom.php" class="info-card hover-jump">
                    <h3>💬 聊天室</h3>
                    <p>与其他用户实时交流。</p>
                </a>
            </div>
        </div>
        <div class="section-block hover-jump" style="border-left: 5px solid #9c27b0; width: 100%; box-sizing: border-box;">
    <div class="section-title" style="color: #9c27b0; border-color: #9c27b0;">🤖 AI 助手</div>
    
    <div id="ai-response" style="
        background: rgba(255,255,255,0.3); 
        padding: 15px; 
        border-radius: 10px; 
        min-height: 50px; 
        margin-bottom: 15px; 
        color: #444; 
        font-size: 14px; 
        line-height: 1.6;
        width: 100%;           /* 强制填满宽度 */
        box-sizing: border-box; /* 确保内边距不撑大盒子 */
        word-wrap: break-word;  /* 防止长单词撑破布局 */
        white-space: pre-wrap;  /* 关键：保留流式输出的换行符 */
    ">有什么我可以帮你的？</div>

    <div style="display: flex; gap: 10px; width: 100%; box-sizing: border-box;">
        <input type="text" id="ai-input" placeholder="输入问题..." style="flex: 1; padding: 10px; border-radius: 8px; border: 1px solid rgba(0,0,0,0.1); background: rgba(255,255,255,0.5); min-width: 0;">
        <button onclick="askAI()" id="ai-btn" style="padding: 10px 20px; background: #9c27b0; color: white; border: none; border-radius: 8px; cursor: pointer; white-space: nowrap;">提问</button>
    </div>
</div>

<script>
// 这里不需要 escapeHtml 了，因为我们会用 innerText 安全插入
async function askAI() {
    const input = document.getElementById('ai-input');
    const responseBox = document.getElementById('ai-response');
    const btn = document.getElementById('ai-btn');
    const prompt = input.value.trim();

    if (!prompt) return;

    // 1. 初始化 UI
    btn.disabled = true;
    btn.innerText = '思考中...';
    responseBox.innerText = ''; // 清空内容，准备打字
    input.value = ''; // 立即清空输入框

    try {
    const response = await fetch('ai_handler.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
            prompt: prompt,
            // 👇 这里传入首页专用的人设
            system: "你是一个热情、幽默的网站助手，请用简短的语言回答访客的问题。",
            temperature: 0.7 // 稍微严谨一点
        })
    });

        if (!response.ok) {
            responseBox.innerText = "服务器连接错误: " + response.status;
            return;
        }

        // 2. 建立流式读取器
        const reader = response.body.getReader();
        const decoder = new TextDecoder("utf-8");
        let buffer = '';

        while (true) {
            const { done, value } = await reader.read();
            if (done) break;

            // 解码二进制块
            const chunk = decoder.decode(value, { stream: true });
            buffer += chunk;

            // 处理 buffer 中的每一行 (SSE 格式通常是 data: {...})
            const lines = buffer.split('\n');
            buffer = lines.pop(); // 把最后一行可能不完整的留到下一次

            for (const line of lines) {
                const trimmed = line.trim();
                if (!trimmed.startsWith('data: ')) continue;
                
                const jsonStr = trimmed.replace('data: ', '');
                
                if (jsonStr === '[DONE]') break; // 结束标志

                try {
                    const json = JSON.parse(jsonStr);
                    // 3. 获取增量内容
                    const content = json.choices[0].delta.content;
                    if (content) {
                        // 4. 追加显示 (这就是打字机效果)
                        responseBox.innerText += content;
                        // 自动滚动到底部
                        // responseBox.scrollTop = responseBox.scrollHeight; 
                    }
                } catch (e) {
                    // 忽略解析错误的行（比如心跳包）
                }
            }
        }

    } catch (e) {
        console.error(e);
        responseBox.innerText += '\n[网络中断]';
    } finally {
        btn.disabled = false;
        btn.innerText = '提问';
    }
}
</script>
            <?php if ($is_admin): ?>
<div class="section-block admin-block">
    
    <div class="section-title" style="color:#d9534f;">
        🔐 管理员控制台
    </div>

    <div class="card-grid">
        <a href="terminal.php" class="info-card admin-card hover-jump">
            <h3>💻 WebShell</h3>
            <p>服务器命令执行终端</p>
        </a>

        <a href="upload.php" class="info-card admin-card hover-jump">
            <h3>📤 文件上传</h3>
            <p>上传并管理服务器文件</p>
        </a>

        <a href="news_admin.php" class="info-card admin-card hover-jump">
            <h3>📢 公告管理</h3>
            <p>发布 / 编辑系统公告</p>
        </a>
    </div>
</div>
<?php endif; ?>
<div class="section-block hover-jump" onclick="location.href='games.php'" style="cursor:pointer; border-left: 5px solid #00cec9; display:flex; align-items:center; justify-content:space-between;">
    <div>
        <h3 style="margin:0; color:#00cec9;">🎮 进入游戏大厅</h3>
        <p style="margin:5px 0 0 0; color:#666; font-size:13px;">AI 地牢、经典小游戏合集</p>
    </div>
    <div style="font-size:30px;">➡️</div>
</div>

        <div class="section-block">
            <div class="section-title">关于本站</div>
            <p style="color:#555; line-height:1.6;">v1.1.0 哈基米</p>
        </div>
    </div>

    <x id="sidebar">
    <div class="toggle-btn" onclick="toggleSidebar()">◀</div>

    <a href="video.php" class="btn-sidebar hover-jump" style="background-color: #ff9800;; color: #000000ff;">📺 进入影院</a>
    <a href="music.php" class="btn-sidebar hover-jump" style="background-color: #7cf753ff;color: #000000ff;">🎵 听音乐</a>
    <a href="book.php" class="btn-sidebar hover-jump" style="background-color: #f65656ff;color: #000000ff;">📚 电子书架</a>
    <a href="games.php" class="btn-sidebar hover-jump" style="background-color: #01d5ffff;color: #000000ff;">🎮游戏中心</a>
    
    <?php if ($is_admin): ?>
        <a href="news_admin.php" class="btn-sidebar hover-jump" style="background-color: #ff9800;">📢 发布公告</a>
        <a href="upload.php" class="btn-sidebar hover-jump" style="background-color: #e91e63;">📤 上传文件</a>
        <a href="terminal.php" class="btn-sidebar hover-jump" style="background-color: #333;">💻 终端</a>
    <?php else: ?>
        <a href="#" class="btn-sidebar hover-jump" style="background-color: #6c757d;">🛠️ 设置</a>
    <?php endif; ?>
</x>
<script>
function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    const mainContent = document.querySelector('.main-content');
    const toggleBtn = document.querySelector('.toggle-btn');
    
    sidebar.classList.toggle('collapsed');
    mainContent.classList.toggle('full-width');
    
    // 切换按钮文字
    if (sidebar.classList.contains('collapsed')) {
        toggleBtn.innerText = '◀'; // 提示点击展开
    } else {
        toggleBtn.innerText = '▶'; // 提示点击收缩
    }
}
</script>

</body>
</html>