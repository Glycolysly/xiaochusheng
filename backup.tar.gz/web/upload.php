<?php
session_start();
// 1. 只有管理员能进
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    die("<h1>403 Forbidden</h1><p>只有管理员可以访问此页面。</p><a href='index.php'>返回</a>");
}

// === 处理 AJAX 上传请求 ===
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json'); // 返回 JSON 格式给前端 JS

    $target_dir = __DIR__ . "/videos/";
    
    // 1. 尝试自动创建文件夹
    if (!file_exists($target_dir)) {
        if (!mkdir($target_dir, 0777, true)) {
            echo json_encode(['status' => 'error', 'msg' => '无法创建 videos 文件夹，请手动创建！']);
            exit;
        }
    }

    // 2. 检查 PHP 上传错误码
    if ($_FILES["fileToUpload"]["error"] !== UPLOAD_ERR_OK) {
        $errorCode = $_FILES["fileToUpload"]["error"];
        $errorMsg = "未知错误";
        switch ($errorCode) {
            case UPLOAD_ERR_INI_SIZE:
                $errorMsg = "文件超过了 php.ini 中的 upload_max_filesize 限制。";
                break;
            case UPLOAD_ERR_FORM_SIZE:
                $errorMsg = "文件超过了表单限制。";
                break;
            case UPLOAD_ERR_PARTIAL:
                $errorMsg = "文件只有部分被上传。";
                break;
            case UPLOAD_ERR_NO_FILE:
                $errorMsg = "没有文件被上传。";
                break;
        }
        echo json_encode(['status' => 'error', 'msg' => "上传失败 (错误码 $errorCode): $errorMsg"]);
        exit;
    }

    $target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
    $fileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    // 3. 检查文件类型

    // ... 前面的代码不变 ...

    $fileName = basename($_FILES["fileToUpload"]["name"]);
    $fileType = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));

    // 1. 定义允许的类型
    $video_types = ['mp4', 'webm', 'ogg'];
    $audio_types = ['mp3', 'flac', 'wav', 'm4a'];

    // 2. 判断是存到 videos 还是 music
    if (in_array($fileType, $video_types)) {
        $target_dir = __DIR__ . "/videos/";
    } elseif (in_array($fileType, $audio_types)) {
        $target_dir = __DIR__ . "/music/";
    } else {
        echo json_encode(['status' => 'error', 'msg' => '不支持的文件格式。']);
        exit;
    }

    // 自动创建文件夹 (双重保险)
    if (!file_exists($target_dir)) mkdir($target_dir, 0777, true);

    $target_file = $target_dir . $fileName;

    // 3. 移动文件

    // 4. 移动文件
    if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
	    while (ob_get_level()) ob_end_clean();
	    echo json_encode(['status' => 'success', 'msg' => '文件上传成功！']);
    } else {
        // 如果前面都过了，这里还挂了，通常是文件夹权限问题
        echo json_encode(['status' => 'error', 'msg' => '移动文件失败。请检查 E:\web\videos 文件夹是否有写入权限。']);
    }
    exit;
}
?>

<!DOCTYPE html>
<html lang="zh-cn">
<head>
    <meta charset="UTF-8">
    <title>文件上传</title>
    <link rel="icon" type="image/png" href="title.png">
    <style>
        body { 
            font-family: 'Segoe UI', sans-serif; 
            background: #f0f2f5; 
            display: flex; 
            justify-content: center; 
            align-items: center; 
            height: 100vh; 
            margin: 0; 
        }
        .card { 
            background: white; 
            padding: 40px; 
            border-radius: 15px; 
            box-shadow: 0 10px 25px rgba(0,0,0,0.1); 
            width: 450px; 
        }
        h2 { margin-top: 0; color: #333; text-align: center; }
        
        /* 上传区域样式 */
        .upload-area {
            border: 2px dashed #ccc;
            padding: 30px;
            text-align: center;
            border-radius: 10px;
            margin: 20px 0;
            background: #fafafa;
            transition: all 0.3s;
        }
        .upload-area:hover { border-color: #2196F3; background: #e3f2fd; }
        
        input[type=file] { display: none; } /* 隐藏原生丑陋的文件框 */
        
        .btn-select {
            background: #666; color: white; padding: 8px 15px;
            border-radius: 5px; cursor: pointer; display: inline-block;
        }
        
        .file-name { margin-top: 10px; color: #555; font-size: 14px; font-weight: bold; }

        button { 
            background: #2196F3; color: white; border: none; 
            padding: 12px 20px; border-radius: 5px; cursor: pointer; 
            width: 100%; font-size: 16px; margin-top: 10px;
            transition: background 0.3s;
        }
        button:hover { background: #1976D2; }
        button:disabled { background: #ccc; cursor: not-allowed; }

        /* 进度条容器 */
        .progress-wrapper {
            margin-top: 20px;
            display: none; /* 默认隐藏 */
        }
        .progress-bar-bg {
            width: 100%; height: 10px; background: #eee; border-radius: 5px; overflow: hidden;
        }
        .progress-bar-fill {
            height: 100%; width: 0%; background: #4CAF50; border-radius: 5px;
            transition: width 0.2s;
        }
        .progress-text {
            text-align: right; font-size: 12px; color: #666; margin-top: 5px;
        }

        .back-link { display: block; text-align: center; margin-top: 20px; color: #666; text-decoration: none; }
        
        #message { margin-top: 15px; text-align: center; font-size: 14px; }
        .success { color: green; }
        .error { color: #d9534f; }
    </style>
</head>
<body>
    <div class="card">
        <h2>📤 上传资源 (Admin)</h2>
        
        <form id="uploadForm">
            <div class="upload-area" onclick="document.getElementById('fileToUpload').click()">
                <div class="btn-select">📂 点击选择文件</div>
                <div class="file-name" id="fileNameDisplay">未选择文件</div>
                <p style="font-size:12px; color:#999; margin-bottom:0;">支持 MP4, WebM, JPG, PNG</p>
            </div>
            
            <input type="file" name="fileToUpload" id="fileToUpload" onchange="showFileName()">
            
            <div class="progress-wrapper" id="progressWrapper">
                <div class="progress-bar-bg">
                    <div class="progress-bar-fill" id="progressBar"></div>
                </div>
                <div class="progress-text" id="progressText">0%</div>
            </div>

            <div id="message"></div>
            
            <button type="button" onclick="uploadFile()" id="btnUpload">开始上传</button>
        </form>

        <a href="index.php" class="back-link">← 返回控制台</a>
    </div>

    <script>
        function showFileName() {
            var input = document.getElementById('fileToUpload');
            var display = document.getElementById('fileNameDisplay');
            if (input.files.length > 0) {
                display.innerText = input.files[0].name + " (" + (input.files[0].size / 1024 / 1024).toFixed(2) + " MB)";
            } else {
                display.innerText = "未选择文件";
            }
        }

        function uploadFile() {
            var fileInput = document.getElementById('fileToUpload');
            if (fileInput.files.length === 0) {
                alert("请先选择一个文件！");
                return;
            }

            var file = fileInput.files[0];
            var formData = new FormData();
            formData.append("fileToUpload", file);

            // UI 状态更新
            var btn = document.getElementById('btnUpload');
            var msg = document.getElementById('message');
            var wrapper = document.getElementById('progressWrapper');
            var bar = document.getElementById('progressBar');
            var txt = document.getElementById('progressText');

            btn.disabled = true;
            btn.innerText = "上传中...";
            msg.innerText = "";
            wrapper.style.display = "block";
            bar.style.width = "0%";
            bar.className = "progress-bar-fill"; // 重置颜色

            // 创建 AJAX 请求
            var xhr = new XMLHttpRequest();

            // 监听上传进度
            xhr.upload.addEventListener("progress", function(evt) {
                if (evt.lengthComputable) {
                    var percentComplete = Math.round((evt.loaded / evt.total) * 100);
                    bar.style.width = percentComplete + "%";
                    txt.innerText = percentComplete + "%";
                }
            }, false);

            // 上传完成（不管成功失败）
            xhr.addEventListener("load", function(evt) {
                btn.disabled = false;
                btn.innerText = "开始上传";
                
                try {
                    var response = JSON.parse(evt.target.responseText);
                    if (response.status === 'success') {
                        msg.innerHTML = "<span class='success'>✅ " + response.msg + "</span>";
                        bar.style.backgroundColor = "#4CAF50"; // 绿色
                        // 2秒后自动清空
                        setTimeout(() => { location.href = 'index.php'; }, 2000); // 成功后跳回首页
                    } else {
                        msg.innerHTML = "<span class='error'>❌ " + response.msg + "</span>";
                        bar.style.backgroundColor = "#f44336"; // 红色
                    }
                } catch (e) {
                    msg.innerHTML = "<span class='error'>❌ 服务器返回数据异常，可能是文件太大导致 PHP 崩溃。</span>";
                }
            }, false);

            // 上传出错（网络错误）
            xhr.addEventListener("error", function(evt) {
                msg.innerHTML = "<span class='error'>❌ 网络连接失败</span>";
                btn.disabled = false;
                btn.innerText = "开始上传";
            }, false);

            // 发送
            xhr.open("POST", "upload.php");
            xhr.send(formData);
        }
    </script>
</body>
</html>

