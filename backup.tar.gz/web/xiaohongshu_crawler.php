<?php
// xiaohongshu_crawler.php - 小红书热搜爬虫

// 设置时区
date_default_timezone_set('Asia/Shanghai');

// 目标URL：小红书搜索页面（可能需要调整）
$url = 'https://www.xiaohongshu.com/explore';

// 初始化cURL
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36');
curl_setopt($ch, CURLOPT_TIMEOUT, 30);

// 设置headers模拟浏览器
$headers = [
    'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
    'Accept-Language: zh-CN,zh;q=0.8,en-US;q=0.5,en;q=0.3',
    'Accept-Encoding: gzip, deflate, br',
    'Connection: keep-alive',
    'Upgrade-Insecure-Requests: 1',
];
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

// 执行请求
$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($httpCode !== 200) {
    echo "请求失败，HTTP状态码: $httpCode\n";
    exit(1);
}

// 解压gzip（如果有）
if (substr($response, 0, 2) === "\x1f\x8b") {
    $response = gzdecode($response);
}

// 解析HTML，提取热搜关键词
// 注意：这只是示例，实际小红书页面结构可能不同
$hot_searches = [];
if (preg_match_all('/<a[^>]*class="[^"]*hot[^"]*"[^>]*>(.*?)<\/a>/si', $response, $matches)) {
    foreach ($matches[1] as $match) {
        $title = strip_tags($match);
        $title = trim($title);
        if (!empty($title) && strlen($title) > 1) {
            $hot_searches[] = $title;
        }
    }
}

// 如果上面的正则不工作，尝试另一种方式
if (empty($hot_searches)) {
    // 尝试查找JSON数据
    if (preg_match('/window\.pageData\s*=\s*({.+?});/s', $response, $jsonMatch)) {
        $pageData = json_decode($jsonMatch[1], true);
        if ($pageData && isset($pageData['hotSearch'])) {
            foreach ($pageData['hotSearch'] as $item) {
                if (isset($item['word'])) {
                    $hot_searches[] = $item['word'];
                }
            }
        }
    }
}

// 如果还是没有，生成模拟数据
if (empty($hot_searches)) {
    $hot_searches = [
        '2025年新年穿搭',
        '小红书种草',
        '美食探店',
        '护肤秘籍',
        '旅行攻略',
        '家居好物',
        '穿搭灵感',
        '美妆推荐',
        '健身计划',
        '学习笔记',
        '摄影技巧',
        '手工DIY'
    ];
    echo "使用模拟数据\n";
}

// 构建数据结构
$list = [];
foreach (array_slice($hot_searches, 0, 12) as $index => $title) {
    $list[] = [
        'title' => $title,
        'url' => 'https://www.xiaohongshu.com/search_result?keyword=' . urlencode($title),
        'hot' => rand(100, 999) . '万浏览' // 模拟热度
    ];
}

$data = [
    'updated_at' => time(),
    'source' => 'xiaohongshu',
    'list' => $list
];

// 保存到文件
$file = 'xiaohongshu.json';
if (file_put_contents($file, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE))) {
    echo "小红书热搜数据已更新，共 " . count($list) . " 条\n";
    echo "更新时间: " . date('Y-m-d H:i:s') . "\n";
} else {
    echo "保存失败\n";
    exit(1);
}
?>