<?php
// games.php
include 'check.php'; // 保持登录验证
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/png" href="title.png">
    <title>游戏中心 - <?php echo $_SESSION['username']; ?></title>
    <style>
        /* 这里建议直接引入你首页的 css 文件，或者把首页 style 标签里的内容复制过来 */
        /* 为了演示，我列出核心的布局样式 */
        body { margin: 0; padding: 0; background: #f0f2f5; font-family: 'Segoe UI', sans-serif; display: flex; height: 100vh; }
        
        /* 侧边栏样式 (假设你首页有) */
        .sidebar { width: 250px; background: white; padding: 20px; display: flex; flex-direction: column; gap: 15px; }
        .sidebar-item { padding: 12px; border-radius: 8px; cursor: pointer; color: #555; text-decoration: none; display: block; }
        .sidebar-item:hover, .sidebar-item.active { background: #e6f7ff; color: #1890ff; }

        /* 主内容区 */
        .main-content { flex: 1; padding: 30px; overflow-y: auto; }

        /* 通用板块样式 (和你首页一致) */
        .section-block { background: rgba(255,255,255,0.8); backdrop-filter: blur(10px); border-radius: 12px; padding: 20px; margin-bottom: 20px; box-shadow: 0 4px 12px rgba(0,0,0,0.05); transition: transform 0.2s; }
        .hover-jump:hover { transform: translateY(-5px); }
        .section-title { font-size: 18px; font-weight: bold; margin-bottom: 15px; padding-left: 10px; border-left: 4px solid #333; }

        /* 游戏网格布局 */
        .game-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(100px, 1fr)); gap: 10px; }
        .game-card { background: #fff; padding: 15px; border-radius: 8px; text-align: center; cursor: pointer; border: 1px solid #eee; text-decoration: none; color: #333; font-size: 14px; }
        .game-card:hover { border-color: #1890ff; color: #1890ff; }

        /* AI 游戏专用输入框 */
        .ai-game-box { background: #2d3436; color: #dfe6e9; padding: 15px; border-radius: 8px; min-height: 150px; margin-bottom: 10px; font-family: 'Courier New', monospace; white-space: pre-wrap; max-height: 300px; overflow-y: auto;}
    </style>
</head>
<body>

    <div class="sidebar">
        <h2 style="margin:0 0 20px 10px;">我的空间</h2>
        <a href="index.php" class="sidebar-item">🏠 返回首页</a>
        <a href="games.php" class="sidebar-item active">🎮 游戏中心</a>
        <a href="profile.php" class="sidebar-item">👤 个人中心</a>
    </div>

    <div class="main-content">
        
        <div class="section-block hover-jump" style="border-left-color: #00cec9;">
            <h1 style="margin:0; font-size:24px;">🎮 娱乐中心</h1>
            <p style="color:#666; margin-top:5px;">工作学习之余，来放松一下吧。</p>
        </div>

        <div class="section-block hover-jump" style="border-left-color: #fd79a8;">
            <div class="section-title" style="color: #fd79a8; border-color: #fd79a8;">🕹️ 网页小游戏</div>
            <div class="game-grid">
                <a href="games/doudizhu.php" class="game-card">斗地主</a>
                <a href="games/2048_game/index.php" class="game-card">2048</a>
                <a href="games/minesweeper.php" class="game-card">扫雷</a>
                <a href="games/tetris.php" class="game-card">俄罗斯方块</a>
            </div>
        </div>

        <div class="section-block hover-jump" style="border-left-color: #6c5ce7;">
            <div class="section-title" style="color: #6c5ce7; border-color: #6c5ce7;">🏰 AI 文字地牢 (无限剧情)</div>
            
            <div id="dungeon-output" class="ai-game-box">欢迎来到文字地牢！<br>你醒来时发现自己在一个潮湿的地下室里，只有一把生锈的匕首。<br>请输入你的行动（例如：检查四周、往北走）...</div>
            
            <div style="display:flex; gap:10px;">
                <input type="text" id="dungeon-input" placeholder="你要做什么？" style="flex:1; padding:10px; border-radius:6px; border:1px solid #ccc;">
                <button onclick="playDungeon()" id="dungeon-btn" style="padding:10px 20px; background:#6c5ce7; color:white; border:none; border-radius:6px; cursor:pointer;">行动</button>
            </div>
        </div>

        <div class="section-block hover-jump" style="border-left-color: #fab1a0;">
            <div class="section-title" style="color: #fab1a0; border-color: #fab1a0;">🏆 玩家排行榜</div>
            <table style="width:100%; text-align:left; font-size:14px; color:#555;">
                <tr style="border-bottom:1px solid #eee;"><th style="padding:8px;">排名</th><th>玩家</th><th>分数</th></tr>
                <tr><td style="padding:8px;">1</td><td><?php echo $_SESSION['username']; ?></td><td>9999</td></tr>
                <tr><td style="padding:8px;">2</td><td>Admin</td><td>8888</td></tr>
                <tr><td style="padding:8px;">3</td><td>Guest</td><td>1200</td></tr>
            </table>
        </div>

    </div>

    <script>
    // 维护游戏历史，让 AI 记得之前的剧情
    let gameHistory = [
        { role: "system", content: "你是一个文字冒险游戏的DM（地下城主）。你的回复必须包含【剧情描述】和【结果判定】。风格要神秘、稍微黑暗。请根据玩家的行动推进剧情。" },
        { role: "assistant", content: "你醒来时发现自己在一个潮湿的地下室里，只有一把生锈的匕首。" }
    ];

    async function playDungeon() {
        const input = document.getElementById('dungeon-input');
        const output = document.getElementById('dungeon-output');
        const btn = document.getElementById('dungeon-btn');
        const action = input.value.trim();

        if (!action) return;

        // 1. 显示玩家行动
        output.innerHTML += `<br><br><span style="color:#81ecec;">> ${action}</span><br>`;
        input.value = '';
        btn.disabled = true;
        btn.innerText = '判定中...';
        
        // 滚动到底部
        output.scrollTop = output.scrollHeight;

        // 2. 加入历史记录
        gameHistory.push({ role: "user", content: action });

        try {
            // 3. 调用通用后端 ai_handler.php
            const response = await fetch('ai_handler.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ 
                    messages: gameHistory, // 传入完整历史
                    temperature: 1.2       // 游戏需要高随机性
                })
            });

            // 4. 流式接收 (复用之前的逻辑)
            const reader = response.body.getReader();
            const decoder = new TextDecoder("utf-8");
            let buffer = '';
            let aiReply = ""; // 临时存储这一轮的回复

            while (true) {
                const { done, value } = await reader.read();
                if (done) break;
                buffer += decoder.decode(value, { stream: true });
                const lines = buffer.split('\n');
                buffer = lines.pop();

                for (const line of lines) {
                    const trimmed = line.trim();
                    if (!trimmed.startsWith('data: ')) continue;
                    const jsonStr = trimmed.replace('data: ', '');
                    if (jsonStr === '[DONE]') break;

                    try {
                        const json = JSON.parse(jsonStr);
                        const content = json.choices[0].delta.content;
                        if (content) {
                            output.innerHTML += content; // 实时上屏
                            aiReply += content;          // 存入变量
                            output.scrollTop = output.scrollHeight;
                        }
                    } catch (e) {}
                }
            }
            
            // 5. 将 AI 的最终回复存入历史，供下一轮使用
            gameHistory.push({ role: "assistant", content: aiReply });

        } catch (e) {
            output.innerHTML += `<br><span style="color:red;">[系统错误: 命运之线断裂]</span>`;
        } finally {
            btn.disabled = false;
            btn.innerText = '行动';
        }
    }
    </script>
</body>
</html>