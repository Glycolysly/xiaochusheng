<?php
// stream.php - 最终修正版
// 1. 检查 username (确保和 music.php 一致)
// 2. 修复空格问题

session_start();

// 【修改点】改回检查 username，这最保险
if (!isset($_SESSION['username'])) {
    session_write_close();
    // 发送 403 禁止访问
    http_response_code(403);
    exit; 
}
session_write_close(); 

// 获取文件名
$file = isset($_GET['file']) ? $_GET['file'] : '';
if (empty($file)) exit;

// 映射表
$map = [
    'mp3' => '/protected_music/',
    'm4a' => '/protected_music/',
    'flac'=> '/protected_music/',
    'wav' => '/protected_music/',
    'ogg' => '/protected_music/',
    'mp4' => '/protected_videos/',
    'pdf' => '/protected_books/',
    'epub' => '/protected_books/',
    'txt' => '/protected_books/',
];

$ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
if (!isset($map[$ext])) exit;

// 设置正确的Content-Type
$content_types = [
    'mp3' => 'audio/mpeg',
    'm4a' => 'audio/mpeg',
    'flac' => 'audio/flac',
    'wav' => 'audio/wav',
    'ogg' => 'audio/ogg',
    'mp4' => 'video/mp4',
    'pdf' => 'application/pdf',
    'epub' => 'application/epub+zip',
    'txt' => 'text/plain',
];

$content_type = isset($content_types[$ext]) ? $content_types[$ext] : 'application/octet-stream';

// 【关键】文件名编码 (必须有!)
$encoded_filename = rawurlencode($file);
$nginx_uri = $map[$ext] . $encoded_filename;

if (ob_get_length()) ob_clean();

header("Content-Type: " . $content_type);
header("X-Accel-Redirect: " . $nginx_uri);
header("X-Accel-Buffering: no");
exit;
?>
