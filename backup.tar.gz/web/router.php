<?php
// router.php - 性能优化修正版

// 1. 获取请求路径
$uri = $_SERVER["REQUEST_URI"];
$path = parse_url($uri, PHP_URL_PATH);
// 这里的 $file 是硬盘上的绝对路径
$file = __DIR__ . $path;

// ==========================================
// 2. 🚀 静态文件直通 (最关键的优化！)
// ==========================================
// 如果文件存在，且不是目录，且后缀不是 php
// 直接 return false，让 PHP 内置服务器自己处理
// 这样视频流、图片、CSS 就不会去抢 ip_firewall.json 的文件锁了
$ext = pathinfo($file, PATHINFO_EXTENSION);
if (file_exists($file) && !is_dir($file) && strtolower($ext) !== 'php') {
    return false; 
}

// ==========================================
// 3. 🛡️ 防火墙逻辑 (只针对 PHP 接口)
// ==========================================
$ip = $_SERVER['REMOTE_ADDR'];
$ua = strtolower($_SERVER['HTTP_USER_AGENT'] ?? '');
$now = microtime(true);

// 3.1 快速检测恶意特征 (纯内存操作，不读文件)
$trap_paths = [
    '/admin', '/administrator', '/wp-admin', '/phpmyadmin', '/mysql',
    '/.env', '/config.php.bak', '/backup.zip', '/db.sql', '/.git',
    '/actuator', '/api/v1', '/test.php'
];
$bad_agents = ['nessus', 'nmap', 'sqlmap', 'nikto', 'python-requests'];

foreach ($trap_paths as $trap) {
    if (strpos($uri, $trap) === 0) {
        ban_ip($ip, "Trap: $trap");
        exit;
    }
}
foreach ($bad_agents as $agent) {
    if (strpos($ua, $agent) !== false) {
        ban_ip($ip, "Bot: $agent");
        exit;
    }
}

// 3.2 频率限制 (读取 json 文件)
// 只有 PHP 请求才会走到这里，大大减少了文件锁冲突
check_frequency($ip, $now);

// ==========================================
// 4. 动态页面路由
// ==========================================

// 首页路由
if ($path === '/' || $path === '/index.php') {
    require 'index.php';
} 
// 其他 PHP 文件路由 (upload.php, video.php, stream.php 等)
elseif (file_exists($file) && str_ends_with($file, '.php')) {
    require $file;
} 
// 404 处理
else {
    http_response_code(404);
    echo "404 Not Found: " . htmlspecialchars($path);
}

// ==========================================
// 🔧 辅助函数 (让主逻辑更清晰)
// ==========================================

function check_frequency($ip, $now) {
    $limit_file = __DIR__ . '/ip_firewall.json';
    
    // 使用 c+ 模式：读写模式，如果文件不存在则创建
    $fp = fopen($limit_file, 'c+');
    
    if ($fp && flock($fp, LOCK_EX)) {
        $json = stream_get_contents($fp);
        $data = json_decode($json, true);
        if (!$data) $data = [];

        // 初始化
        if (!isset($data[$ip])) $data[$ip] = ['last_time' => $now, 'count' => 0, 'ban_until' => 0, 'reason' => ''];

        // A. 检查是否被封禁
        if ($data[$ip]['ban_until'] > $now) {
            $wait = ceil($data[$ip]['ban_until'] - $now);
            flock($fp, LOCK_UN); fclose($fp);
            http_response_code(403);
            die("<h1>403 Forbidden</h1><p>IP Banned. Wait {$wait}s.</p>");
        }

        // B. 频率计数 (1秒内超过10次请求则封禁)
        if (($now - $data[$ip]['last_time']) < 1.0) {
            $data[$ip]['count']++;
            if ($data[$ip]['count'] > 15) { // 稍微放宽一点到15次，防止误伤
                $data[$ip]['ban_until'] = $now + 60; // 封禁60秒
                $data[$ip]['reason'] = "Fast Access (DoS)";
            }
        } else {
            // 超过1秒，重置计数
            $data[$ip]['count'] = 1;
            $data[$ip]['last_time'] = $now;
        }

        // 写入文件
        ftruncate($fp, 0); rewind($fp); 
        fwrite($fp, json_encode($data));
        flock($fp, LOCK_UN);
    }
    if ($fp) fclose($fp);
}

function ban_ip($ip, $reason) {
    $limit_file = __DIR__ . '/ip_firewall.json';
    $fp = fopen($limit_file, 'c+');
    if ($fp && flock($fp, LOCK_EX)) {
        $json = stream_get_contents($fp);
        $data = json_decode($json, true);
        if (!$data) $data = [];
        
        $data[$ip] = [
            'last_time' => microtime(true),
            'count' => 999,
            'ban_until' => microtime(true) + 600, // 封禁10分钟
            'reason' => $reason
        ];
        
        ftruncate($fp, 0); rewind($fp); 
        fwrite($fp, json_encode($data));
        flock($fp, LOCK_UN);
        fclose($fp);
    }
    http_response_code(403);
    die("Access Denied: $reason");
}
?>
