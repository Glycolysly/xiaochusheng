<?php
// news_admin.php - 公告发布后台 (JSON版)
session_start();

// 1. 权限检查 (根据你的 index.php 逻辑，确保只有管理员能进)
// 如果你的管理员判断逻辑不一样，请自行修改这里
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
die("❌ 只有管理员可以发布公告 <a href='login.php'>登录</a>");
}

$file = 'news.json';

// 2. 处理表单提交 (发布公告)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['title'])) {
    $new_notice = [
        'id'      => uniqid(), // 生成唯一ID
        'title'   => htmlspecialchars($_POST['title']),
        'content' => htmlspecialchars($_POST['content']),
        'type'    => $_POST['type'], // 样式类型：info, warning, danger
        'date'    => date('Y-m-d H:i')
    ];

    $data = file_exists($file) ? json_decode(file_get_contents($file), true) : [];
    if (!is_array($data)) $data = [];
    
    // 把新公告插到最前面
    array_unshift($data, $new_notice);
    
    // 保存回文件
    file_put_contents($file, json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    
    header("Location: news_admin.php");
    exit;
}

// 3. 处理删除请求
if (isset($_GET['delete'])) {
    $id_to_delete = $_GET['delete'];
    $data = file_exists($file) ? json_decode(file_get_contents($file), true) : [];
    
    // 过滤掉要删除的ID
    $data = array_filter($data, function($item) use ($id_to_delete) {
        return $item['id'] !== $id_to_delete;
    });
    
    file_put_contents($file, json_encode(array_values($data), JSON_UNESCAPED_UNICODE));
    header("Location: news_admin.php");
    exit;
}

// 读取现有公告
$notices = file_exists($file) ? json_decode(file_get_contents($file), true) : [];
?>

<!DOCTYPE html>
<html lang="zh-cn">
<head>
    <meta charset="UTF-8">
    <title>📢 公告管理后台</title>
    <style>
        body { font-family: sans-serif; max-width: 800px; margin: 40px auto; padding: 20px; background: #f4f4f4; }
        .card { background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); margin-bottom: 20px; }
        input, textarea, select { width: 100%; margin-bottom: 10px; padding: 10px; box-sizing: border-box; }
        button { background: #2196F3; color: white; border: none; padding: 10px 20px; cursor: pointer; border-radius: 4px; }
        .list-item { border-bottom: 1px solid #eee; padding: 10px 0; display: flex; justify-content: space-between; align-items: center; }
        .tag { padding: 3px 8px; border-radius: 4px; font-size: 12px; color: white; margin-right: 10px; }
        .tag.info { background: #2196F3; }
        .tag.warning { background: #ff9800; }
        .tag.danger { background: #f44336; }
        .delete-btn { color: red; text-decoration: none; font-size: 14px; }
    </style>
</head>
<body>
    <div class="card">
        <h2>✍️ 发布新公告</h2>
        <form method="post">
            <select name="type">
                <option value="info">🔵 普通通知 (Info)</option>
                <option value="warning">🟠 重要提醒 (Warning)</option>
                <option value="danger">🔴 紧急维护 (Danger)</option>
            </select>
            <input type="text" name="title" placeholder="公告标题 (例如：今晚服务器维护)" required>
            <textarea name="content" rows="4" placeholder="公告详情内容..." required></textarea>
            <button type="submit">🚀 立即发布</button>
            <a href="index.php" style="float:right; margin-top:10px;">返回首页</a>
        </form>
    </div>

    <div class="card">
        <h3>📜 历史公告列表</h3>
        <?php if (empty($notices)): ?>
            <p style="color:#888;">暂无公告，快发一条吧！</p>
        <?php else: ?>
            <?php foreach ($notices as $n): ?>
                <div class="list-item">
                    <div>
                        <span class="tag <?php echo $n['type']; ?>"><?php echo strtoupper($n['type']); ?></span>
                        <strong><?php echo $n['title']; ?></strong>
                        <span style="color:#999; font-size:12px; margin-left:10px;"><?php echo $n['date']; ?></span>
                        <div style="color:#666; font-size:13px; margin-top:5px;"><?php echo $n['content']; ?></div>
                    </div>
                    <a href="?delete=<?php echo $n['id']; ?>" class="delete-btn" onclick="return confirm('确定删除吗？')">🗑️ 删除</a>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</body>
</html>
