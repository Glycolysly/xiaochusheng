<?php
// book.php - 电子书书架页面

session_start();
// 1. 安全检查
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}
// 释放 Session 锁，避免卡顿
session_write_close();

// 2. 扫描电子书
$book_dir = 'books/';
$files = glob($book_dir . '*.{pdf,epub,txt}', GLOB_BRACE);

$book_list = [];
if ($files) {
    foreach ($files as $file) {
        $filename = basename($file);
        $name_without_ext = pathinfo($file, PATHINFO_FILENAME);

        // 构建数据
        $book_list[] = [
            'file' => $filename,
            'name' => $name_without_ext,
            'path' => $file,
            'type' => strtolower(pathinfo($file, PATHINFO_EXTENSION))
        ];
    }
}

if (empty($book_list)) {
    echo "<script>alert('未找到电子书文件！');window.location.href='index.php';</script>";
    exit;
}
?>
<!DOCTYPE html>
<html lang="zh-cn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>电子书书架</title>
    <link rel="icon" type="image/png" href="title.png">
    <style>
        /* 全局样式 */
        body {
            font-family: 'Segoe UI', Arial, sans-serif;
            margin: 0;
            padding: 0;
            background: linear-gradient(to right, #ff99cc 0%, #ffffff 50%, #66ccff 100%);
            color: #333;
            min-height: 100vh;
        }

        /* 导航栏 */
        nav {
            position: fixed;
            top: 0; left: 0;
            width: 100%;
            height: 70px;
            background-color: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-bottom: 1px solid rgba(0, 0, 0, 0.05);
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 40px;
            box-sizing: border-box;
            z-index: 100;
        }

        .nav-logo { font-size: 20px; font-weight: bold; color: #333; }
        .nav-links { display: flex; align-items: center; }
        .nav-links a { color: #555; margin-left: 20px; font-size: 15px; font-weight: 500; }
        .nav-links a:hover { color: #000; }

        /* 主内容 */
        .main-content {
            margin-top: 70px;
            padding: 40px;
            min-height: calc(100vh - 70px);
        }

        .page-title {
            text-align: center;
            margin-bottom: 40px;
            color: white;
            font-size: 2.5em;
            font-weight: 300;
            text-shadow: 0 2px 4px rgba(0,0,0,0.3);
        }

        /* 书架网格 */
        .bookshelf {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(160px, 1fr));
            gap: 20px;
            max-width: 1000px;
            margin: 0 auto;
        }

        .book-card {
            background: linear-gradient(135deg, #d4a574 0%, #c49666 50%, #a67c52 100%);
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 8px 32px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
            cursor: pointer;
            text-decoration: none;
            color: inherit;
            display: flex;
            flex-direction: column;
            height: 45%;
        }

        .book-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 12px 35px rgba(0,0,0,0.15);
        }

        .book-cover {
            height: 90px;
            background: linear-gradient(135deg, #8b4513 0%, #a0522d 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
            overflow: hidden;
        }

        .book-cover::before {
            content: '';
            position: absolute;
            top: 0; left: 0;
            right: 0; bottom: 0;
            background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><text fill="white" font-size="40" y="50%">📖</text></svg>') no-repeat center;
            background-size: 60px;
            opacity: 0.8;
        }

        .book-type {
            position: absolute;
            top: 10px;
            right: 10px;
            background: rgba(255,255,255,0.9);
            color: #333;
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 12px;
            font-weight: bold;
            text-transform: uppercase;
        }

        .book-info {
            padding: 12px;
            flex: 1;
            display: flex;
            flex-direction: column;
            background: rgba(255, 255, 255, 0.9);
            justify-content: space-between;
        }

        .book-title {
            font-size: 14px;
            font-weight: 600;
            color: #333;
            margin-bottom: 6px;
            line-height: 1.3;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            overflow: hidden;
            flex: 1;
        }

        .book-meta {
            font-size: 11px;
            color: #666;
            margin-top: auto;
            text-align: center;
        }

        .book-actions {
            padding: 10px 12px;
            background: rgba(0,0,0,0.05);
            display: flex;
            gap: 6px;
        }

        .btn {
            padding: 6px 12px;
            border: none;
            border-radius: 6px;
            font-size: 12px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.2s;
            text-decoration: none;
            display: inline-block;
            text-align: center;
            flex: 1;
        }

        .btn-primary {
            background: #667eea;
            color: white;
        }

        .btn-primary:hover {
            background: #5a6fd8;
        }

        .btn-secondary {
            background: #f8f9fa;
            color: #666;
        }

        .btn-secondary:hover {
            background: #e9ecef;
        }

        /* 响应式 */
        @media (max-width: 768px) {
            .bookshelf {
                grid-template-columns: repeat(auto-fill, minmax(140px, 1fr));
                gap: 15px;
            }

            .main-content {
                padding: 20px;
            }

            .page-title {
                font-size: 2em;
            }

            .book-cover {
                height: 80px;
            }

            .book-title {
                font-size: 13px;
            }

            .btn {
                font-size: 11px;
                padding: 5px 10px;
            }
        }

        @media (max-width: 480px) {
            .bookshelf {
                grid-template-columns: repeat(auto-fill, minmax(120px, 1fr));
            }

            .book-cover {
                height: 70px;
            }

            .book-info {
                padding: 10px;
            }

            .book-title {
                font-size: 12px;
                -webkit-line-clamp: 2;
            }

            .btn {
                font-size: 10px;
                padding: 4px 8px;
            }
        }
    </style>
</head>
<body>
    <nav>
        <div class="nav-logo">📚 电子书书架</div>
        <div class="nav-links">
            <a href="index.php">首页</a>
            <a href="logout.php">注销</a>
        </div>
    </nav>

    <div class="main-content">
        <h1 class="page-title">我的电子书库</h1>

        <div class="bookshelf">
            <?php foreach ($book_list as $book): ?>
                <div class="book-card">
                    <div class="book-cover">
                        <div class="book-type"><?php echo strtoupper($book['type']); ?></div>
                    </div>
                    <div class="book-info">
                        <div class="book-title"><?php echo htmlspecialchars($book['name']); ?></div>
                        <div class="book-meta"><?php echo strtoupper($book['type']); ?> 文件</div>
                    </div>
                    <div class="book-actions">
                        <a href="reader.php?book=<?php echo urlencode($book['file']); ?>" class="btn btn-primary">阅读</a>
                        <a href="<?php echo htmlspecialchars($book['path']); ?>" download class="btn btn-secondary">下载</a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</body>
</html>
<html lang="zh-cn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>电子书阅读</title>
    <link rel="icon" type="image/png" href="title.png">
    <style>
        /* 全局样式 */
        body {
            font-family: 'Segoe UI', Arial, sans-serif;
            margin: 0;
            padding: 0;
            background: linear-gradient(to right, #d7c2c2, #7895ea, #1185f3ff);
            color: #333;
            overflow: hidden;
        }

        /* 导航栏 */
        nav {
            position: fixed;
            top: 0; left: 0;
            width: 100%;
            height: 70px;
            background-color: rgba(255, 255, 255, 0.7);
            backdrop-filter: blur(10px);
            border-bottom: 1px solid rgba(0, 0, 0, 0.05);
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 40px;
            box-sizing: border-box;
            z-index: 100;
        }

        .nav-logo { font-size: 20px; font-weight: bold; color: #333; }
        .nav-links { display: flex; align-items: center; }
        .nav-links a { color: #555; margin-left: 20px; font-size: 15px; font-weight: 500; }
        .nav-links a:hover { color: #000; }

        /* 主内容 */
        .main-content {
            margin-top: 70px;
            height: calc(100vh - 70px);
            display: flex;
        }

        /* 侧边栏 */
        .sidebar {
            width: 300px;
            background: rgba(255, 255, 255, 0.8);
            border-right: 1px solid rgba(0, 0, 0, 0.1);
            overflow-y: auto;
            padding: 20px;
            box-sizing: border-box;
        }

        .sidebar h3 {
            margin: 0 0 15px 0;
            color: #333;
        }

        .book-list {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .book-list li {
            margin-bottom: 10px;
        }

        .book-list a {
            display: block;
            padding: 10px;
            background: rgba(255, 255, 255, 0.6);
            border-radius: 6px;
            text-decoration: none;
            color: #333;
            transition: all 0.3s;
        }

        .book-list a:hover,
        .book-list a.active {
            background: rgba(255, 255, 255, 0.9);
            transform: translateX(5px);
        }

        /* 阅读区域 */
        .reader {
            flex: 1;
            background: rgba(255, 255, 255, 0.9);
            display: flex;
            flex-direction: column;
        }

        .reader-header {
            padding: 15px 20px;
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
            background: rgba(255, 255, 255, 0.8);
        }

        .reader-header h2 {
            margin: 0;
            color: #333;
        }

        .reader-content {
            flex: 1;
            padding: 20px;
            overflow: auto;
        }

        .reader-content iframe {
            width: 100%;
            height: 100%;
            border: none;
        }

        /* 响应式 */
        @media (max-width: 768px) {
            .main-content {
                flex-direction: column;
            }
            .sidebar {
                width: 100%;
                height: 200px;
                border-right: none;
                border-bottom: 1px solid rgba(0, 0, 0, 0.1);
            }
        }
    </style>
</head>
<body>
    <nav>
        <div class="nav-logo">📚 电子书书架</div>
        <div class="nav-links">
            <a href="index.php">网站首页</a>
            <a href="logout.php">注销</a>
        </div>
    </nav>

    <div class="main-content">
        <div class="sidebar">
            <h3>电子书列表</h3>
            <ul class="book-list">
                <?php foreach ($book_list as $index => $book): ?>
                    <li>
                        <a href="?b=<?php echo urlencode($book['file']); ?>" class="<?php echo ($index === $current_index) ? 'active' : ''; ?>">
                            📖 <?php echo htmlspecialchars($book['name']); ?>
                        </a>
                    </li>
                <?php endforeach; ?>
            </ul>
        </div>

        <div class="reader">
            <div class="reader-header">
                <h2><?php echo htmlspecialchars($current_book['name']); ?></h2>
            </div>
            <div class="reader-content">
                <?php if ($current_book['type'] === 'pdf'): ?>
                    <iframe src="<?php echo htmlspecialchars($current_book['path']); ?>" title="PDF 阅读器"></iframe>
                <?php elseif ($current_book['type'] === 'epub'): ?>
                    <p>EPUB 文件：<?php echo htmlspecialchars($current_book['name']); ?> (暂不支持在线阅读，请下载)</p>
                    <a href="<?php echo htmlspecialchars($current_book['path']); ?>" download>下载 EPUB</a>
                <?php elseif ($current_book['type'] === 'txt'): ?>
                    <pre><?php echo htmlspecialchars(file_get_contents($current_book['path'])); ?></pre>
                <?php else: ?>
                    <p>不支持的文件类型</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html>