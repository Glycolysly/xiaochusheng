<?php
session_start();

// 如果用户已经登录，直接跳到首页
if (isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}

$error_msg = '';

// ====================================================
// 只有当用户点击了“立即登录”按钮 (POST请求) 时，才执行下面的代码
// ====================================================
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    // 1. 获取表单提交的数据
    $username = isset($_POST['username']) ? trim($_POST['username']) : '';
    $password = isset($_POST['password']) ? trim($_POST['password']) : '';
    
    // 2. 读取 JSON 文件
    $json_file = '732946d0544620d92e4d7c4b1490b143.json';
    
    if (!file_exists($json_file)) {
        $error_msg = "系统错误：找不到用户数据文件";
    } else {
        // 获取内容
        $json_string = file_get_contents($json_file);
        $users = json_decode($json_string, true);
        
        if (!$users) {
            $error_msg = "系统错误：用户数据格式有误";
        } else {
            // 3. 遍历查找用户
            $login_success = false;
            
            foreach ($users as $user) {
                // 检查用户名是否匹配
                if ($user['username'] === $username) {
                    
                    // 检查密码 (关键修改：必须使用 password_verify 验证加密密码)
                    // 因为你在注册页用了 password_hash，这里不能直接用 ===
                    if (password_verify($password, $user['password'])) {
                        
                        // --- 密码正确，登录成功 ---
                        $_SESSION['user_id'] = $user['id'];
                        $_SESSION['username'] = $user['username'];
                        $_SESSION['role'] = $user['role']; // 写入权限
                        
                        $login_success = true;
                        break; // 停止循环
                    }
                }
            }
            
            // 4. 根据结果处理
            if ($login_success) {
                // 登录成功 -> 跳转首页
                header("Location: index.php");
                exit;
            } else {
                // 登录失败 -> 显示错误
                $error_msg = "用户名或密码错误！";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="zh-cn">
<head>
    <meta charset="UTF-8">
    <title>用户登录</title>
    <link rel="icon" type="image/png" href="title.png">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        /* 全局样式，保持和首页一致 */
        body {
            font-family: Arial, sans-serif;
            background-color: #fdfdfdff;
            margin: 0;
            height: 100vh;
            display: flex;
            justify-content: center; /* 水平居中 */
            align-items: center;     /* 垂直居中 */
            overflow: hidden;
            position: relative;
        }

        /* 背景层样式 */
        /* --- 登录框样式 (卡片) --- */
        .login-card {
            position: relative;
            z-index: 10; /* 保证浮在背景上面 */
            background: rgba(249, 249, 249, 0.95); /* 半透明白色背景 */
            padding: 40px;
            width: 320px;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.3); /* 阴影效果 */
            text-align: center;
        }

        .login-card h2 {
            margin-top: 0;
            color: #333;
            margin-bottom: 20px;
        }

        /* 输入框样式 */
        .form-group {
            margin-bottom: 15px;
            text-align: left;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 5px;
            color: #666;
            font-size: 14px;
        }

        .form-control {
            width: 100%;
            padding: 10px;
            box-sizing: border-box; 
            background: rgba(249, 249, 249, 0.95);
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
        }

        /* 按钮样式 */
        .btn-submit {
            width: 100%;
            padding: 12px;
            background-color: #4CAF50; /* 绿色按钮 */
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            margin-top: 10px;
            transition: background 0.3s;
        }

        .btn-submit:hover {
            background-color: #45a049;
        }

        /* 错误提示样式 */
        .error-message {
            color: #ff0000;
            background-color: #ffe6e6;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 15px;
            font-size: 14px;
            display: <?php echo empty($error_msg) ? 'none' : 'block'; ?>;
        }
        
        .back-link {
            margin: 15px;
            font-size: 14px;
            color: #490ae9ff;
            text-decoration: none;
        }
        .bottom-links {
            display: flex;              /* 开启弹性布局 */
            justify-content: center; /* 关键：让子元素向两边撑开 */
            margin-top: 20px;           /* 距离上面按钮的间距 */
}
    </style>
</head>
<body>

    <?php include("back.php"); ?>

    <div class="login-card">
        <h2>用户登录</h2>

        <div class="error-message">
            <?php echo $error_msg; ?>
        </div>

        <form method="post" action="login.php">
            <div class="form-group">
                <label>用户名</label>
                <input type="text" name="username" class="form-control" placeholder="请输入用户名" required>
            </div>

            <div class="form-group">
                <label>密码</label>
                <input type="password" name="password" class="form-control" placeholder="请输入密码" required>
            </div>

            <button type="submit" class="btn-submit">立即登录</button>
        </form>
<div class="bottom-links">
    <a href="index.php" class="back-link">← 返回首页</a>
    <a href="register.php" class="back-link">去注册 →</a>
</div>
    </div>

</body>
</html>