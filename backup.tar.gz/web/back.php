<canvas id="background-canvas"></canvas>
<div class="background-overlay"></div>

<style>
    /* 1. 画布：放在最底层 (z-index: 0) */
    #background-canvas {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        z-index: 0; /* 提升层级，防止跑到底层虚空里 */
        pointer-events: none;
        /* 备用背景色 */
        background: radial-gradient(ellipse at bottom, #1b2735 0%, #090a0f 100%);
    }

    /* 2. 遮罩层：放在画布上面 (z-index: 1) */
    .background-overlay {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        /* 深蓝色的半透明遮罩 */
        background-color: rgba(5, 10, 30, 0.4); 
        z-index: 1; 
        pointer-events: none;
    }

    /* 3. 你的登录框：必须比上面两个都高 (login.php 里原本是 10，这里不用改) */
    /* 确保 login-card 的 z-index > 1 即可 */
</style>

<script>
(function() {
    const canvas = document.getElementById('background-canvas');
    const ctx = canvas.getContext('2d');

    let width, height;
    let stars = [];

    // 星星参数
    const starCountFactor = 10000; // 星星密度
    const starColor = '173, 216, 230'; // 浅蓝色

    function resize() {
        width = window.innerWidth;
        height = window.innerHeight;
        canvas.width = width;
        canvas.height = height;
    }

    class Star {
        constructor() {
            this.init();
        }

        init() {
            this.x = Math.random() * width;
            this.y = Math.random() * height;
            // 让星星大一点，容易看见
            this.size = Math.random() * 1.5 + 1; 
            
            this.alpha = Math.random();
            this.fadeDir = Math.random() > 0.5 ? 1 : -1;
            this.fadeSpeed = Math.random() * 0.01 + 0.001;
        }

        update() {
            this.alpha += this.fadeDir * this.fadeSpeed;
            if (this.alpha >= 1) { this.alpha = 1; this.fadeDir = -1; }
            if (this.alpha <= 0.1) { this.alpha = 0.1; this.fadeDir = 1; }
        }

        draw() {
            ctx.beginPath();
            // 绘制
            const gradient = ctx.createRadialGradient(this.x, this.y, 0, this.x, this.y, this.size * 3);
            gradient.addColorStop(0, `rgba(255, 255, 255, ${this.alpha})`);
            gradient.addColorStop(0.4, `rgba(${starColor}, ${this.alpha * 0.8})`);
            gradient.addColorStop(1, `rgba(${starColor}, 0)`);
            
            ctx.fillStyle = gradient;
            ctx.arc(this.x, this.y, this.size * 3, 0, Math.PI * 2);
            ctx.fill();
        }
    }

    function init() {
        resize();
        stars = [];
        const count = Math.floor((width * height) / starCountFactor);
        for(let i = 0; i < count; i++) {
            stars.push(new Star());
        }
        animate();
    }

    function animate() {
        ctx.clearRect(0, 0, width, height);

        // 每一帧都画背景，确保覆盖掉 body 的颜色
        const bgGradient = ctx.createLinearGradient(0, 0, 0, height);
        bgGradient.addColorStop(0, '#020b1a');
        bgGradient.addColorStop(1, '#0b1a36');
        ctx.fillStyle = bgGradient;
        ctx.fillRect(0, 0, width, height);

        stars.forEach(star => {
            star.update();
            star.draw();
        });

        requestAnimationFrame(animate);
    }

    window.addEventListener('resize', () => {
        resize();
        init();
    });

    init();
})();
</script>